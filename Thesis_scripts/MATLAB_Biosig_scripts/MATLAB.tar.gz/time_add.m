function t = time_add(t1,t2)
% Adds times in [h m s ms]
% Hours are in recording times (no modulo)
%
% Manolis Christodoulakis @ 2014

    ms    = mod(t1(4)+t2(4),1000);
    add_s = floor(double(t1(4)+t2(4))/1000);
    s     = mod(t1(3)+t2(3)+add_s,60);
    add_m = floor(double(t1(3)+t2(3)+add_s)/60);
    m     = mod(t1(2)+t2(2)+add_m,60);
    add_h = floor(double(t1(2)+t2(2)+add_m)/60);
    h     = t1(1)+t2(1)+add_h;

    t     = [h m s ms];
end
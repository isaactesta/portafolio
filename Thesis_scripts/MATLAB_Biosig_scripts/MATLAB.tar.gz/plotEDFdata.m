function ax = plotEDFdata(data,start,finish,shift)
%plotEDFdata Plots the data between start and finish
%
%   Plots a data matrix in the EDF format:
%       1 row, where each cell is a channel
%
%   Input:      data,   The channel data (1 row, 18 cols/cells at least)
%               start,  The time in seconds where the plot should start
%               finish, The time in seconds where the plot should finish
%               shift,  Optional argument specifying a time shift in
%                       seconds (for plotting purposes only)
%
%   Manolis Christodoulakis @ 2013

SRATE=500;

if nargin < 4
    shift = 0;
end

% Open the figure
screen_size = get(0, 'ScreenSize');
h = figure('Position', [0 0 0.9*screen_size(3) 0.9*screen_size(4) ]);
set(h,'Color',[1 1 1]);

% Make the plots
for i=1:18
    ax(i) = subplot(18,1,i); 
    plot(shift+start:0.002:shift+finish,data{1,i}(start*SRATE:finish*SRATE));
    axis tight
end

% Set the X-axis tick locations and limits of
% each plot to the same values
ylims = cell2mat(get(ax,'YLim'));
upper = max(ylims);
upper = upper(2);
lower = min(ylims);
lower = lower(1);
set(ax,'YLim',[lower upper]);

% Turn off the X-tick labels in the top axes
set(ax(1:17),'XTickLabel','');

% Set the color of the X-axis in the top axes
% to the axes background color
set(ax(1:17),'XColor',get(gca,'Color'))

% Turn off the box so that only the left 
% vertical axis and bottom axis are drawn
set(ax,'box','off')

end


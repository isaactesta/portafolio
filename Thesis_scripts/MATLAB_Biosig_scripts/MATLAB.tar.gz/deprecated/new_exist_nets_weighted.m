function [doesexist]=new_exist_nets_weighted(outdir,windows)
    tic;
    
    disp('Checking existence of correlations and events...');
    
    doesexist = false;
    
    datafile = [outdir '/data.mat'];
    
    if ~exist(datafile,'file')
        disp(['    Datafile does not exist!']);
        return;
    end
    
    load(datafile,'nets_w*','evstart','evend');
    vars_to_check = {'evstart'; 'evend'};
    for w = windows
        vars_to_check = [['nets_w' int2str(w)]; vars_to_check]; 
    end
    
    for i=1:size(vars_to_check,1)
        if ~exist(vars_to_check{i},'var')
            disp(['    Variable ' vars_to_check{i} ' does not exist!']);
            return;
        end
    end

    disp('    Yes, all data do exist!');
    doesexist = true;
    disp(['New method: ' num2str(toc)]);
end
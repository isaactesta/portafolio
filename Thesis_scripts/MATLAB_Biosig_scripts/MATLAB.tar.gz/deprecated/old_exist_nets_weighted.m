function [doesexist]=old_exist_nets_weighted(outdir,windows)
    tic;
    
    disp('Checking existence of correlations and events...');
    
    doesexist = false;
    
    datafile = [outdir '/data.mat'];
    
    if exist(datafile,'file')
        load(datafile,'nets_w*','evstart','evend')
    else 
        disp(['    Datafile does not exist!']);
        return;
    end
    
    for w = windows
        if ~exist(['nets_w' int2str(w)],'var')
        	disp(['nets_w' int2str(w) ' does not exist!']);
            return;
        end
    end
    
    if ~exist('evstart','var') || ~exist('evend','var')
        disp('    Events do not exist!');
        return;
    end

    disp('    Yes, all data do exist!');
    doesexist = true;
    disp(['Old method: ' num2str(toc)]);
end

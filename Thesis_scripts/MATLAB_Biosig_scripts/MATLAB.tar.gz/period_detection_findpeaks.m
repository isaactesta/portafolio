function periods = period_detection_findpeaks(lags,autocor,fs)
% Manolis Christodoulakis @ 2014
    
    MinPeakHeight = 0.001;
    Threshold = 0;
    [pk,lc] = findpeaks(autocor,'MinPeakDistance',fs,'Threshold',Threshold);%,'MinPeakheight',MinPeakHeight);
    period  = mean(diff(lc))/fs
    periods = period;
    pks = {pk};
    lcs = {lc};

    while ~isempty(period)
        [pk,lc] = findpeaks(autocor,'MinPeakDistance',ceil(period)*fs,'Threshold',Threshold);%,'MinPeakheight',MinPeakHeight);
        if size(lc,1)>1
            % Keep only prominent peaks
            [max_pk_value,max_pk_loc] = max(pk);
            prominent_indx = find(pk>max_pk_value/2);
            pk = pk(prominent_indx);
            lc = lc(prominent_indx);
            
            period = mean(diff(lc))/fs
            if period<26
                periods(end+1,1) = period;
                pks{1,end+1} = pk;
                lcs{1,end+1} = lc;
            else
                period = [];
            end
        else
            period = [];
        end
    end
 
    figure; plot(lags/fs,autocor);

    hold on
    N = size(periods,1);
    Legends = cell(N+1,1);  
    Legends{1} = '';
    Styles = {'or','vk','+y','>b','<m','*r','xk','.y','sb','dm'};
    for i=1:N
        plot(lags(lcs{1,i})/fs,pks{1,i}+i*0.05,Styles{1,mod(i,size(Styles,2))+1});
        Legends{i+1} = ['Period: ' num2str(periods(i))];
    end
    hold off
    legend(Legends)
    
end
clear all;
close all;
Fs= 1000;

t=0:1/Fs:50;

x= sin(2*pi*10.*t) + 0.03* randn(size(t));
y=sin(2*pi*10.*t)+ 0.03* randn(size(t));
z=sin(2*pi*10.*t + pi/4)+ 0.03* randn(size(t));

%% bp filtering at teh global lelvel (long signal)
%% instananeous phases
xh=angle(hilbert(x));yh=angle(hilbert(y));zh=angle(hilbert(z)); %[ pi

%%% make pairs

dphi1=xh-yh; %% [-2pi 2pi]
dphi2=xh-zh; %% [-2pi 2pi]
%% normalize phase [-pi pi],, %% look internet
a=mod(dphi1,2*pi)-pi;%% incorrect mapping, fix me
b=mod(dphi2,pi)-pi;% incorrect mapping, fix me

pli=abs(mean(sign(sin(a))));
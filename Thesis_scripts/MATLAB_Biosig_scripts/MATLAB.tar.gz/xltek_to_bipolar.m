function [ bipolar_data ] = xltek_to_bipolar(data, ncols)
%XLTEK_TO_BIPOLAR Converts the XLTEK raw data to bipolar
%   Assumes that rows are time moments and cols are channels
%
% Manolis Christodoulakis @ 2012

    if (nargin<2)
        ncols = 18;
    end
    
    nlines       = size(data,1);
    bipolar_data = zeros(nlines,25);

    bipolar_data(:,1)  = data(:,4) - data(:,5);     %  Fp1 - F7
    bipolar_data(:,2)  = data(:,5) - data(:,6);     %   F7 - T3
    bipolar_data(:,3)  = data(:,6) - data(:,7);     %   T3 - T5
    bipolar_data(:,4)  = data(:,7) - data(:,8);     %   T5 - O1
    bipolar_data(:,5)  = data(:,18) - data(:,19);   %  Fp2 - F8
    bipolar_data(:,6)  = data(:,19) - data(:,20);   %   F8 - T4
    bipolar_data(:,7)  = data(:,20) - data(:,21);   %   T4 - T6
    bipolar_data(:,8)  = data(:,21) - data(:,22);   %   T6 - O2
    bipolar_data(:,9)  = data(:,4) - data(:,9);     %  Fp1 - F3
    bipolar_data(:,10) = data(:,9) - data(:,10);    %   F3 - C3
    bipolar_data(:,11) = data(:,10) - data(:,11);   %   C3 - P3
    bipolar_data(:,12) = data(:,11) - data(:,8);    %   P3 - O1
    bipolar_data(:,13) = data(:,18) - data(:,15);   %  Fp2 - F4
    bipolar_data(:,14) = data(:,15) - data(:,16);   %   F4 - C4
    bipolar_data(:,15) = data(:,16) - data(:,17);   %   C4 - P4
    bipolar_data(:,16) = data(:,17) - data(:,22);   %   P4 - O2
    bipolar_data(:,17) = data(:,12) - data(:,13);   %   Fz - Cz
    bipolar_data(:,18) = data(:,13) - data(:,14);   %   Cz - Pz
    
    bipolar_data(:,19) = data(:,4) - data(:,27);     %   F8 - AC27
    bipolar_data(:,20) = data(:,27) - data(:,7);     % AC27 - T5
    bipolar_data(:,21) = data(:,18) - data(:,28);    %  Fp2 - AC28
    bipolar_data(:,22) = data(:,28) - data(:,21);    % AC28 - T6
    bipolar_data(:,23) = data(:,23) - data(:,1);     % AC23 - AC1
    bipolar_data(:,24) = data(:,24) - data(:,2);     % AC24 - AC2
    bipolar_data(:,25) = data(:,25) - data(:,26);    % AC25 - AC26

%     tic
%     i = [4:7 18:21 4 9:11 18 15:17 12:13];
%     j = [5:8 19:22 9:11 8 15:17 22 13:14];
%     bp2 = data(:,i) - data(:,j);
%     toc
%     isequal(bipolar_data,bp2)
%     assert(isequal(bipolar_data,bp2));
    bipolar_data = bipolar_data(:,1:ncols);

end


%% Run several tests together
% Column vectors, use semicolon
montages     = {'bipolar'};
filterings   = {'f1-60_notch'}; % 'f1-50'; 'f1-60'; 'ICA'
correlations = {'coherence_freq_bands'; 'imaginary_coherence_freq_bands'; 'mean_coherence_freq_bands'}; % 'coherence_freq_bands'; 'imaginary_coherence_freq_bands'; 'mean_coherence_freq_bands'; 'cross-corr'; 'cross-corr_no_zero_lag';
seizures     = {'/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240' '19_56_36_820_[-15min_+15min]'; % I.I.
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '4_18_11_250_[-15min_+15min]';  % M.C. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '16_48_31_920_[-15min_+15min]'; % M.C. 2nd seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_11_43_870_[-15min_+15min]'; % T.K. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_33_52_810_[-15min_+15min]'; % T.K. 2nd seizure
                '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' '91_26_49_705_[-15min_+15min]';           % H.E.
                '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' '36_43_57_265_[-15min_+15min]';       % M.G.
                '/home/manolisc/epilepsy/Exports/Export-Txxxxx~ Yxxxxx_d405987a-c066-4363-a607-bd1ec8c5f7cf' '15_50_06_900_[-15min_+15min]'        % T.Y. 
};

new_seizures = {'/home/manolisc/epilepsy/Exports/Export-10753' '5848.2812_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '7582.25_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '36929.2395_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '40464.3958_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '41666.2395_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '42626.6041_[-15min_+15min]'
};

% OLD PATIENTS
[s m c f] = ndgrid(1:size(seizures,1), 1:numel(montages), 1:numel(correlations), 1:numel(filterings));
run       = [ seizures(s(:),1) seizures(s(:),2) montages(m(:)) correlations(c(:)) filterings(f(:)) ];

% NEW PATIENTS
%[s m c f] = ndgrid(1:size(new_seizures,1), 1:numel(montages), 1:numel(correlations), 1:numel(filterings));
%run       = [ new_seizures(s(:),1) new_seizures(s(:),2) montages(m(:)) correlations(c(:)) filterings(f(:)) ];

tic
%matlabpool open
parfor i = 1:size(run,1)
    testing_measures(run{i,1}, run{i,2}, run{i,3}, run{i,4}, run{i,5});
end
%matlabpool close
toc


%% Run selection of tests
% =========================================================================
montages     = {'bipolar'; 'ref'; 'avgref'};
correlations = {'cross-corr';                       % 1
                'cross-corr_no_zero_lag';           % 2
                'cross-corr_no_symmetric';          % 3
                'coherence';                        % 4
                'coherence_freq_bands';             % 5
                'mean_coherence';                   % 6
                'mean_coherence_freq_bands';        % 7
                'mean_imaginary_coherence';         % 8
                'imaginary_coherence';              % 9 
                'imaginary_coherence_freq_bands';   % 10
                'pli';                              % 11
                'pli_cpsd';                         % 12
                'wpli'};                            % 13
thresholds   = [0.75; 0.75; 0.5;
                0.75; 0.75; 
                0.4; 0.4;
                0.08;
                0.5; 0.5; 
                0.13; 0.55; 0.6]; 
filterings   = {'ICA'; 'f1-60_notch'; 'f1-45'; 'f1-50'; 'f1-60'; 'alpha'; 'beta'; 'gamma'; 'delta'; 'theta'; 
                'ICA_alpha'; 'ICA_beta'; 'ICA_gamma'; 'ICA_delta'; 'ICA_theta';}; 
seizures     = {'/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240' '19_56_36_820_[-15min_+15min]'; % I.I.
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '4_18_11_250_[-15min_+15min]';  % M.C. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '16_48_31_920_[-15min_+15min]'; % M.C. 2nd seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_11_43_870_[-15min_+15min]'; % T.K. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_33_52_810_[-15min_+15min]'; % T.K. 2nd seizure
                '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' '91_26_49_705_[-15min_+15min]';           % H.E.
                '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' '36_43_57_265_[-15min_+15min]';       % M.G.
                '/home/manolisc/epilepsy/Exports/Export-Txxxxx~ Yxxxxx_d405987a-c066-4363-a607-bd1ec8c5f7cf' '15_50_06_900_[-15min_+15min]'        % T.Y. 
};

new_seizures = {'/home/manolisc/epilepsy/Exports/RC-4337' '1-6_Day_12_[-15min_+26.5min]';       % 1
                '/home/manolisc/epilepsy/Exports/RC-4337' '7_Day_12_[-15min_+15min]';           % 2
                '/home/manolisc/epilepsy/Exports/RC-4337' '8_Day_12_[-15min_+15min]';           % 3
                '/home/manolisc/epilepsy/Exports/RC-4337' '9-12_Day_22_[-11.9min_+47.2min]';    % 4
                '/home/manolisc/epilepsy/Exports/DK-2440' '1_Day_31_[-15min_+15min]';           % 5
                '/home/manolisc/epilepsy/Exports/DK-2440' '2_Day_31_[-15min_+15min]';           % 6
                '/home/manolisc/epilepsy/Exports/SN-10838' '1_Day_110_[-15min_+15min]';         % 7
                '/home/manolisc/epilepsy/Exports/SN-10838' '2_Day_21_[-15min_+15min]';          % 8
                '/home/manolisc/epilepsy/Exports/SN-10838' '3_Day_21_[-15min_+15min]';          % 9
                '/home/manolisc/epilepsy/Exports/SN-10838' '4_Day_325_[-15min_+15min]';         % 10
                '/home/manolisc/epilepsy/Exports/SN-10838' '5_Day_325_[-15min_+15min]'          % 11
};

long_seizures = {'/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '4_18_11_250_[-240min_+240min]';  % M.C. 1st seizure
                 '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '4_18_11_250_[-480min_+480min]';  % M.C. 1st seizure
                 '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '16_48_31_920_[-240min_+240min]'; % M.C. 2nd seizure
                 '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240' 'all_Export1'; % I.I.
                 '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' 'all_Export1'; % M.C.
                 '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' 'all_Export1a'; % T.K.
                 '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' 'all_Export1b'; % T.K.
                 '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' 'all_Export1'; % H.E.
                 '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' 'all_Export2a'; % H.E.
                 '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' 'all_Export2b'; % H.E.
                 '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' 'all_Export1'; % M.G.
                 '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' 'all_Export2'; % M.G.
                 '/home/manolisc/epilepsy/Exports/GM-10837' 't1_unipolar2bipolar';
                 '/home/manolisc/epilepsy/Exports/MV-5859' '1_unipolar2bipolar';
                 '/home/manolisc/epilepsy/Exports/MV-5859' '2_unipolar2bipolar';
                 '/home/manolisc/epilepsy/Exports/RC-4337' 't1_unipolar2bipolar'
                 '/home/manolisc/epilepsy/Exports/RC-4337' 't2_unipolar2bipolar';
};

long_seiz_mat = {'/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240' 'Export1'; % I.I.
                 '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' 'Export1'; % M.C.
                 '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' 'Export1'; % T.K.
                 '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' 'Export1-2'; % H.E.
                 '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' 'Export1-2'; % M.G.
                 '/home/manolisc/epilepsy/Exports/Export-DP-98304' 'Export1';
                 '/home/manolisc/epilepsy/Exports/GM-10837' 'Export1';
                 '/home/manolisc/epilepsy/Exports/MV-5859' 'Export1-2';
                 '/home/manolisc/epilepsy/Exports/RC-4337' 'Export2';
};

mrange = 1;%1:3;
%crange = [1 3 4 9 11 13];
crange = 1;%[5 11];
frange = 3;
srange = 2;%[13:17]; %[1 2 6 7];
for m = mrange
    for c = crange
        for f = frange
            for s = srange
                disp(long_seiz_mat(s,1));
                disp(long_seiz_mat(s,2));
                disp(montages(m));
                disp(correlations(c));
                disp(filterings(f));
                testing_measures_mat(long_seiz_mat{s,1},long_seiz_mat{s,2},montages{m},correlations{c},filterings{f},thresholds(c));
            end
        end
    end
end

% for p=1:6
%     mat = matfile([long_seiz_mat{p,1} '/seizure_' long_seiz_mat{p,2} '.mat']);
%     info = whos(mat,'data');
%     n = info.size(1)
%     index_to_time(n,200)
% end


%% Plot brain networks around seizure
% =========================================================================
clear
PATIENT_SEIZURE ='focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/';
EXPERIMENT      ='bipolar__ICA__imaginary_coherence_freq_bands';
MONTAGE         = 'bipolar'
WINDOW          = 5;
CONNECTIVITY    = 0.2;
SURROGATES      = 0;
THRESHOLD       = 0; %0.55;

% Load experiment
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/data.mat'],['nets_w' num2str(WINDOW)]);
if CONNECTIVITY>0
    eval(['nets = binarize_fixed_connectivity(nets_w' int2str(WINDOW) ',CONNECTIVITY);']);
elseif SURROGATES>0
    %%%%%%%%%%%%%%%%%
else
    eval(['nets = binarize(nets_w' int2str(WINDOW) ',THRESHOLD);']);
end
eval(['clear nets_w' int2str(WINDOW)]);

% Set output directory
if CONNECTIVITY>0
    subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/graphs_w' int2str(WINDOW) '_c' num2str(CONNECTIVITY)];
elseif SURROGATES>0
    %%%%%%%%%%%%%%%%%
else
    subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/graphs_w' int2str(WINDOW) '_t' num2str(THRESHOLD)];
end

if ~exist(subdir,'dir')
    mkdir(subdir);
end

%% Plot specific networks
timemoments = [50 190 280];
if size(nets_w5,4)==1
    for i=timemoments
        draw_brain_network(nets_w5(:,:,i), MONTAGE)
        saveas(gcf, [subdir '/graph' int2str(i) '.jpg'])
        close(gcf);    
    end
else
    network_labels = {'all_bands' 'alpha' 'beta' 'gamma' 'delta' 'theta'};
    for i=timemoments
        for j=1:6
            draw_brain_network(nets_w5(:,:,i,j), MONTAGE)
            saveas(gcf, [subdir '/' network_labels{j} '_graph' int2str(i)  '.jpg'])
            close(gcf);    
        end
    end
end

%% Plot average networks
periods = [10  40;
           180 210;
           240 270];
period_labels = {'avg_preictal' 'avg_ictal' 'avg_postictal'};

if size(nets_w5,4)==1
    for i=1:size(periods,1)
        avgnet = binarize(mean(nets_w5(:,:,periods(i,1):periods(i,2)),3),0.5);
        draw_brain_network(avgnet, MONTAGE)
        saveas(gcf, [subdir '/graph_' period_labels{i} '.jpg'])
        close(gcf);    
    end
else
    network_labels = {'all_bands' 'alpha' 'beta' 'gamma' 'delta' 'theta'};
    for i=1:size(periods,1)
        for j=1:6
            avgnet = binarize(mean(nets_w5(:,:,periods(i,1):periods(i,2),j),3),0.5);
            draw_brain_network(avgnet, MONTAGE)
            saveas(gcf, [subdir '/' network_labels{j} '_graph_' period_labels{i}  '.jpg'])
            close(gcf);    
        end
    end
end

% Clean up
%clear PATIENT_SEIZURE EXPERIMENT WINDOW THRESHOLD MONTAGE subdir i nets



%% Plot brain networks differences between two networks
% =========================================================================
clear;
PATIENT_SEIZURE ='focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/';
EXPERIMENT1     ='bipolar__ICA__coherence_freq_bands';
THRESHOLD1      = 0.65;
CONNECTIVITY1   = 0; %0.2;
EXPERIMENT2     ='bipolar__ICA__imaginary_coherence_freq_bands';
THRESHOLD2      = 0.55;
CONNECTIVITY2   = 0; %0.2;
MONTAGE         = 'bipolar'
WINDOW          = 5;
DIFFTITLE       = 'coherence__vs__imaginary_coherence';
legends = {'Coherence' 'Imaginary coherence'};

% Load experiment 1
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT1 '/data.mat'],['nets_w' num2str(WINDOW)]);
if THRESHOLD1>0
    eval(['nets1 = binarize(nets_w' int2str(WINDOW) ',THRESHOLD1);']);
elseif CONNECTIVITY1>0
    eval(['nets1 = binarize_fixed_connectivity(nets_w' int2str(WINDOW) ',CONNECTIVITY1);']);
end
eval(['clear nets_w' int2str(WINDOW)]);

% Load experiment 2
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT2 '/data.mat'],['nets_w' num2str(WINDOW)]);
if THRESHOLD2>0
    eval(['nets2 = binarize(nets_w' int2str(WINDOW) ',THRESHOLD2);']);
elseif CONNECTIVITY2>0
    eval(['nets2 = binarize_fixed_connectivity(nets_w' int2str(WINDOW) ',CONNECTIVITY2);']);
end
eval(['clear nets_w' int2str(WINDOW)]);

% Set output directory
if THRESHOLD1>0
    subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT1 '/graphs_w' int2str(WINDOW) '_t' num2str(THRESHOLD1) ...
        '__diff__' DIFFTITLE];
elseif CONNECTIVITY1>0
    subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT1 '/graphs_w' int2str(WINDOW) '_c' num2str(CONNECTIVITY1) ...
        '__diff__' DIFFTITLE];
end
if ~exist(subdir,'dir')
    mkdir(subdir);
end

%% Plot specific networks
print_common_edges = 1;
timemoments = [50 190 280];
if size(nets1,4)==1
    for i=timemoments
        % Plot only networks that differ
        if draw_brain_network_differences(nets1(:,:,i), nets2(:,:,i), MONTAGE, legends, print_common_edges)
            saveas(gcf, [subdir '/graph' int2str(i) '.jpg'])
        end
        close(gcf);
    end
else
    network_labels = {'all_bands' 'alpha' 'beta' 'gamma' 'delta' 'theta'};
    for i=timemoments
        for j=1:6
            % Plot only networks that differ
            if draw_brain_network_differences(nets1(:,:,i,j), nets2(:,:,i,j), MONTAGE, legends, print_common_edges)
                saveas(gcf, [subdir '/' network_labels{j} '_graph' int2str(i)  '.jpg'])
            end
            close(gcf);    
        end
    end
end

%% Plot average networks
print_common_edges = 1;
periods = [10  40;
           180 210;
           240 270];
period_labels = {'avg_preictal' 'avg_ictal' 'avg_postictal'};
figs = {};

if size(nets1,4)==1
    for i=1:size(periods,1)
        avgnet1 = binarize(mean(nets1(:,:,periods(i,1):periods(i,2)),3),0.5);
        avgnet2 = binarize(mean(nets2(:,:,periods(i,1):periods(i,2)),3),0.5);
        % Plot only networks that differ
%        figs = [figs; [subdir '/graph_' period_labels{i} '.fig']];
        if draw_brain_network_differences(avgnet1, avgnet2, MONTAGE, legends, print_common_edges)
            saveas(gcf, [subdir '/graph_' period_labels{i} '.jpg'])
%            saveas(gcf, [subdir '/graph_' period_labels{i} '.fig'])
        end
        close(gcf);    
    end
else
    network_labels = {'all_bands' 'alpha' 'beta' 'gamma' 'delta' 'theta'};
    for i=1:size(periods,1)
        for j=1:6
            avgnet1 = binarize(mean(nets1(:,:,periods(i,1):periods(i,2),j),3),0.5);
            avgnet2 = binarize(mean(nets2(:,:,periods(i,1):periods(i,2),j),3),0.5);
%            figs = [figs; [subdir '/' network_labels{j} '_graph_' period_labels{i}  '.fig']];
            if draw_brain_network_differences(avgnet1, avgnet2, MONTAGE, legends, print_common_edges)
                saveas(gcf, [subdir '/' network_labels{j} '_graph_' period_labels{i}  '.jpg'])
%                saveas(gcf, [subdir '/' network_labels{j} '_graph_' period_labels{i}  '.fig'])
            end
            close(gcf);    
        end
    end
end

% Combine the figures above into one
% row_titles = {'Broadband' 'Alpha' 'Beta' 'Gamma' 'Delta' 'Theta'};
% col_titles = {'Preictal' 'Ictal' 'Postictal'};
% figs_to_grid(figs,6,2,row_titles,col_titles,legends,[subdir '/graph_grid']);

% Clean up
%clear PATIENT_SEIZURE EXPERIMENT WINDOW THRESHOLD MONTAGE subdir i nets







%% Plot correlations vs electrode distances
% =========================================================================
% Load electod distances and get rid of the common reference Cz
if ~exist('A')
    A=importdata('electrode-distances.txt');
    A=A(~ismember(1:size(A,1),13),:);
    A=A(:,~ismember(1:size(A,2),13));
    Avec = nonzeros(triu(A)');
end

% Load the correlations
PATIENT_SEIZURE='focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_19_56_36_820_[-15min_+15min]/';
NAME='I.I.';
%EXPERIMENT='ref__f1-60__coherence_freq_bands';
EXPERIMENT='ref__f1-50__kramer__ICA';
WINDOW=10;
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/data.mat'],['nets_w' num2str(WINDOW)]);
timemoments = [70 90 100];
freq        = {'all' 'alpha' 'beta' 'gamma' 'delta' 'theta'};

for t=timemoments
    for fi=1:1
        %figtitle = strcat(NAME,' --- ',EXPERIMENT,' - ', char(freq(fi)), ' --- window=',num2str(WINDOW),'--- time=', num2str(t));

         % Plot correlation measure
        netvec = nonzeros(triu(nets_w10(:,:,t,fi))');
        scatter(Avec,netvec);
        h=lsline;
        set(h(1),'color','r')
        title(figtitle);
        saveas(gcf, strcat(figtitle, '.jpg'));
        close(gcf);
    end
end

% Plot correlation measure minus random coherence
%figure
%scatter(Avec,netvec-exp((1-Avec)/3));
%lsline;


%% Single patient from scratch
[data,indices] = importEEG('/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min].txt',0);
node_data      = xltek_to_bipolar(data);
filtered_data  = bandpass(node_data,1,50);

SRATE  = 200;
WINDOW = 5;     % In sec.
frame  = WINDOW*SRATE;

[length chan]  = size(filtered_data);
nets_w         = zeros(chan,chan,ceil(length/frame));
maxind         = zeros(chan,chan,ceil(length/frame));
timemoments    = 0;
for time = 1:frame:length
    timestop    = min(time+frame-1,length);
    timemoments = timemoments + 1;
    for i = 1:chan
        for j = 1:chan
            if (i<j)
%                [nets_w(i,j,timemoments) maxind(i,j,timemoments)] = max(abs(xcov(filtered_data(time:timestop,i),filtered_data(time:timestop,j),50,'coeff')));
                covmat = abs(xcov(filtered_data(time:timestop,i),filtered_data(time:timestop,j),50,'coeff'));
%                nets_w(i,j,timemoments) = max(max(covmat(1:50)),max(covmat(52:101)));
                covmat(51) = 0;
                [nets_w(i,j,timemoments) maxind(i,j,timemoments)] = max(covmat);
            % We'll make it symmetric afterwards
            %else
            %    nets_w(i,j,timemoments) = nets_w(j,i,timemoments);
            end
        end
    end
end

for i=1:timemoments
    nets_w(:,:,i) = triu(nets_w(:,:,i)) + triu(nets_w(:,:,i),1)';
end

%plot(1:timemoments, reshape(maxind(1,2,:),timemoments,1));

nets_bin = binarize(nets_w,0.75);
plot_nodes_property('average_degree_und',nets_bin,WINDOW);


%% Problematic coherence data
load('/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_19_56_36_820_[-15min_+15min]/bipolar__f1-60__coherence_freq_bands/data.mat');
[C,f]  = mscohere(data(120000:122000,5),data(120000:122000,4),[],[],[],200);figure; plot(f,C);


%% Plot part of edf matrix
from=12;
to=15;
SRATE=500;

screen_size = get(0, 'ScreenSize');
h = figure('Position', [0 0 screen_size(3) screen_size(4) ]);
set(h,'Color',[1 1 1]);
for i=1:18
    ax(i) = subplot(18,1,i); 
    plot(from:0.002:to,DK_data2{1,i}(from*SRATE:to*SRATE));
end

    % Set the X-axis tick locations and limits of
    % each plot to the same values
%    set(ax,'YTick',get(ax(1),'YTick'), ...
%    'YLim',get(ax(1),'YLim'))

    % Turn off the X-tick labels in the top axes
    set(ax(1:17),'XTickLabel','');

    % Set the background color to gray
%    set(gca,'Color',[0.8 0.8 0.8]);

    % Set the color of the X-axis in the top axes
    % to the axes background color
    set(ax(1:17),'XColor',get(gca,'Color'))
    
    % Turn off the box so that only the left 
    % vertical axis and bottom axis are drawn
    set(ax,'box','off')

%% Load a series of EDF data from a patient
day_num = 9;
max_day_file = 4;
patient_day = ['/home/epilepsy/Original Data/new-patients-small-files/Karamanidou Panayiota 10753/KP_patientevent5-' int2str(day_num) ];
for i=0:max_day_file
    if (i==0)
        seq = '';
    else
        seq = int2str(i);
    end
    % Load both data and header
    % eval(['[data' int2str(day_num) seq ',header' int2str(day_num) seq ']=ReadEDF(''' patient_day seq '.edf'');']);
    % Load header only
    eval(['[~,header' int2str(day_num) seq ']=ReadEDF(''' patient_day seq '.edf'');']);
end

%%
for i=0:4
    if (i==0)
        seq = '';
    else
        seq = int2str(i);
    end
    eval(['header' int2str(day_num) seq '.startdate']);
    eval(['header' int2str(day_num) seq '.starttime']);
    eval(['header' int2str(day_num) seq '.annotation.event(1:5)']);
    eval(['starts = find(strcmp(header' int2str(day_num) seq '.annotation.event,''start''))']);
end

%%
sum = size(data1{1,1},1);
for i=1:9
    eval(['sum = sum + size(data1' int2str(i) '{1,1},1);']);
end
sum
sum/(500*60)

%%
patient   = 'KP_Day1';
starttime = 87.8125;
shift     = 0;

% Ignore shift initially
    starttime_row = floor(starttime * 500);
    figure7
    plot(-data{1,1}(starttime_row-1000:starttime_row+1000));
    hold on;
    ylimits = get(gca, 'YLim');
    plot([1000 1000], ylimits, '--','DisplayName','','Color','k');

    saveas(gca,[patient '_seizure_' num2str(starttime) 'a.jpg']);
    hold off;

% Plot once more with the shift included
if (shift>0)
    starttime_row = floor(starttime * 500) + shift*500;
    figure
    plot(-data16{1,1}(starttime_row-1000:starttime_row+1000));
    hold on;
    ylimits = get(gca, 'YLim');
    plot([1000 1000], ylimits, '--','DisplayName','','Color','k');

    saveas(gca,[patient '_seizure_' num2str(starttime) 'b.jpg']);
    close;
end


%% Bipolar (old) data; making plots on selection of channels
clear;
bad_channels = [1 5 9 13];
threshold  = 0.75;
datadir    = '/home/manolisc/epilepsy/Exports';
patient    = 'focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240';
seizure    = 'seizure_19_56_36_820_[-15min_+15min]';
experiment = 'bipolar__ICA__coherence_freq_bands';
artfctdir  = '/home/manolisc/fieldtrip';

% Load the data
load([datadir '/' patient '/' seizure '/' experiment '/data.mat']);
window_size = 5;

% Get rid of noisy channels
index = true(1,size(nets_w5,1));
index(bad_channels) = false;
if size(nets_w5,4)>0
    nets_w5_clean = nets_w5(index,index,:,:);
else
    nets_w5_clean = nets_w5(index,index,:);
end
size(nets_w5_clean)

% Correct event annotations
load([artfctdir '/' patient '/' seizure '__seizures-and-artifacts.mat']);
seizstart = cfg.artfctdef.seizure.artifact(1)/200;
seizend = cfg.artfctdef.seizure.artifact(2)/200;

% Binarize and plot for clean network
nets_w5 = binarize(nets_w5_clean,threshold);
clean_figdir = [OUTDIR '/window=' num2str(window_size) '/threshold=' num2str(threshold) '/excl_bad_channels'];
plot_all(nets_w5,window_size,seizstart,seizend,clean_figdir);
plot_all_brain_networks(nets_w5,NET,clean_figdir,bad_channels);


%% Plot node properties vs electrode distance of two experiments in the same figure (coherence vs imaginary coherence, one band per plot)
clear
datafile1 = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/data.mat';
load(datafile1,'nets_w5');
nets1 = nets_w5;
clear nets_w5;

datafile2 = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__imaginary_coherence_freq_bands/data.mat';
load(datafile2,'nets_w5','evstart','evend');
nets2 = nets_w5;   % 4th dim. is now the freq. band
clear nets_w5;

load('/home/manolisc/epilepsy/MATLAB/electrode_locations_and_distances.mat','bipolar_distances');
dist = nonzeros(triu(bipolar_distances));
clear bipolar_distances;

figdir = strrep(datafile1,'data.mat','electrode_dist_comparison_to_imaginary_coherence');
timemoments = [90];
freq        = {'All bands' 'Alpha Band' 'Beta Band' 'Gamma Band' 'Delta Band' 'Theta Band'};

for t=timemoments
    for fi=1:6
        figtitle = strcat(freq(fi),'Time=', num2str(t));

        % Plot correlation measure
        net1vec = nonzeros(triu(nets1(:,:,t,fi))');
        net2vec = nonzeros(triu(nets2(:,:,t,fi))');
        scatter(dist,net1vec,'o');
        h=lsline;
        set(h(1),'color','r')
        hold on
        scatter(dist,net2vec,'+');
        h=lsline;
        set(h(1),'color','b')
        title(figtitle);
        saveas(gcf, strcat(figdir,'/',figtitle, '.jpg'));
        close(gcf);
    end
end





%% Plot histogram of lag indices where the max cross-corr and the max cross-corr-no-zero-lag occur
clear
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/data.mat';
load(datafile);

[s1 s2 s3]    = size(indx);
size_per_iter = (s1-1)*(s2-2)/2;
%indx_vector   = zeros(s3*size_per_iter,1);
indx_vector1 = [];
for i=1:s3
    strt = (i-1)*size_per_iter+1;
    %indx_vector(strt:strt+size_per_iter-1) = indx(find(~tril(ones(size(indx(:,:,i))))));
    indx_vector1 = [indx_vector1; indx(find(~tril(ones(size(indx(:,:,i))))))];
end

indx_vector1(indx_vector1<-15|indx_vector1>15) = [];

%Uncomment the following to plot single histogram
h = figure;
hist(indx_vector1,[-15:15])
title('Distribution of maximimum cross-correlation lags');
xlabel('Lags');
saveas(h,[strrep(datafile,'data.mat','cross_corr_hist.jpg')]);

%%
clearvars -except indx_vector1
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr_no_zero_lag/data.mat';
load(datafile);

[s1 s2 s3]    = size(indx);
size_per_iter = (s1-1)*(s2-2)/2;
%indx_vector   = zeros(s3*size_per_iter,1);
indx_vector2 = [];
for i=1:s3
    strt = (i-1)*size_per_iter+1;
    %indx_vector(strt:strt+size_per_iter-1) = indx(find(~tril(ones(size(indx(:,:,i))))));
    indx_vector2 = [indx_vector2; indx(find(~tril(ones(size(indx(:,:,i))))))];
end
indx_vector2(indx_vector2<-15|indx_vector2>15) = [];

h = figure;
subplot(2,1,1)
hist(indx_vector1,[-15:15])
title('Cross-correlation');
subplot(2,1,2)
hist(indx_vector2,[-15:15])
title('Cross-correlation excluding zero-lags');
saveas(h,[strrep(datafile,'data.mat','subplot_hist_with_and_without_zerolags.jpg')]);
saveas(h,[strrep(datafile,'data.mat','subplot_hist_with_and_without_zerolags.fig')]);


%% Histogram to show differences between max correlations of cross-corr and cross-corr_no_zero_lag
clear
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr_no_zero_lag/data.mat';
load(datafile);
indx_nozerolag = indx;
nets_nozerolag = nets_w5;
clearvars -except indx_nozerolag nets_nozerolag

datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/data.mat';
load(datafile);
nets_w5 = nets_w5;
clearvars -except indx_nozerolag nets_nozerolag indx nets datafile

% Indices of non-zero elements above the diagonal
[s1 s2 s3]    = size(indx);         % third dimension is time
size_per_iter = (s1-1)*(s2-2)/2;
diffs = [];
for i=1:s3
    % Vectorize upper triangular parts
    indx1 = indx(:,:,i);
    indx1v = indx1(itriu(size(indx1),1));
    nets_diff = nets_w5(:,:,i) - nets_nozerolag(:,:,i);
    nets1v = nets_diff(itriu(size(indx1),1));
    
    diffs = [diffs; nets1v(find(indx1v==0))];
end

h = figure;
%[nelements,xcenters] = hist(diffs);
%plot(xcenters,nelements);
hist(diffs,[0.025:0.05:0.4]);
saveas(h,[strrep(datafile,'data.mat','crosscorr_vs_nonzerolag_maxdiff.jpg')]);
saveas(h,[strrep(datafile,'data.mat','crosscorr_vs_nonzerolag_maxdiff.fig')]);


%% Plot node properties of three experiments in the same figure (change montage)
% =========================================================================
% Load and binarize nets
% In the 4th dimension we add the experiments to be plot at the same figure
% included
% Need to set MULTIPLE_NETWORKS_PER_FIG = 1
clear
seizure = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/';
%seizure = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_91_26_49_705_[-15min_+15min]/';
%suffix = '__fmax_20';
suffix = '';

%experiment = 'cross-corr'; threshold = 0.6;
%experiment = 'cross-corr_no_zero_lag'; threshold = 0.6;
%experiment = 'cross-corr_no_symmetric'; threshold = 0.15;
%experiment = 'coherence'; threshold = 0.82;
%experiment = 'imaginary_coherence'; threshold = 0.64;
%experiment = 'pli'; threshold = 0.1;
%experiment = 'wpli'; threshold = 0.45;
experiments = {'cross-corr'; 'cross-corr_no_symmetric';
                'coherence'; 'imaginary_coherence';
                'pli'; 'wpli'};
thresholds = [0.6; 0.15; 0.75; 0.58; 0.1; 0.45];

for i=1:size(experiments,1)
    datafile = [seizure 'ref__ICA__' experiments{i} suffix '/data.mat'];
    FileInfo = dir(datafile); TimeStamp = FileInfo.date
    load(datafile,'nets_w5');
    nets_w5 = binarize(nets_w5,thresholds(i));
    clear nets_w5;

    datafile = [seizure 'avgref__ICA__' experiments{i} suffix '/data.mat'];
    FileInfo = dir(datafile); TimeStamp = FileInfo.date
    load(datafile,'nets_w5');
    channels_to_include = [1:12 14:19];
    avgnet = binarize(nets_w5,thresholds(i));
    nets_w5(:,:,:,2) = avgnet(channels_to_include,channels_to_include,:);
    clear nets_w5;

    datafile = [seizure 'bipolar__ICA__' experiments{i} suffix '/data.mat'];
    FileInfo = dir(datafile); TimeStamp = FileInfo.date
    load(datafile,'nets_w5','evstart','evend');
    nets_w5(:,:,:,3) = binarize(nets_w5,thresholds(i));
    clear nets_w5;

    % Plot properties - you need to set MULTIPLE_NETWORKS_PER_FIG = 1
    figdir = strrep(datafile,'data.mat',[experiments{i} suffix '_montage_comparison_3x']);
    network_labels = {'Common reference montage' 'Average reference montage' 'Bipolar montage' };
    plot_all(nets_w5,5,seizstart,seizend,figdir,network_labels);
end




%% Plot node properties of two experiments in the same plot
% =========================================================================
% Load and binarize nets
% In the 4th dimension: 1 is no-zero-lag corrs and 2 with zero-lags
% included
clear
seizure = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/';
%seizure = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_91_26_49_705_[-15min_+15min]/';
file_prefix = [seizure 'bipolar__ICA__'];
file_suffix = '/data.mat';

% Cross-correlation vs no-zero-lag
% experiments = {'cross-corr'; 'cross-corr_no_zero_lag'};
% legends = {'Cross-correlation'; 'No-zero-lag cross-correlation'};
% thresholds = [0.5; 0.5];

% Cross-correlation vs no-symmetric
% experiments = {'cross-corr'; 'cross-corr_no_symmetric'};
% legends = {'Cross-correlation'; 'Corrected cross-correlation'};
% thresholds = [0.5; 0.15];

% Coherence
% experiments = {'mean_coherence'; 'mean_imaginary_coherence'};
% legends = {'Coherence'; 'Imaginary Coherence'};
% thresholds = [0.35; 0.06];

% Coherence freq bands
experiments = {'coherence_freq_bands'; 'imaginary_coherence_freq_bands'};
legends = {'Coherence'; 'Imaginary Coherence'};
thresholds = [0.65; 0.55];

% PLI
% experiments = {'pli'; 'wpli'};
% legends = {'PLI'; 'Weighted PLI'};
% thresholds = [0.13; 0.6];

% PLI bands
% file_prefix = [seizure 'bipolar__ICA_theta__'];
% experiments = {'pli'; 'wpli'};
% legends = {'PLI'; 'Weighted PLI'};
% thresholds = [0.13; 0.6];

% Cross-correlation varying thresholds
% experiments = {'cross-corr'; 'cross-corr'; 'cross-corr'; 'cross-corr'};
% legends = {'0.3'; '0.4'; '0.5'; '0.6'};
% thresholds = [0.3; 0.4; 0.5; 0.6];

% Cross-correlation varying thresholds
% experiments = {'cross-corr_no_symmetric'; 'cross-corr_no_symmetric'; 'cross-corr_no_symmetric'; 'cross-corr_no_symmetric'};
% legends = {'0.09'; '0.12'; '0.15'; '0.18'};
% thresholds = [0.09; 0.12; 0.15; 0.18];


for i=1:size(experiments,1)
    datafile = [file_prefix experiments{i} file_suffix];
    FileInfo = dir(datafile); TimeStamp = FileInfo.date
    load(datafile,'nets_w5');
    if size(size(nets_w5),2)==4
        nets_w5(:,:,:,:,i) = binarize(nets_w5,thresholds(i));
    else
        nets_w5(:,:,:,i) = binarize(nets_w5,thresholds(i));
    end
    clear nets_w5;
end
load(datafile,'evstart','evend');

expdir = '';
for i=1:size(experiments,1)-1
    expdir = [expdir experiments{i} '__vs__'];
end
expdir = [expdir experiments{end}];
figdir = strrep([file_prefix experiments{1} file_suffix],'data.mat',expdir)

if ~exist(figdir,'dir')
    mkdir(figdir); 
end

if size(size(nets_w5),2)==5
    freqband_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};
    [s1 s2 s3 s4 s5] = size(nets_w5);
    for i=1:s4
        plot_all(reshape(nets_w5(:,:,:,i,:),[s1 s2 s3 s5]),5,seizstart,seizend,[figdir '/' freqband_labels{i}],legends);
    end
else
    plot_all(nets_w5(:,:,:,:),5,seizstart,seizend,figdir,legends);
end



%% Combine multiple figs in one fig
% =========================================================================

% Montages, varying measures
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]';
%dir = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_91_26_49_705_[-15min_+15min]';
%suffix = '__fmax_20';
suffix = '';

figs = { [dir '/bipolar__ICA__cross-corr' suffix '/cross-corr' suffix '_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/bipolar__ICA__cross-corr_no_symmetric' suffix '/cross-corr_no_symmetric' suffix '_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/bipolar__ICA__coherence' suffix '/coherence' suffix '_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/bipolar__ICA__imaginary_coherence' suffix '/imaginary_coherence' suffix '_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/bipolar__ICA__pli' suffix '/pli' suffix '_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/bipolar__ICA__wpli' suffix '/wpli' suffix '_montage_comparison_3x/average_degree_und1.fig']
       };
titles = {'Cross-correlation'; 'Corrected cross-correlation';
            'Coherence'; 'Imaginary coherence'; 
            'PLI'; 'Weighted PLI'};
legends = {'Common ref.' 'Average ref.' 'Bipolar' };
figs_to_subplots(figs,titles,3,2,legends,[dir '/average_degree_montage_comparisons']);

%% Cross-corr vs cross-corr_no_zero_lag, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/cross-corr__vs__cross-corr_no_zero_lag';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
%         [dir '/betweenness_centralization_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; % 'Betweenness centralization';
             'Clustering'};
legends = {'Cross-correlation' 'No-zero-lag cross-correlation'};
figs_to_subplots(figs,titles,3,1,legends,[dir '/cross-corr__vs__cross-corr_no_zero_lag_all_measures']);

%% Cross-corr vs no-symmetric, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/cross-corr__vs__cross-corr_no_symmetric';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; 'Clustering'};
legends = {'Cross-correlation' 'Corrected cross-correlation'};
figs_to_subplots(figs,titles,3,1,legends,[dir '/cross-corr__vs__cross-corr_no_symmetric__all_measures']);

%% Cross-corr vs cross-corr_no_zero_lag, average degree, varying threshold
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]';
fig_choice = 'average_degree_und1';
figs = { [dir '/bipolar__ICA__cross-corr/cross-corr__vs__cross-corr__vs__cross-corr__vs__cross-corr/' fig_choice '.fig'];
         [dir '/bipolar__ICA__cross-corr_no_symmetric/cross-corr_no_symmetric__vs__cross-corr_no_symmetric__vs__cross-corr_no_symmetric__vs__cross-corr_no_symmetric/' fig_choice '.fig']
       };
titles = {'Cross-correlation'; 'Corrected cross-correlation'};
legends = {'0.3' '0.4' '0.5' '0.6';
           '0.09' '0.12' '0.15' '0.18'};
figs_to_subplots(figs,titles,2,1,legends,[dir '/cross-corr__vs__cross-corr_no_symmetric_averagedegree_varying_thresholds']);

%% Cross-corr vs cross-corr_no_zero_lag, histograms
clear;
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]';
figs = { [dir '/bipolar__ICA__cross-corr_no_zero_lag/window=5/threshold=0.75/max-cross-corr_no_zero_lag-lag-indx.fig'];
         [dir '/bipolar__ICA__cross-corr/window=5/threshold=0.75/max-cross-corr-lag-indx.fig']
        };
titles = {'Cross-correlation'; 'Cross-correlation excluding zero-lags'};
      
figs_to_subplots(figs,titles,2,1,[dir '/subplot_hist_lag_indx']);

%% Coherence vs Imaginary coherence, varying network properties (broad band)
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/coherence_freq_bands__vs__imaginary_coherence_freq_bands/all bands';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; 'Clustering'};
legends = {'Coherence' 'Imaginary Coherence'};
figs_to_subplots(figs,titles,3,1,legends,[dir '/coherence__vs__imaginary_coherence_all_measures']);

%% Coherence vs Imaginary coherence, varying network properties in the theta and alpha bands
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/coherence_freq_bands__vs__imaginary_coherence_freq_bands/';
figs = { [dir 'theta band/average_degree_und1.fig'];
         [dir 'alpha band/average_degree_und1.fig'];
         [dir 'theta band/efficiency_bin1.fig'];
         [dir 'alpha band/efficiency_bin1.fig'];
         [dir 'theta band/network_clustering_WS_bu1.fig'];
         [dir 'alpha band/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree - Theta band'; 'Average Degree - Alpha band'; 'Efficiency - Theta band'; 'Efficiency - Alpha band'; 'Clustering - Theta band'; 'Clustering - Alpha band'};
legends = {'Coherence' 'Imaginary Coherence'};
figs_to_subplots(figs,titles,3,2,legends,[dir '/coherence__vs__imaginary_coherence_all_measures__alpha_theta']);

%% Coherence vs Imaginary coherence, efficiency and clustering in the theta and alpha bands
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/coherence_freq_bands__vs__imaginary_coherence_freq_bands/';
figs = { [dir 'theta band/efficiency_bin1.fig'];
         [dir 'alpha band/efficiency_bin1.fig'];
         [dir 'theta band/network_clustering_WS_bu1.fig'];
         [dir 'alpha band/network_clustering_WS_bu1.fig']
       };
titles = {'Efficiency - Theta band'; 'Efficiency - Alpha band'; 'Clustering - Theta band'; 'Clustering - Alpha band'};
legends = {'Coherence' 'Imaginary Coherence'};
figs_to_subplots(figs,titles,2,2,legends,[dir '/coherence__vs__imaginary_coherence__alpha_theta__efficiency_clustering']);

%% Coherence vs Imaginary coherence, varying network properties (all bands)
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/coherence_freq_bands__vs__imaginary_coherence_freq_bands/';
legends = {'Coherence' 'Imaginary Coherence'};
titles = {'Average Degree'; 'Efficiency'; 'Clustering'};
freqbands = {'all bands'; 'delta band'; 'theta band'; 'alpha band'; 'beta band'; 'gamma band' };

for i=1:6
    figs = { [dir '/' freqbands{i} '/average_degree_und1.fig'];
             [dir '/' freqbands{i} '/efficiency_bin1.fig'];
             [dir '/' freqbands{i} '/network_clustering_WS_bu1.fig']
           };
    figs_to_subplots(figs,titles,3,1,legends,[dir '/coherence__vs__imaginary_coherence_all_measures_' strrep(freqbands{i},' ','_')]);
end

%% Coherence vs Imaginary coherence, varying frequency bands
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/coherence_freq_bands__vs__imaginary_coherence_freq_bands/';
legends = {'Coherence' 'Imaginary Coherence'};
titles = {'Broadband (1-45Hz)'; 'Delta (1-4Hz)'; 'Theta (4-8Hz)'; 'Alpha (8-13Hz)'; 'Beta (13-30Hz)'; 'Gamma (30-45Hz)'};
freqbands = {'all bands'; 'delta band'; 'theta band'; 'alpha band'; 'beta band'; 'gamma band' };

figs = strcat(repmat(dir,6,1),freqbands,repmat('/average_degree_und1.fig',6,1));

figs_to_subplots(figs,titles,3,2,legends,[dir '/coherence__vs__imaginary_coherence__freq_bands__average_degree_und1']);

%% Mean Coherence vs Mean Imaginary coherence, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__mean_coherence/mean_coherence__vs__mean_imaginary_coherence';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; 'Clustering'};
legends = {'Coherence' 'Imaginary Coherence'};
figs_to_subplots(figs,titles,3,1,legends,[dir '/mean_coherence__vs__mean_imaginary_coherence_all_measures']);


%% PLI vs weighted PLI, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__pli/pli__vs__wpli';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; 'Clustering'};
legends = {'PLI' 'Weighted PLI'};
figs_to_subplots(figs,titles,3,1,legends,[dir '/pli__vs__wpli_all_measures']);

%% PLI vs weighted PLI, varying frequency bands
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA';
freqbands = { '';
          '_delta';
          '_theta';
          '_alpha';
          '_beta';
          '_gamma'
       };
figs = strcat(repmat(dir,6,1),freqbands,repmat('__pli/pli__vs__wpli/average_degree_und1.fig',6,1));

titles = {'Broadband (1-45Hz)'; 'Delta (1-4Hz)'; 'Theta (4-8Hz)'; 'Alpha (8-13Hz)'; 'Beta (13-30Hz)'; 'Gamma (30-45Hz)'};
legends = {'PLI' 'Weighted PLI'};
figs_to_subplots(figs,titles,3,2,legends,[dir '__pli/pli__vs__wpli/pli__vs__wpli__freq_bands']);


%% Median cross-corr as a function of lag
clear;
montages = {'bipolar'; 'ref'; 'avgref'};
m_titles = {'Bipolar'; 'Common ref.'; 'Average ref.'};   

for m = 1:3
    % Load the data
    datafile = ['/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/' montages{m} '__ICA__cross-corr/data.mat']
    load(datafile,'node_data');
    
%     data = node_data';
%     %clear node_data;
%     node_data = eegfilt(data,200,0,20);
%     node_data = node_data';
    
    % Compute correlations, normal and corrected
    wlength  = 60;
    srate    = 200;
    lag      = srate;
    [ndatapoints,nchannels] = size(node_data);
    nwindows = ndatapoints/(wlength*srate);
    ncorrs   = nwindows*(nchannels-1)*(nchannels-2)/2;

    correlations = zeros(nchannels,nchannels,2*lag+1,nwindows);
    %corrected_correlations = zeros(nchannels,nchannels,lag,nwindows);

    w = 1;
    for wstart=1:wlength*srate:ndatapoints
        wend = wstart + wlength*srate -1;
        for i = 1:nchannels
            for j=i+1:nchannels
                correlations(i,j,:,w) = xcov(node_data(wstart:wend,i),node_data(wstart:+wend,j),lag,'coeff');
                %corrected_correlations(i,j,:,w) = correlations(i,j,lag+2:2*lag+1,w) - 
            end
        end
        w = w +1;
    end
    
    % Plot one window per period (pre-, post-, ictal), average over channels
%     periods = [ floor(nwindows/4);
%                 floor(nwindows/2+10);
%                 floor(3*nwindows/4)];
    periods = [ floor(5);
                floor(16);
                floor(25)];
    p_titles = {'inter-ictal' 'ictal' 'post-ictal'}; 
    mean_corr_at_lag = zeros(2*lag+1,3);
    up_bound=mean_corr_at_lag;
    low_bound=mean_corr_at_lag;

    h = figure; hold all;
    for p = 1:3
        corr = correlations(:,:,:,periods(p));
        
        for i=1:2*lag+1
            corr_at_lag = corr(:,:,i);  % A single window for a lag
            corr_at_lag = corr_at_lag(itriu(size(corr_at_lag),1));  % vectorize upper triangular (non-zero) part
            rect_corr=abs(corr_at_lag);
            mean_corr_at_lag(i,p) = median(rect_corr);
            up_bound(i,p) = prctile(rect_corr,97.5);
            low_bound(i,p) = prctile(rect_corr,2.5);
        end
        plot(-lag:lag, mean_corr_at_lag(:,p)); 
%         plot(-lag:lag, up_bound(:,p),'k:'); 
%         plot(-lag:lag, low_bound(:,p),'k:'); 
    end
    legend(p_titles);
    title([m_titles{m} ' - Cross-correlation over lags']);
    xlabel('Lags');
    saveas(h,[strrep(datafile,'data.mat',[montages{m} '_cross_corr_over_lags']) '.jpg']);
%    close;
    
    h = figure; hold all;
    mean_corr_at_lag = zeros(lag,3);
    for p = 1:3
        corr1 = correlations(:,:,:,periods(p));
        corr = corr1(:,:,lag+2:2*lag+1) - flipdim(corr1(:,:,1:lag),3);
        for i=1:lag
            corr_at_lag = corr(:,:,i);  % A single window for a lag
            corr_at_lag = corr_at_lag(itriu(size(corr_at_lag),1));  % vectorize upper triangular (non-zero) part
            rect_corr=abs(corr_at_lag);
            mean_corr_at_lag(i,p) = median(rect_corr);
%             up_bound(i,p) = prctile(rect_corr,97.5);
%             low_bound(i,p) = prctile(rect_corr,2.5);
        end
        plot(1:lag, mean_corr_at_lag(:,p)); 
    end
    legend(p_titles);
    title([m_titles{m} ' - Corrected cross-correlation over lags']);
    xlabel('Lags');
    saveas(h,[strrep(datafile,'data.mat',[montages{m} '_corrected_cross_corr_over_lags']) '.jpg']);
%    close;

end

%% Plot channels individually, average over windows in the same range (pre-, post-, ictal)
% periods = [ 1     89;
%             180  210;
%             211 360];
periods = [ 1  30;
            180  210;
            230 260];

p_titles = {'preictal' 'ictal' 'postictal'}; 

for p = 1:3
    for i=1:nchannels
        for j=i+1:nchannels
            ii = int2str(i);
            jj = int2str(j);
            p1 = int2str(periods(p,1));
            p2 = int2str(periods(p,2));
            
            % Cross correlations
            varname = ['corr_' ii '_' jj '_' p_titles{p}];
            eval([varname ' = reshape(correlations(' ii ',' jj ',:,' p1 ':' p2 '),2*lag+1,' int2str(periods(p,2)-periods(p,1)+1) ');' ]);
            eval([varname '_mean = mean(' varname ',2);' ]);
            eval([varname '_std  = std(' varname ',0,2);' ]);
            
            h = figure;
            errorbar(-lag:lag,eval([varname '_mean']),eval([varname '_std'])); hold on;
            title(['Cross-corr as a function of lag: channels ' ii '-' jj ' ' p_titles{p}]);
            saveas(h,[strrep(datafile,'data.mat','cross_corr_over_lags/') varname '.jpg']);
            close;
            
            % Cross correlations without symmetric C(l)-C(-l)
            varname2 = ['nosymm' varname];
            eval([varname2 ' = ' varname '(lag+2:2*lag+1,:) - flipdim(' varname '(1:lag,:),1);']);
            
            eval([varname2 '_mean = mean(' varname2 ',2);' ]);
            eval([varname2 '_std  = std(' varname2 ',0,2);' ]);
            
            h = figure;
            errorbar(1:lag,eval([varname2 '_mean']),eval([varname2 '_std'])); hold on;
            title(['C(l)-C(-l) as a function of lag: channels ' ii '-' jj ' ' p_titles{p}]);
            saveas(h,[strrep(datafile,'data.mat','cross_corr_no_symmetric_over_lags/') varname2 '.jpg']);
            close;
            
            clearvars corr_* nosymmcorr_*;
        end
    end
end
%% DELETE
mean_corr_atlags = mean(correlations,2);
std_corr_atlags  = std(correlations,0,2);

h = figure;
errorbar(-lag:lag,mean_corr_atlags,std_corr_atlags); hold on;
plot(-lag:lag,mean_corr_atlags,'r','LineWidth',2);
title('Cross-corr as a function of lag');
saveas(h,[strrep(datafile,'data.mat','cross_corr_over_lags') '.jpg']);
%close;


%% By Avgis, corrected cross-corr
x = rand(1000,1);
y = rand(1000,1);
[c,l]=xcorr(x,y,'coef'); %% c is the cross-corralation coefficients across all lags, L is %all the lags [-lmax lmax]
C_corr=zeros(size(l,2),1);

for k=1:length(l)
    lag_var=l(k); %%this is the particular lag staring from the first one, which will be % negative (= -lmax)
    C_corr(k)= c(l==lag_var)- c(l==-lag_var);
end

lag = (size(l,2)-1)/2
C_corr2=zeros(size(l,2),1);
C_corr2(1:lag) = c(1:lag)-flipdim(c(lag+2:2*lag+1),1);
C_corr2(lag+1:2*lag+1) = c(lag+1:2*lag+1)-flipdim(c(1:lag+1),1);

assert(isequal(C_corr,C_corr2));

%% Plot network properties, average over windows in the same range (inter-, pre-, early ictal, late, early post-, late post-)
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__imaginary_coherence/data.mat';
load(datafile,'nets_w5','evstart','evend');
threshold = 0.75;
figdir = [strrep(datafile,'data.mat','window=5/threshold=') num2str(threshold) '/averages'];
network_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};

periods = [ 1  30;
            150 180
            180 190;
            200 210;
            220 250;
            330 360];
p_titles = {'Interictal' 'Preictal' 'Early ictal' 'Late ictal' 'Early postictal' 'Late postictal'}; 
nperiods = size(periods,1);

[nchannels,~,nwindows,nfreqbands] = size(nets_w5);

avg_nets_w5 = zeros(nchannels,nchannels,nperiods,nfreqbands);
%for f=1:nfreqbands
    for p=1:nperiods
%        avg_nets_w5(:,:,p,f) = mean(nets_w5(:,:,periods(p,1):periods(p,2),f),3);
        avg_nets_w5(:,:,p,:) = mean(nets_w5(:,:,periods(p,1):periods(p,2),:),3);
    end
%end

avg_nets = binarize(avg_nets_w5,threshold);
plot_all(avg_nets,5,seizstart,seizend,figdir,network_labels);

%% Average binary networks (adjacency matrices)
%datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_all_Export1/bipolar__f1-45__cross-corr/data.mat';
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_all_Export1/bipolar__f1-45__coherence_freq_bands/data.mat';
%datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_all_Export1/bipolar__f1-45__cross-corr/data.mat';
%datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_all_Export1/bipolar__f1-45__coherence_freq_bands/data.mat';

load(datafile,'nets_w5','evstart','evend');
threshold = 0.5;
avg_time = 3600; % sec
figdir = [strrep(datafile,'data.mat','window=5/threshold=') num2str(threshold) '/avg_bin_nets_' num2str(avg_time)];
    if ~exist(figdir,'dir')
        mkdir(figdir); 
    end

network_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};

bin_nets = binarize(nets_w5,threshold);
[nrows ncols nnets nfreq] = size(bin_nets);
mean_step = avg_time / 5;   % 5 sec windows
avg_bin_nets = zeros(nrows,ncols,ceil(nnets/mean_step));

for f=1:nfreq
    if nfreq>1
        figdir_sub = [figdir '/' network_labels{1,f}];
           
        if ~exist(figdir_sub,'dir')
            mkdir(figdir_sub); 
        end
    else
        figdir_sub = figdir;
    end

    for i=1:ceil(nnets/mean_step)
        avg_bin_nets(:,:,i) = mean(bin_nets(:,:,(i-1)*mean_step+1:min(i*mean_step,nnets),f),3);

        avg_bin_nets(:,:,i) = binarize(avg_bin_nets(:,:,i),0.5);
        %h = figure('visible','off');
        tmp_net = imresize(avg_bin_nets(:,:,i), 25, 'nearest');
        imwrite(tmp_net, [figdir_sub '/avg_bin_net' num2str(i) '.png']);
        %saveas(h, [figdir '/avg_bin_net' num2str(i) '.jpg']);
        %
        % spy(avg_bin_nets(:,:,i),15,'sk')
        %
        %imagesc((1:ncols)+0.5,(1:nrows)+0.5,avg_bin_nets(:,:,1));
        %colormap(gray); 
        %axis equal
        %set(gca,'XTick',1:(c+1),'YTick',1:(r+1),...  %# Change some axes properties
        %    'XLim',[1 c+1],'YLim',[1 r+1],...
        %    'GridLineStyle','-','XGrid','on','YGrid','on');
    end
end
disp('Done');

%% DELETE - Finds line discrepanses
[EDFdata, header] = ReadEDF('/home/epilepsy/Original_Data/new-patients/Mavromati Vasia, CING 5859/EDF Whole file 2nd event input montage.edf');
new_bipolar_data = edfdata_to_bipolar(EDFdata);

[EDFdata_bipolar, header_bipolar] = ReadEDF('/home/epilepsy/Original_Data/new-patients/Mavromati Vasia, CING 5859/EDF Whole file, includes 2nd patient event.edf');
bipolar_data = cell2mat(EDFdata_bipolar);

[EDFdata_bipolar1, header_bipolar1] = ReadEDF('/home/epilepsy/Original_Data/new-patients/Mavromati Vasia, CING 5859/EDF Whole file, includes 2nd patient event1.edf');
bipolar_data1 = cell2mat(EDFdata_bipolar1);

[EDFdata_bipolar2, header_bipolar2] = ReadEDF('/home/epilepsy/Original_Data/new-patients/Mavromati Vasia, CING 5859/EDF Whole file, includes 2nd patient event2.edf');
bipolar_data2 = cell2mat(EDFdata_bipolar2);

%% DELETE - Finds the first line in new_bipolar that almost matches bipolar1
for i=713900:800000
    if  isequal((new_bipolar_data(i,:) - bipolar_data1(1,:) > 1),zeros(1,23))
        disp(i);
    end
end

plot(new_bipolar_data(721001:721001+36500,1));
hold on;
plot(bipolar_data1(1:36500,1),'r');

%% DELETE - Finds the first line in new_bipolar that almost matches bipolar2
for i=757500:765000
    if  isequal((new_bipolar_data(i,:) - bipolar_data2(1,:) > 5),zeros(1,23))
        disp(i);
    end
end

%% DELETE - Finds line discrepanses - file event
count = 0;
for i=1:714000
    if  ~isequal((new_bipolar_data(i,:) - bipolar_data(i,:) > 5),zeros(1,23))
        count = count + 1; 
        disp(i);
    end
end
disp([num2str(count) ' discrepances found']);

%% DELETE - Finds line discrepanses - file event1 
count = 0;
for i=1:36500
    if  ~isequal((new_bipolar_data(721000+i,:) - bipolar_data1(i,:) > 5),zeros(1,23))
        count = count + 1; 
        disp(i);
    end
end
disp([num2str(count) ' discrepances found']);

%% DELETE - Finds line discrepanses - file event2
count = 0;
for i=1:size(bipolar_data2,1)
    if  ~isequal((new_bipolar_data(763527+i,:) - bipolar_data2(i,:) > 5),zeros(1,23))
        count = count + 1; 
        %disp(i);
    end
end
disp([num2str(count) ' discrepances found']);

%% Test signal periodicity using autocorrelation
%load('/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_all_Export1/bipolar__f1-45__cross-corr/data.mat');
%load('/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_all_Export1/bipolar__f1-45__cross-corr/data.mat');
load('/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1a/bipolar__f1-45__cross-corr/data.mat');
nets_bin = binarize(nets_w5,0.5);
fname = 'average_degree_und';
[~, ~, timemoments, networks] = size(nets_bin);

for t=1:timemoments
    for j=1:networks
       C(:,t,j) = feval(fname,nets_bin(:,:,t,j));
    end
end

C2 = C - mean(C,2);
figure;
plot(xcorr(C2(1,:,1), 'unbiased'))

%%
Y = fft(C(1,:,1));
periodLength = '5 second'; %or whatever units your signal was acquired in.
N = length(Y);
Y(1) = [];
power = abs(Y(1:floor(N/2))).^2;
nyquist = 1/2;
freq = (1:floor(N/2))/floor(N/2)*nyquist;
figure;
plot(freq,power)
grid on
xlabel(['cycles/' periodLength]);
title('Frequency plot');

%%
period = 1./freq;
figure;
plot(period,power)
grid on
ylabel('Power')
xlabel(['Period (' periodLength 's/Cycle)']);
title('Period Plot');


%% Periodicity
load('/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_all_Export1/bipolar__f1-45__cross-corr/data.mat','nets_w5');
threshold =0.5
property = 'average_degree_und';
nets_bin = binarize(nets_w5,threshold);
[~, ~, timemoments, networks] = size(nets_bin);
for t=1:timemoments
    for j=1:networks
        C(:,t,j) = feval(property,nets_bin(:,:,t,j));
    end
end
j=1;
C2 = C(:,:,j) - mean(C(:,:,j),2);
C3 = C2(:);

%% Present long data (allows scrolling on the x-axis)
figure
plot(1:10000)
pan xon

%% Process long-term new data (one off)
edf_unipolar_to_bipolar_datamat('/home/epilepsy/Original_Data/new-patients/Ralli Chloe CING 4337/t2 input montage.edf','/home/manolisc/epilepsy/Exports/RC-4337/seizure_t2_unipolar2bipolar.mat')
edf_unipolar_to_bipolar_datamat('/home/epilepsy/Original_Data/new-patients/Gregoriou Marios 10837/t1 input montage.edf','/home/manolisc/epilepsy/Exports/GM-10837/seizure_t1_unipolar2bipolar.mat')

testing_measures('/home/manolisc/epilepsy/Exports/RC-4337','t1_unipolar2bipolar','bipolar','cross-corr','f1-45',0.75)
testing_measures('/home/manolisc/epilepsy/Exports/RC-4337','t2_unipolar2bipolar','bipolar','cross-corr','f1-45',0.75)
testing_measures('/home/manolisc/epilepsy/Exports/GM-10837','t1_unipolar2bipolar','bipolar','cross-corr','f1-45',0.75)

%% Convert XLTEK data to new universal format

% === Input parameters. Provide the RAW_DATA file (!) annotated with
% === recording time!
dir         = '/home/epilepsy/Exports/XLTEK/HE-bb167/RAW_DATA';
infile      = [dir '/' 'Export1.txt'];
annotfile   = [dir '/' 'final_annotations_with_sleep.txt'];
mfile       = strrep(infile,'.txt','.mat');
srate       = 200;
montage     = 'unipolar';
channel_labels = {'AC1'; 'AC2'; 'Ref'; 'Fp1'; 'F7'; 'T3'; 'T5'; '01'; ...
                  'F3'; 'C3'; 'P3'; 'Fz'; 'Cz'; 'Pz'; 'F4'; 'C4'; 'P4'; ...
                  'Fp2'; 'F8'; 'T4'; 'T6'; '02'; 'AC23'; 'AC24'; ...
                  'AC25'; 'AC26'; 'AC27'; 'AC28'; 'AC29'; 'AC30'; ...
                  'AC31'; 'AC32'; 'DC1'; 'DC2'; 'DC3'; 'DC4'};
% === Import the data
% Read data from the file. AMPSAT and OFF are treated as NaN!
txtFID      = fopen(infile); 
headerlines = 15;
textData    = textscan(txtFID,'%d/%d/%d %d:%d:%2d.%d %*u%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%*s','HeaderLines',headerlines,'CommentStyle','---','TreatAsEmpty',{'AMPSAT';'OFF'}); 
fclose(txtFID);

% Get rid of last row if incomplete 
last_row = numel(textData{43});

tic
orig_data  = [textData{8}(1:last_row) textData{9}(1:last_row) ... 
              textData{10}(1:last_row) textData{11}(1:last_row)... 
              textData{12}(1:last_row) textData{13}(1:last_row) ...
              textData{14}(1:last_row) textData{15}(1:last_row) ...
              textData{16}(1:last_row) textData{17}(1:last_row) ...
              textData{18}(1:last_row) textData{19}(1:last_row) ...
              textData{20}(1:last_row) textData{21}(1:last_row) ...
              textData{22}(1:last_row) textData{23}(1:last_row) ...
              textData{24}(1:last_row) textData{25}(1:last_row) ... 
              textData{26}(1:last_row) textData{27}(1:last_row) ...
              textData{28}(1:last_row) textData{29}(1:last_row) ... 
              textData{30}(1:last_row) textData{31}(1:last_row) ...
              textData{32}(1:last_row) textData{33}(1:last_row) ...
              textData{34}(1:last_row) textData{35}(1:last_row) ...
              textData{36}(1:last_row) textData{37}(1:last_row) ...
              textData{38}(1:last_row) textData{39}(1:last_row) ...
              textData{40}(1:last_row) textData{41}(1:last_row) ... 
              textData{42}(1:last_row) textData{43}(1:last_row) ];
toc
tic
orig_times = [textData{4}(1:last_row) textData{5}(1:last_row) ...
              textData{6}(1:last_row) textData{7}(1:last_row)];
toc
          
startdate = [textData{3}(1) textData{1}(1) textData{2}(1)];

save(strrep(mfile,'.mat','_intermediate.mat'),'orig_data','orig_times','srate','montage','startdate','channel_labels','-v7.3');

% Check data times' uniqueness
[data times] = xltek_fix_broken_data(orig_data,orig_times)
% Alternative
%[uniques,numUnique] = count_unique(times);

save(mfile,'data','times','srate','montage','startdate','channel_labels','-v7.3');

% For daytime time
% str_start_date = textData{1}{1};
% str_start_time = textData{2}{1};
% startdate = [str2num(str_start_date(9:10)); str2num(str_start_date(4:5)); str2num(str_start_date(1:2))];
% starttime = [str2num(str_start_time(1:2)); str2num(str_start_time(4:5)); str2num(str_start_time(7:8))];

% For recording time
% str_start_date = textData{1}{1};
% startdate = [str2num(str_start_date(9:10)); str2num(str_start_date(1:2)); str2num(str_start_date(4:5))];
% 
% times2 = regexp(textData{2}, '[:.]', 'split');
% times = cell2mat(cellfun(@(x) cellfun(@str2num,x),times2,'Un',0));
% 
% save(matfile,'times','-append');

clear textData;

annotFID     = fopen(annotfile); 
starttime    = cell2mat(textscan(annotFID,'%*s %*s %n:%n:%n %*[^\n]',1,'HeaderLines',3)); 
starttime(4) = 0;
starttime    = time_add(starttime,times(1,:))
annot        = textscan(annotFID,' %d:%d:%2d.%d %[^\n]','headerlines',1);
annot_times  = [annot{1} annot{2} annot{3} annot{4}];
annot_events = annot{5};
fclose(annotFID);

seizstart_times    = annot_times(find(ismember(annot_events,'start')),:)
seizend_times      = annot_times(find(ismember(annot_events,'end')),:)
sleepstart_times = annot_times(find(ismember(annot_events,'Sleep Start')),:)
sleepend_times   = annot_times(find(ismember(annot_events,'Sleep End')),:)

seizstart = time_diffs_to_index(seizstart_times,times(1,:));
assert(isequal(times(seizstart,:),seizstart_times))
seizend = time_diffs_to_index(seizend_times,times(1,:));
assert(isequal(times(seizend,:),seizend_times))
sleepstart = time_diffs_to_index(sleepstart_times,times(1,:));
assert(isequal(times(sleepstart,:),sleepstart_times))
sleepend = time_diffs_to_index(sleepend_times,times(1,:));
assert(isequal(times(sleepend,:),sleepend_times))



% % Import annotation data (again in daytime format)
% % Cell array of 2 cols, time (string, in hh.mm.ss.xxx) and event (string)
% % annot = import_annotations(annotfile);
% % Locate events in the second column, and get their corresponding
% % time(s) of occurrence in the first column (in hh.mm.ss.xxx)
% stimes = annot(strcmp(annot(:, 2), 'start'));
% etimes = annot(strcmp(annot(:, 2), 'end'));
% % Find the same times in the indices of the data and get the row they
% % correspond to in the data (thus, event times in samples)
% [~,~,evstart] = intersect(stimes,times);
% [~,~,evend] = intersect(etimes,times);
% %event_times = evidx/srate;
% % Replace above with:
% xltek_annot_extract_events('/home/epilepsy/Exports/XLTEK/II-9fee1/RAW_DATA/annotations_daytime_sleep.txt'

%save(matfile,'-v7.3','data','srate','evstart','evend','starttime','startdate','montage');
save(mfile,'starttime','annot_times','annot_events','seizstart','seizend',...
     'sleepstart','sleepend','-append');
 
% Combine multiple data and times
matcombfile = [dir '/Export1-2.mat'];
matcomb = matfile(matcombfile,'Writable',true);
mat1 = matfile([dir '/Export1.mat'])
mat2 = matfile([dir '/Export2.mat'])
mat3 = matfile([dir '/Export2b.mat'])
% Check that there is no gap between the data
n1 = size(mat1.times,1);
rows_missing = time_diffs_to_index(mat2.times(1,:),mat1.times(n1,:)) - 2
times_temp = time_add(mat1.times(n1,:),[0 0 0 1000/srate])
for i=2:rows_missing
    times_temp(end+1,:) = time_add(times_temp(end,:),[0 0 0 1000/srate]);
end
times_temp
data_temp = nan(rows_missing,36);
% Combine into one variable
matcomb.data = [mat1.data; data_temp; mat2.data]; % mat3.data];
matcomb.times = [mat1.times; times_temp; mat2.times]; %; mat3.times];
n = size(matcomb.times,1);
assert(isequal(size(matcomb.data,1),n))
test = time_diff(matcomb.times(n,:),matcomb.times(1,:));
assert((test(1)*3600+test(2)*60+test(3))*200+test(4)/5+1 == n)
% Load the remaining variables from the first file
load([dir '/Export1.mat'],'srate','montage','startdate','channel_labels')
% Save to new file
save(matcombfile,'srate','montage','startdate','channel_labels','starttime','annot_times','annot_events','seizstart','seizend',...
     'sleepstart','sleepend','-append');

%% Test fix the XLTEK data, where broken
dir         = '/home/epilepsy/Exports/DP-98304';
%infile      = [dir '/' 'test_break.txt'];
infile      = [dir '/RAW_DATA/' 'Export1_daytime.txt'];

txtFID      = fopen(infile); 
textData    = textscan(txtFID,'%s%s%*u%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%n%*s','HeaderLines',15,'CommentStyle','---','TreatAsEmpty',{'AMPSAT';'OFF'}); 
fclose(txtFID);

times       = textData{2};
data        = cell2mat(textData(3:end));

%xltek_fix_broken_data(data,times)

% DELETE
% tic; unique_times = unique(times);
% y = zeros(size(times));
% for i = 1:100 %length(unique_times)
% y(i) =  numel(find(strcmp(unique_times{i}, times)));
% end
% toc;

%
dates_times = [textData{1} textData{2}];
srate = 200;
tic; [uniques,numUnique] = count_unique(dates_times); toc
uniques_indices = find(numUnique ~= srate);

%% Nicolet - Full-day files in input montage, annotated with FT, to new universal format

    % Load the data
    export_dir      = '/home/epilepsy/Exports/Nicolet/GM-10837/';
    ft_dir          = '/home/epilepsy/fieldtrip/Gregoriou Marios 10837/';
    edf_dir         = '/home/epilepsy/Original_Data/new-patients/Gregoriou Marios 10837/';
    filename        = 't1 input montage';

    %load([ft_dir filename '_data.mat']);
    
    % Copy the data
    ftdata          = data;
    srate           = ftdata.fsample;
    montage         = 'unipolar';
    channel_labels  = {'Fp1'; 'Fp2';  'F3';  'F4';  'C3'; 'C4'; ...
                        'P3';  'P4';  '01';  '02';  'F7'; 'F8'; ...
                        'T3';  'T4';  'T5';  'T6';  'A1'; 'A2'; ...
                        'Fz';  'Cz';  'Pz'; 'ROC'; 'LOC'; '24'; ...
                        'T1';  'T2'; 'EMG'; 'EKG'; 'Photic'};
    if ftdata.hdr.nChans==28
        channel_labels = [channel_labels(1:23); channel_labels(25:end)];
    end
    data            = cell2mat(ftdata.trial)';
    assert(size(data,1) == size(ftdata.trial,2)*srate);
    assert(size(data,2) == ftdata.hdr.nChans);
    % Test
    %i=1020; j=20; assert(isequal(data(i,j),ftdata.trial{ceil(i/500)}(j,mod(i,500))))
    
    startdate       =  ftdata.hdr.orig.T0(1:3);
    starttime       = [ftdata.hdr.orig.T0(4:6) 0];
    clear ftdata;
    
    % Copy the events and artifacts
    if exist([ft_dir filename '_seizures-and-artifacts.mat'],'file')
        load([ft_dir filename '_seizures-and-artifacts.mat']);
        
        seizstart       = cfg.artfctdef.seizure.artifact(1:2:size(cfg.artfctdef.seizure.artifact,1),1);
        seizend         = cfg.artfctdef.seizure.artifact(2:2:size(cfg.artfctdef.seizure.artifact,1),1);
        assert(isequal(size(seizstart),size(seizend)));

        artifactstart   = cfg.artfctdef.artifacts.artifact(1:2:size(cfg.artfctdef.artifacts.artifact,1),1);
        artifactend     = cfg.artfctdef.artifacts.artifact(2:2:size(cfg.artfctdef.artifacts.artifact,1),1);
    else
        seizstart       = [];
        seizend         = [];
        artifactstart   = [];
        artifactend     = [];
    end
    
    % Save
    if ~exist(export_dir,'dir')
        mkdir(export_dir); 
    end
    save([export_dir filename '.mat' ],'srate','montage','channel_labels', ...
         'data', 'startdate','starttime','seizstart','seizend', ...
         'artifactstart','artifactend','-v7.3');

%% Nicolet - Full-day files in input montage to new universal format (no FT!)
    clear 
    
    % Load the data
    export_dir      = '/home/epilepsy/Exports/Nicolet/KC-11561/';
    edf_dir         = '/home/epilepsy/Original_Data/new-patients/Koskosis Christodoulos CING 11561/';
    filename        = 'Day 2 EDF input montage';
    [edfdata, header] = ReadEDF([edf_dir filename '.edf']);
    %[header, edfdata] = edfread([edf_dir filename '.edf']); data = edfdata(1:32,:)';
    
    % Copy the data
    data            = cell2mat(edfdata(1:32));
    srate           = header.samplerate(1);
    montage         = 'unipolar';
%     channel_labels  = {'Fp1'; 'Fp2';  'F3';  'F4';  'C3'; 'C4'; ...
%                         'P3';  'P4';  '01';  '02';  'F7'; 'F8'; ...
%                         'T3';  'T4';  'T5';  'T6';  'A1'; 'A2'; ...
%                         'Fz';  'Cz';  'Pz'; 'ROC'; 'LOC'; '24'; ...
%                         'T1';  'T2'; 'EMG'; 'EKG'; 'Photic'};
    channel_labels  = {'Fp1'; 'Fp2';  'F3';  'F4';  'C3'; 'C4'; ...
                        'P3';  'P4';  '01';  '02';  'F7'; 'F8'; ...
                        'T3';  'T4';  'T5';  'T6';  'A1'; 'A2'; ...
                        'Fz';  'Cz';  'Pz'; 'ROC'; 'LOC'; 'EMG Right_Leg'; ...
                        'EMG Abdomen'; 'EMG Left_Leg'; 'EMG Chin'; ...
                        'EMG'; 'EKG'; 'EMG Nose'; 'EMG Oral'; 'EMG Thorax'};
    
    startdate       = [str2num(header.startdate(7:8)) ...
                       str2num(header.startdate(4:5)) ...
                       str2num(header.startdate(1:2))];
    starttime       = [str2num(header.starttime(1:2)) ...
                       str2num(header.starttime(4:5)) ...
                       str2num(header.starttime(7:8)) 0];
    
    seizstart       = [];
    seizend         = [];
    sleepstart      = [];
    sleepend        = [];
    
    % Save
    if ~exist(export_dir,'dir')
        mkdir(export_dir); 
    end
    save([export_dir filename '.mat' ],'srate','montage','channel_labels', ...
         'data', 'startdate','starttime','-v7.3');

    %% Resave data from edf in mat file
    oldmat  = '';
    newmat  = '/home/epilepsy/Exports/Nicolet/RC-4337/t1 input montage.mat';
    edffile = '/home/epilepsy/Original_Data/new-patients/Ralli Chloe CING 4337/t1 input montage.edf';
    
    [edfdata, header] = ReadEDF(edffile);
    data = cell2mat(edfdata);
    save(newmat,'data','-v7.3')
    
    load(oldmat,'artifactend','artifactstart','channel_labels',...
         'montage','seizend','seizstart','sleepend','sleepstart',...
         'srate','startdate','starttime');
    save(newmat,'artifactend','artifactstart','channel_labels',...
         'montage','seizend','seizstart','sleepend','sleepstart',...
         'srate','startdate','starttime','-append');

%% Merge Nicolet files

    % Get the files
    dir             = '/home/epilepsy/Exports/Nicolet/KC-11561/';
    tempfile        = [dir 'temp.mat'];
    combfile        = [dir 'Export1-2b.mat'];
    
    mtemp           = matfile(tempfile,'Writable',true);
    m1              = matfile([dir 'EDF file input montage Day 1.mat']);
    m2              = matfile([dir 'Day 2 EDF input montage.mat']);
    
    % Calculate gap between the data
    info1           = whos(m1,'data');
    n1              = info1.size(1)
    info2           = whos(m2,'data');
    n2              = info2.size(1)
    assert(info1.size(2)==info2.size(2))
    nchans          = info1.size(2)
    m1.startdate
    m1.starttime
    m2.startdate
    m2.starttime
    
    m1_endtime      = time_add(m1.starttime,index_to_time(n1,500));
    m1_endtime(1)   = mod(m1_endtime(1),24)
    rows_missing    = time_diffs_to_index(m2.starttime,m1_endtime,500)-1
    
    % Merge the two data matrices
    if rows_missing>0
        gap         = NaN(rows_missing,nchans);
    else
        gap         = [];
    end
    %mcomb.data      = [m1.data; gap; m2.data];
    %mcomb.data      = NaN(n1+n2+rows_missing,nchans);

%     mcomb.data(1:n1,:) = m1.data; 
%     mcomb.data(n1+1:n1+rows_missing,:) = gap; 
    mtemp.data(1:n1+rows_missing,1:32) = [m1.data; gap]; 
    mtemp.data(n1+rows_missing+1:n1+rows_missing+n2,1:32) = m2.data;
    load(tempfile)
    save(combfile,'data','-v7.3');
    
    mcomb = matfile(combfile,'Writable',true);
    
    % Merge event indices
    mcomb.seizstart = [m1.seizstart; n1+rows_missing+m2.seizstart];
    mcomb.seizend   = [m1.seizend;   n1+rows_missing+m2.seizend];
    mcomb.sleepstart = [m1.sleepstart; n1+rows_missing+m2.sleepstart];
    mcomb.sleepend   = [m1.sleepend;   n1+rows_missing+m2.sleepend];
    mcomb.artifactstart = [m1.artifactstart; n1+rows_missing+m2.artifactstart];
    mcomb.artifactend   = [m1.artifactend;   n1+rows_missing+m2.artifactend];
    %mcomb.seizstart  = []; mcomb.seizend  = []; 
    %mcomb.sleepstart = []; mcomb.sleepend = [];
    
    % Copy the remaining, common data
    mcomb.srate     = m1.srate;
    mcomb.montage   = m1.montage;
    mcomb.startdate = m1.startdate;
    mcomb.starttime = m1.starttime;
    mcomb.channel_labels = m1.channel_labels;  
    
    %n = size(mcomb.times,1);
    %assert(isequal(size(mcomb.data,1),n))
    %test = time_diff(mcomb.times(n,:),mcomb.times(1,:));
    %assert((test(1)*3600+test(2)*60+test(3))*200+test(4)/5+1 == n)
    
    % Load the remaining variables from the first file
%     load([dir '/Export1.mat'],'srate','montage','startdate','channel_labels')
    % Save to new file
%     save(mcombfile,'srate','montage','startdate','channel_labels','starttime','annot_times','annot_events','seizstart','seizend','sleepstart','sleepend','-append');


%% Append meta-data to mat files in the new universal format
mfile   = '/home/manolisc/epilepsy/Exports/RC-4337/seizure_t2_unipolar2bipolar.mat';
edffile   = '/home/epilepsy/Original_Data/new-patients/Ralli Chloe CING 4337/t2 input montage.edf';
ftfile    = '';
montage   = 'bipolar';

header    = readEDF_header_only(edffile);
%load(ftfile)

%evstart   = cfg.artfctdef.seizure.artifact(1:2:end,1);
%evend     = cfg.artfctdef.seizure.artifact(2:2:end,1);

starttime = [str2num(header.starttime(1:2)); str2num(header.starttime(4:5)); str2num(header.starttime(7:8))]
startdate = [str2num(header.startdate(7:8)); str2num(header.startdate(4:5)); str2num(header.startdate(1:2))]

%save(matfile,'starttime','startdate','evstart','evend','montage','-append')
save(mfile,'starttime','startdate','montage','-append')

eval(['whos -file ' mfile])


%% Combine very large files that have been split and contain consequtive data
% Files must be 'data.mat' containing variables: nets_w5, indx, evstart, evend
% infile1 = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2a/bipolar__f1-45__coherence_freq_bands/data.mat';
% infile2 = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2b/bipolar__f1-45__coherence_freq_bands/data.mat';
% outdir = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2_combined/bipolar__f1-45__coherence_freq_bands';

infile1 = '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1a/bipolar__f1-45__coherence_freq_bands/data.mat';
infile2 = '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1b/bipolar__f1-45__coherence_freq_bands/data.mat';
outdir = '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1_combined/bipolar__f1-45__coherence_freq_bands';

load(infile1); nets1 = nets_w5; indx1 = indx; evstart1 = seizstart; evend1 = seizend; n1 = size(nets_w5,3);
load(infile2); nets2 = nets_w5; indx2 = indx; evstart2 = seizstart; evend2 = seizend;

nets_w5 = cat(3,nets1,nets2);
indx = cat(3,indx1,indx2);
seizstart = cat(1,evstart1,evstart2+n1*5);
seizend = cat(1,evend1,evend2+n1*5);

if ~exist(outdir,'dir')
        mkdir(outdir); 
end
save([outdir '/data.mat'],'nets_w5','indx','evstart','evend');

%% (Re-)save ica'd data together with their relevant info
    clear

    dir      = '/home/epilepsy/Exports/XLTEK/HE-bb167/CLEAN_DATA/';
    ica_dir  = '/home/manast09/big_files/HE/ICA_nofilt/';
    filename = 'Export1-2';
    whos('-file',[dir filename '.mat'])

    load([ica_dir filename '_ica.mat'])
    %load([dir filename '.mat'],'-regexp','^(?!data)\w')
    load([dir filename '.mat'])

    %data = data';
    n = size(data,1);
%     data_new            = zeros(n,28);
%     data_new(1:n,1:3)  = [ica_data(:,1:2) data(:,3)];
%     data_new(1:n,4:22)  = ica_data(:,3:21);
%     data_new(1:n,23:26) = data(:,23:26);
%     data_new(1:n,27:28) = ica_data(:,22:23);
    
    icamat = matfile([dir filename '_ica.mat'],'Writable',true);
%     icamat.data(1:n,1:3)  = [ica_data(:,1:2) data(:,3)];
%     icamat.data(1:n,4:12)  = ica_data(:,3:11);
%     icamat.data(1:n,13:22) = ica_data(:,12:21);
%     icamat.data(1:n,23:26) = data(:,23:26);
%     icamat.data(1:n,27:28) = ica_data(:,22:23);
    step = 10000000;
    for i=1:floor(n/step)
        i
        l1 = (i-1)*step+1;
        l2 = min(i*step,n);
        icamat.data(l1:l2,1:28) = [ ica_data(l1:l2,1:2) ...
                                    data(l1:l2,3) ...
                                    ica_data(l1:l2,3:21) ...
                                    data(l1:l2,23:26) ...
                                    ica_data(l1:l2,22:23) ];
    end
    
    t = 500:700;
    i = 20; figure; plot(data(t,i)-mean(data(t,i)),'b'); hold on; plot(icamat.data(t,i),'r')
    i = 28; figure; plot(data(t,i)-mean(data(t,i)),'b'); hold on; plot(icamat.data(t,i),'r')
    i = 1; figure; plot(data(t,i)-mean(data(t,i)),'b'); hold on; plot(icamat.data(t,i),'r')
    i = 4; figure; plot(data(t,i)-mean(data(t,i)),'b'); hold on; plot(icamat.data(t,i),'r')
    i = 3; figure; plot(data(t,i),'b'); hold on; plot(icamat.data(t,i),'r')
    i = 23; figure; plot(data(t,i),'b'); hold on; plot(icamat.data(t,i),'r')
%     data            = data_new;
    channel_labels  = channel_labels(1:28);
    filtering       = 'ica';
    clear annot ica_data data_new i t n data;
    
    
    tic; save([dir filename '_ica.mat'],'-regexp','^(?!dir|filename|ica_dir|icamat)\w','-append'); toc/60
    whos('-file',[dir filename '.mat'])
    whos('-file',[dir filename '_ica.mat'])



%% Compute periodicities for all long-duration data
experiments = {'bipolar__f1-45__cross-corr';
               'bipolar__f1-45__cross-corr_no_symmetric'; 
               'bipolar__f1-45__wpli';
               'bipolar__f1-45__coherence_freq_bands';
              };
thresholds  = [0.65; 
               0.35; 
               0.8;
               0.65];
property   = {'average_degree_und'; 'efficiency_bin'; 'network_clustering_WS_bu'};
% data = {['/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_all_Export1/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_all_Export1/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1_combined/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export1/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2_combined/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935/seizure_all_Export1/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935/seizure_all_Export2/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/Export-DP-98304/seizure_all_Export1_bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/GM-10837/seizure_t1_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/MV-5859/seizure_1_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/MV-5859/seizure_2_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/RC-4337/seizure_t1_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/RC-4337/seizure_t2_unipolar2bipolar/' experiment '/data.mat'];
% };

long_seiz_mat = {'/home/manolisc/epilepsy/Exports/II-9fee1' 'Export1';
                 '/home/manolisc/epilepsy/Exports/MC-95a3a' 'Export1';
                 '/home/manolisc/epilepsy/Exports/TK-c840d' 'Export1';
                 '/home/manolisc/epilepsy/Exports/HE-bb167' 'Export1-2';
                 '/home/manolisc/epilepsy/Exports/MG-f84c1' 'Export1-2part';
                 '/home/manolisc/epilepsy/Exports/DP-98304' 'Export1';
                 '/home/manolisc/epilepsy/Exports/GM-10837' 'Export1';
                 '/home/manolisc/epilepsy/Exports/MV-5859'  'Export1-2';
                 '/home/manolisc/epilepsy/Exports/RC-4337'  'Export1-2';
%         ['/home/manolisc/epilepsy/Exports/GM-10837/seizure_t1_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/MV-5859/seizure_1_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/MV-5859/seizure_2_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/RC-4337/seizure_t1_unipolar2bipolar/' experiment '/data.mat'];
%         ['/home/manolisc/epilepsy/Exports/RC-4337/seizure_t2_unipolar2bipolar/' experiment '/data.mat'];
};


% Property periodicity
for e=1
    for i=9%1:size(long_seiz_mat,1)
        for j=1:size(property,1)
            periodicity_netsw_netproperty(long_seiz_mat{i,1},long_seiz_mat{i,2},experiments{e},property{j},thresholds(e))
        end
    end
end

%% Graph edit distance periodicity
for i=[2 3 5 6]%9:size(data,1)
    tic
    periodicity_netsw_edit_distance(long_seiz_mat{i,1},long_seiz_mat{i,2},experiments{e},thresholds(e));
    toc
end



%% Fix XLTEK data of long duration
init_dir = '/home/manolisc/epilepsy/Exports/';
patients = {'focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_all_Export1/';
        'focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_all_Export1/';
        'focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1a/';
        'focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1b/';
        'focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa/seizure_all_Export1_combined/';
        'Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export1/' ;
        'Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2a/';
        'Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2b/';
        'Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_all_Export2_combined/';
        'Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935/seizure_all_Export1/';
        'Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935/seizure_all_Export2/'
};
experiments = { 'bipolar__f1-45__cross-corr/'; 
                'bipolar__f1-45__coherence_freq_bands/'; 
                'bipolar__f1-45__pli/'};
filename = 'data.mat';

n = numel(patients);
m = 1;%numel(experiments);
[ii,jj] = ndgrid(1:n, 1:m);
%R = [patients(ii(:)) experiments(jj(:))]
data =reshape(strcat(init_dir,patients(ii(:)),experiments(jj(:)),filename),n*m,1);

for i=1:numel(data)
    if exist(data{i},'file')
        data{i}
        whos('-file', data{i})
%        srate = 200;
%        load(data{i},'evstart','evend');
        %evstart = evstart .* srate
%        evstart/(srate*3600)
        %evend = evend .* srate
        %save(data{i},'evstart','evend','srate','-append')
    end
end
%% Graph Edit distance between random graphs
n = 18; % Number of nodes
n_graphs = 20; % Number of random graphs

dist = zeros(9,1);
for p=1:9
    for g=1:n_graphs
       A = random_graph(n,p/10);
       B = random_graph(n,p/10);
       dist(p) = dist(p) + graph_edit_distance_test(A,B);
    end
    dist(p) = dist(p)/n_graphs;
%    draw_brain_network(A,'bipolar');
%    draw_brain_network(B,'bipolar');
end
dist
plot(0.1:0.1:0.9,dist)


%% Annotating long-duration plots (DELETE, has been incorporated in periodicity_netsw_netproperty)

    % Initialize
    filename    = '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_Export1/bipolar__f1-45__cross-corr/data.mat';
    %filename    = '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa/seizure_Export1-2/bipolar__f1-45__cross-corr/data.mat';
    %metadata_file = '/home/epilepsy/Exports/XLTEK/II-9fee1/CLEAN_DATA/Export1.mat';
    properties  = {'average_degree_und'; 'efficiency_bin'; 'network_clustering_WS_bu'};
    property    = properties{3};
    threshold   = 0.65;
    figdir      = strrep(filename,'data.mat',['threshold=' num2str(threshold) '/']);
    
    % Load the data
    load(filename,'srate','starttime','seizstart','seizend','sleepstart','sleepend','nets_w5')
    %load(metadata_file,'starttime','seizstart','seizend','sleepstart','sleepend');
    [~, ~, timemoments, networks] = size(nets_w5);

    % Titling
    patient_title = patient_to_str_public(filename);
    property_title = fname_to_str(property);

%     strstarttime = '09:31:05';
%     strstartdate = '06/27/2011';
%     starttime = [str2num(strstarttime(1:2)); str2num(strstarttime(4:5)); str2num(strstarttime(7:8))]
%     startdate = [str2num(strstartdate(7:10)); str2num(strstartdate(1:2)); str2num(strstartdate(4:5))]
    x_axis_start_hour = (double(starttime(1))+double(starttime(2))/60+double(starttime(3))/3600);
    if  exist('starttime','var')
        x_axis_values = x_axis_start_hour + [5/3600:5/3600:timemoments*5/3600];     % Set the time scale to hours
        %x_axis_values = [5/3600:5/3600:timemoments*5/3600];
        %x_axis_values2 = mod(x_axis_values + , 24);
        x_axis_title = '24h time';
    else
        x_axis_values = [5/3600:5/3600:timemoments*5/3600];     % Set the time scale to hours
        x_axis_title = 'Time (hours)';
    end
    x_axis_values_per = [-(timemoments-1)*5/3600:5/3600:(timemoments-1)*5/3600];
    net_filename = '';
    net_title = '';

% Calc property and smooth
nets_bin = binarize(nets_w5,threshold);
C = zeros(timemoments,1);
for t=1:timemoments
    for j=1:networks
        C(t) = feval(property,nets_bin(:,:,t,j));
    end
end
C3 = remove_mean(C,0.98);
C3 = C3'+min(C3);

% Plot

% Plot data
g = figure;
plot(x_axis_values,C3); 
xlim([x_axis_values(1) x_axis_values(end)+0.5])
xt = get(gca,'xtick'); xt = mod(xt,24); 
%set(gca,'xtick',xt);
%set(gca,'XTickLabel',cellstr(num2str(x_axis_values2')));
set(gca,'xticklabel',cellstr(num2str(mod(xt',24))));

%plot(x_axis_values2', C3);
hold on;
title([patient_title ' - ' property_title]);% ' ' net_title]);
xlabel(x_axis_title);
for e=x_axis_start_hour+seizstart/(srate*3600)
    arrayfun(@(e) add_vline(e,'--'),e);
end

% Plot sleep
lims = ylim;
s = fill((x_axis_start_hour+[sleepstart sleepstart sleepend sleepend]./(srate*3600))', ...
         repmat([lims lims(end:-1:1)]',1,size(sleepstart,1)), [.75 .75 .75],...
         'EdgeColor','None');

uistack(s,'bottom');
    set(findall(gcf,'type','text'),'fontSize',24) 
    set(findall(gcf,'type','axes'),'fontsize',14)
    
     if ~exist(figdir,'dir')
        mkdir(figdir); 
    end

saveas(g, [figdir property '.jpg']);


%% Clusters
%load('/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_19_56_36_820_[-15min_+15min]/bipolar__f1-50__cross-corr/data.mat')
load('/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935/seizure_36_43_57_265_[-15min_+15min]/bipolar__f1-50__cross-corr/data.mat')
channel_labels = {'Fp1-F7';'F7-T3';'T3-T5';'T5-O1';'Fp2-F8';...
                          'F8-T4';'T4-T6';'T6-O2';'Fp1-F3';'F3-C3';...
                          'C3-P3';'P3-O1';'Fp2-F4';'F4-C4';'C4-P4';...
                          'P4-O2';'Fz-Cz';'Cz-Pz'};
test18 = nets_w5(:,:,18);
y18 = squareform(test18);
Z18 = linkage(1-y18);
dendrogram(Z18,'Labels',channel_labels)

nnets = size(nets_w5,3);
clusters = {[1;9]; [5;13]; [2;3]; [10;11;14;15;17;18]; [6;7]; [4;12]; [8;16]}
nclusters = numel(clusters);
tic
clust_net_vector = zeros(nclusters*(nclusters-1)/2,1);
clust_nets_w5 = zeros(nclusters,nclusters,nnets);
for net=1:size(nets_w5,3)
    k = 0;
    for i=1:nclusters-1
        for j=i+1:nclusters
            k = k+1;
            %disp([i j])
            % c = [clusters{i};clusters{j}]
            %nets_w5(clusters{i},clusters{j},net)
            
            % Max
            clust_net_vector(k) = max(max(nets_w5(clusters{i},clusters{j},net)));
            % Mean
            %clust_net_vector(k) = sum(sum(nets_w5(clusters{i},clusters{j},net)))/numel(nets_w5(clusters{i},clusters{j},net))
            %clust_net_vector(k)
        end
    end
    assert(k==nclusters*(nclusters-1)/2)
    clust_nets_w5(:,:,net) = squareform(clust_net_vector);
end
toc
tic
clust_nets2 = nets_to_clusternets(nets_w5,clusters);
toc
assert(isequal(clust_nets2,clust_nets_w5))

% Binarize and Plot
nets_w5 = binarize(clust_nets2,0.7);
fname = 'average_degree_und';
%plot_nodes_property('average_degree_und',clust_nets2,5)
for t=1:nnets
   C(:,t) = feval(fname,nets_w5(:,:,t));
end
plot(C)


%% Freiburg database
clear
srate = 256;
%dir     = '/home/epilepsy/Freiburg Database/001/pat001Iktal/';
dir     = '/home/epilepsy/Freiburg Database/001/pat001Interiktal/';
patient = '010403ba';%_0013_5
files   = [6 7 8 12 13 14 15];
chans   = 1:6;

% [ci,fi] = ndgrid(1:numel(chans),1:numel(files));
% data =reshape(strcat([dir '/' patient '_'],sprintf('%04d',files(fi(:))),chans(ci(:))),numel(files)*numel(chans),1);
filepref = [dir patient '_0095_'];

fileID = fopen([filepref '1.asc'],'r');
x = fscanf(fileID,'%f');
fclose(fileID);

orig_data = zeros(numel(x),6);
orig_data(:,1) = x;

for c = 2:6
    fileID = fopen([filepref num2str(c) '.asc'],'r');
    orig_data(:,c) = fscanf(fileID,'%f');
    fclose(fileID);
end

    % Filtering
    filtered_data = detrend(orig_data);
    filtered_data = filtered_data';
    [filtered_data]=eegfilt(filtered_data,srate,1,0);
    [filtered_data]=eegfilt(filtered_data,srate,0,45);
    filtered_data = filtered_data';

    % Calculate correlations
    data = filtered_data;
    [length chan] = size(data);
    window = 5;
    frame = window*srate;
    timemoments = 0;
    symmetric = 1;

    corr      = @(x,y) max(abs(xcov(x,y,floor(srate/4),'coeff')));
    
   	nets_w5 = zeros(chan,chan,ceil(length/frame));
    indx = zeros(chan,chan,ceil(length/frame));
    	for time = 1:frame:length
        	timestop    = min(time+frame-1,length);
        	timemoments = timemoments + 1;
        	for i = 1:chan
        	    for j = 1:chan
        	        if (i<j) || (i>j && ~symmetric)
        	            [nets_w5(i,j,timemoments),indx(i,j,timemoments)] = ...
                            corr(data(time:timestop,i), ...
                                 data(time:timestop,j));
        	        elseif (i>j && symmetric)
        	            nets_w5(i,j,timemoments) = nets_w5(j,i,timemoments);
                        indx(i,j,timemoments) = indx(j,i,timemoments);
        	        end
        	    end
        	end
        end

    % Binarize and plot properties
    nets = binarize(nets_w5,0.7);
    nnets = size(nets_w5,3);
    fname = 'average_degree_und';
    %plot_nodes_property('average_degree_und',clust_nets2,5)
    for t=1:nnets
       C(:,t) = feval(fname,nets(:,:,t));
    end
    figure;
    plot(C)
    
%% Test saving via matfile (to be continued)
test = rand(100000,1000);
temp1 = 0;
save('test-save.mat','test')
save('test-save-v7.3.mat','test','-v7.3')

m = matfile('test-matfile.mat','Writable',true)
m.test = test;

save('test-save-v7.3-matfile.mat','temp1','-v7.3')
m2 = matfile('test-save-v7.3-matfile.mat','Writable',true)
m2.test = test;

m3 = matfile('test-matfile-loop.mat','Writable',true)
for i=1:1000 
    m3.test(1:100000,i)=test(1:100000,i); 
    i 
end

%% Save bipolar filtered data to central file
    infile        = '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_Export1/bipolar__f1-45__cross-corr/data.mat';
    outfile       = '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_Export1_bipolar_f1-45.mat';
    vars_to_copy  = {'startdate';'starttime';'srate';'seizend';'seizstart';'sleepend';'sleepstart';'sleep_annot';'filtered_data'};
    vars_to_stay  = {'nets_w5'};
    montage       = 'bipolar';
    filter        = 'f1-45';
    
    load(infile,vars_to_copy{:})
    save(outfile,vars_to_copy{:},'montage','filter','-v7.3')

    load(infile,vars_to_stay{:}) 
    whos('-file',infile)
    whos('-file',outfile)
    %% Careful!
    save(infile,vars_to_stay{:})
    
%% Copy piece of large mat file
    infile        = '/home/manolisc/epilepsy/Exports/II-9fee1/Export1.mat';
    outfile       = '/home/manolisc/epilepsy/Exports/II-9fee1/Export1_sleep1.mat';
    vars_to_copy  = {'startdate';'starttime';'srate';'montage';'seizstart';'seizend';'sleepend';'sleepstart';'sleep_annot'};
    
    load(infile,vars_to_copy{:})
    start         = sleepstart(1)
    finish        = sleepend(1)   
    starttime     = time_add(starttime,index_to_time(start-1,200))
    sleepstart    = 1
    sleepend      = sleepend(1) - start +1;
    for i=1:size(sleep_annot,1)
        sleep_annot{i,1} = sleep_annot{i,1} - start + 1;
    end
    seizstart     = []
    seizend       = []
    
    matin         = matfile(infile);
    datasize      = size(matin,'data')
    data          = matin.data(start:finish,1:datasize(2));
    
    save(outfile,vars_to_copy{:},'data','-v7.3')
    
%% Check periodicity of the EEG signal
    datafile = '/home/manolisc/epilepsy/Exports/II-9fee1/Export1_sleep1_data__bipolar__f1-45.mat';
    figdir = strrep(datafile,'.mat','_channel_power_periodicities');
    if ~exist(figdir,'dir') mkdir(figdir); end;
    patient_title = patient_to_str(datafile);

    load(datafile);
    [n nchans] = size(filtered_data);

    for i=1:nchans
        autocorrelation = xcorr(filtered_data(:,i), 'unbiased');
        assert(size(autocorrelation,1) == 2*n-1)
        normalized_autocorrelation = autocorrelation./autocorrelation(n);
        
        h = figure;
        leave_out_values = 150*1000;
        x_start = n+1000;
        x_finish = 2*n-leave_out_values-1;
        
        plot((1:x_finish-x_start+1)/(3600*200),normalized_autocorrelation(x_start:x_finish,:));
        title([patient_title ' - Channel ' int2str(i)  ' autocorrelation']);
        xlabel('Time lag (hours)');
        set(findall(gcf,'type','text'),'fontSize',24) 
        set(findall(gcf,'type','axes'),'fontsize',14)

        saveas(h, [figdir '/periodicity_channel' int2str(i) '.jpg']);
%        saveas(h, [figdir '/periodicity_channel' int2str(i) '.fig']);

        close;

    end
    
%% Clean sleep annotations and save
global ANNOT
annot = ANNOT;

nannot = size(annot, 1);
i = 1;
while (i<nannot)
    if annot{i,1}>=annot{i+1,1}
        annot(i,:)
        annot(i+1,:)
        annot(i,:)=[];
        nannot = nannot-1;
    else
        i = i+1;
    end
end

%% Periodicity (based on Salomi's code)
    load('/home/manolisc/epilepsy/Exports/II-9fee1/Export1_sleep1/bipolar__f1-45__cross-corr/nets.mat')
    nets_bin = binarize(nets_w5,0.65);

    % Calculate the desired property
    timemoments = size(nets_bin,3);
    C = zeros(timemoments,1);
    for t=1:timemoments
        C(t) = feval('average_degree_und',nets_bin(:,:,t));
    end

    x  = C;
    fs = 0.2;
    N  = 256;
    f  = -fs:fs/(N-1):fs;
    
    periodicity_stationary_DFT_DCT(x,fs,N)
    
    wsize = 2048;
    o     = 512;
    periodicity_nonstationary_DFT_DCT(x,fs,N,wsize,o)
%% DELETE
%     % The signal is first decomposed into a short-time frequency representation
%     [S,F,T,P] = spectrogram(x,kaiser(N),N-1,N,fs,'yaxis');        % use more than 256 DFT points to avoid considerable smearing of the harmonic powers
%     figure
%     surf(T,F,10*log10(P),'edgecolor','none');
%     axis tight,  view(0,90)
%     xlabel 'Time (s)', ylabel 'Frequency (Hz)'
%     title ('Spectrogram - Patient 5 - Average Degree')
%     
%     magnitude_S=abs(S);           % apoliti timi gia to DFT magnitude 
%     Discrete_cosine = dct(magnitude_S);  
%     
%     % Autocorrelation of Discrete Cosine
%     for i= 1:size(Discrete_cosine,1);
%         [ACF_DCT(i,:),Lags(i,:),bounds(i,:)] = autocorr(Discrete_cosine(i,:),length(Discrete_cosine(i,:))-1,1,2);
%     end
% 
%     % Sum of autocorrelation
%     sum_auto = sum(ACF_DCT);
% 
%     plot(sum_auto)   
%     ylabel ('Autocorrelation')
%     xlabel('Autocorrelation Lag')
%     title ('Summed Autocorrelation - Patient 4 - Average Degree ')
%     grid on

    % WINDOW THE SIGNAL
    x=x';
    [n,T]=size(x);                   % T einai ta samples
    %T = size(x,1);
    index=1:5000:T-4999;                 % to index xrisimopoeitai gia metritis

    for i=1:length(index);             % for loop gia para8irwsi
        X{i}=x(:,index(i):index(i)+4999);         %apo8ikeusi twn windows
        %X{i}=x(index(i):index(i)+4999,:);
    end

    % APPLY A SLIDING RECTANGULAR WINDOW & IN EACH WINDOW USE THE STATIONARY VERSION
    N=512;
    for i=1:1
        [S2_new{1,i},F2_new{1,i},T2_new{1,i},P2_new{1,i}] = spectrogram(X{1,i} (1,:),rectwin(N),511,N,fs,'yaxis');        % use more than 256 DFT points to avoid considerable smearing of the harmonic powers
    end

     %% DFT magnitude %%

     for i=1:1;

        S2_new_abs{1,i} = abs( S2_new {1,i});

      end
     %%   Discrete cosine transform (DCT)  %%
      for i=1:1;
     Discrete_cosine_new{1,i} = dct(S2_new_abs{1,i}); 
      end

      %% Autocorrelation of Discrete Cosine
      for i= 1:1;
        for j=1:257;
    ACF_DCT_new{1,i} = autocorr(Discrete_cosine_new{1,i} (j,:),length(Discrete_cosine_new{1,i} (j,:))-1,1,2);

    end
      end


    %% %% Sum of autocorrelation

    sum_auto_new = ACF_DCT_new{1,1}+  ACF_DCT_new{1,2}+ACF_DCT_new{1,3}+  ACF_DCT_new{1,4}+ACF_DCT_new{1,5} + ACF_DCT_new{1,6};
    %+ACF_DCT_new{1,7}+ACF_DCT_new{1,8};
    %+ACF_DCT_new{1,9}+ACF_DCT_new{1,10} ;


    figure
    plot (sum_auto_new)
    ylabel ('Autocorrelation')
    xlabel('Autocorrelation Lags')
    title ('Summed Autocorrelation - Average Degree - Non-Stationary')
    grid on


%% Empirical Mode Decomposition, Hilbert Huang

    experiments = {'bipolar__f1-45__cross-corr';
                   'bipolar__f1-45__cross-corr_no_symmetric'; 
                   'bipolar__f1-45__wpli';
                   'bipolar__f1-45__coherence_freq_bands';
                  };
    thresholds  = [0.65; 
                   0.35; 
                   0.8;
                   0.65];
    property   = {'average_degree_und'; 
                  'efficiency_bin'; 
                  'network_clustering_WS_bu'};
    long_seiz_mat = {'/home/manolisc/epilepsy/Exports/II-9fee1' 'Export1_sleep1';
                     '/home/manolisc/epilepsy/Exports/MC-95a3a' 'Export1';
                     '/home/manolisc/epilepsy/Exports/TK-c840d' 'Export1';
                     '/home/manolisc/epilepsy/Exports/HE-bb167' 'Export1-2';
                     '/home/manolisc/epilepsy/Exports/MG-f84c1' 'Export1-2part';
                     '/home/manolisc/epilepsy/Exports/DP-98304' 'Export1';
                     '/home/manolisc/epilepsy/Exports/GM-10837' 'Export1';
                     '/home/manolisc/epilepsy/Exports/MV-5859'  'Export1-2';
                     '/home/manolisc/epilepsy/Exports/RC-4337'  'Export1-2';
    };

    for e=1:1
        for i=1:1%size(long_seiz_mat,1)
            for pr=1:1%size(property,1)
                % Load the data
                load([long_seiz_mat{i,1} '/' long_seiz_mat{i,2} '/' experiments{e} '/nets.mat'],'nets_w5');
                load([long_seiz_mat{i,1} '/' long_seiz_mat{i,2} '.mat'],'srate');
                figdir = [long_seiz_mat{i,1} '/' long_seiz_mat{i,2} '/' experiments{e} '/window=5/threshold=' num2str(thresholds(e))];
                
                % Binarize and calculate the property
                [~, ~, timemoments, networks] = size(nets_w5);
                nets_bin = binarize(nets_w5,thresholds(e));
                for j=1:networks
                    if (networks==1)
                        net_filename = '';
                        net_title = '';
                    else
                        net_filename = ['_' strrep(network_to_freq_str(j),' band','')];
                        net_title = network_to_freq_str(j);
                    end
                    
                    for t=1:timemoments
                       C(t) = feval(property{pr},nets_bin(:,:,t,j));
                    end
                    
                    filename = [figdir '/hht_' property{pr}]; 
                    %C = detrend(C);
                    plot_hht(C,5/3600,filename)
                    close all
                end % networks
            end
        end
    end
    
%% Test HHT
close all
t = 0:pi/100:16*pi;
x =  sin(t)+sin(2.3*t+100) + [0:pi/100:16*pi];
%x = [0:pi/100:16*pi 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100 0:pi/100:16*pi-pi/100]+sin(t)+sin(2.3*t+100);
%x = detrend(x);
figure; plot(t,x,t,sin(t),t,sin(2.3*t+100))
imf = plot_hht(x,1/200);

%% Impulse responce of filter
period = 5;
a = [1 zeros(1,period-1) -1/period];
b = [1];% zeros(1,period-1) 1];
y = filter(b,a,[1 zeros(1,50)]);
plot(y,'r')

%% Test remore period with a comb filter
close
t = 0:pi/100:16*pi;
x = sin(t);%+sin(5*t);
plot(t,x)
hold on;

%[b,a] = comb(400,1);
period = 200;
a = [1 zeros(1,period-1) -1/period];
b = [1 zeros(1,period-1) -1];
y = filter(b,a,x);
plot(t,y,'r')

z = x - y;
plot(t,z,'y')

%% Test detect period with sine fit (http://www.mathworks.com/matlabcentral/answers/36999-how-do-i-regression-fit-a-sinwave-to-a-dataset)
 t = (1:50)';
 X = ones(50,3);
 X(:,2) = cos((2*pi)/50*t);
 X(:,3) = sin((2*pi)/50*t);
 y = 2*cos((2*pi)/50*t-pi/4)+randn(size(t));
 y = y(:);
 beta = X\y;
 yhat = beta(1)+beta(2)*cos((2*pi)/50*t)+beta(3)*sin((2*pi)/50*t);
 plot(t,y,'b');
 hold on
 plot(t,yhat,'r','linewidth',2);
 
%% Test detect period with sine fit
    %close all
    t = 0:pi/100:16*pi; t=t';
    y = 2*sin(t-pi/4)+randn(size(t))+sin(5*t);
    
    yhat = sinefit(t,y,t);
    figure
    y1 = y-yhat;
    plot(t,y1);
 
    yhat = sinefit(t,y1,5*t);
    figure
    y2 = y1-yhat;
    plot(t,y2);

%% Test detect multiple periods with autocorrelations and findpeaks (http://www.mathworks.com/help/signal/ug/find-periodicity-using-autocorrelation.html)
    fs = 200;
    t = 0:2*pi/fs:16*pi; t=t';
    y = 9 + 2*sin(t-pi/4)+randn(size(t))+sin(5*t)+t;
    plot(y)
    
    ynorm = y - mean(y);
    ynorm = detrend(ynorm);
    plot(ynorm);

    [autocor,lags] = xcorr(ynorm,'coeff');
    figure; plot(lags/fs,autocor);
    
    [pksh,lcsh] = findpeaks(autocor,'MinPeakheight',0.3);
    short = mean(diff(lcsh))/fs

    [pklg,lclg] = findpeaks(autocor,'MinPeakDistance',ceil(short)*fs, ...
                                'MinPeakheight',0.3);
    long = mean(diff(lclg))/fs
    hold on
    pks = plot(lags(lcsh)/fs,pksh,'or', ...
           lags(lclg)/fs,pklg+0.05,'vk');
    hold off
    legend(pks,[repmat('Period: ',[2 1]) num2str([short;long],0)])
    %axis([-21 21 -0.4 1.1])
%% Test detect multiple periods in XLTEK data
    close all
    clear
    y = periodicity_netsw_netproperty('/home/manolisc/epilepsy/Exports/II-9fee1','Export1','bipolar__f1-45__cross-corr','average_degree_und',0.65);
    fs = 3600/5;
    t = (0:size(y,1)-1)'/fs;
    yhat = sinefit(t,y,2*pi/0ceil(25.66*3600/5)*(1:size(t,1)));
    y1 = y - yhat;
    plot(y1)
    autocorrelation = xcorr(y1, 'unbiased');
    figure; plot(autocorrelation);
    figure; plot(y1)
    y1hat = sinefit(t,y1,2*pi/7521*(1:size(t,1)));
    y2 = y1 - y1hat;
    autocorrelation = xcorr(y2, 'unbiased'); figure; plot(autocorrelation);

%% Test detect multiple periods in XLTEK data using findpeaks
    close all
    clear
    %y = periodicity_netsw_netproperty('/home/manolisc/epilepsy/Exports/II-9fee1','Export1','bipolar__f1-45__cross-corr','average_degree_und',0.65);
    %y = periodicity_netsw_netproperty('/home/manolisc/epilepsy/Exports/II-9fee1','Export1_sleep1','bipolar__f1-45__cross-corr','average_degree_und',0.65);
    %y = periodicity_netsw_netproperty('/home/manolisc/epilepsy/Exports/HE-bb167','Export1-2','bipolar__f1-45__cross-corr','average_degree_und',0.65);
    %fs = 3600/5;
    %load('HE-degree.mat')
    load('HE-degree-corrected_cross_corr')
    y = detrend(y);
    t = (0:size(y,1)-1)'/fs;
    figure; plot(t,y); 
    xlabel 'Time (hours)', ylabel 'Average degree', axis tight
    
    ynorm = y - mean(y);
    %ynorm = remove_mean(y,0.98); ynorm = ynorm - mean(ynorm);
    figure; plot(t,ynorm); 
    xlabel 'Time (hours)', ylabel 'Normalized average degree', axis tight
    
%     [autocor,lags] = xcorr(y,'coeff');
%     figure; plot(lags/fs,autocor);

    [autocor,lags] = xcorr(ynorm,'coeff');
    %%
    %close
    figure; plot(lags/fs,autocor);

%     [pksh,lcsh] = findpeaks(autocor,'MinPeakDistance',3600/5);%,'MinPeakheight',0.3);
%     short = mean(diff(lcsh))/fs
% 
%     [pklg,lclg] = findpeaks(autocor,'MinPeakDistance',ceil(short)*fs);%, ...
%                                 %'MinPeakheight',0.3);
%     long = mean(diff(lclg))/fs
%     hold on
%     pks = plot(lags(lcsh)/fs,pksh,'or', ...
%            lags(lclg)/fs,pklg+0.05,'vk');
%     hold off
%     legend(pks,[repmat('Period: ',[2 1]) num2str([short;long],0)])
    

    MinPeakHeight = 0.001;
    Threshold = 0;
    [pk,lc] = findpeaks(autocor,'MinPeakDistance',3600/5,'Threshold',Threshold);%,'MinPeakheight',MinPeakHeight);
    period  = mean(diff(lc))/fs
    periods = period;
    pks = {pk};
    lcs = {lc};

    while ~isempty(period)
        [pk,lc] = findpeaks(autocor,'MinPeakDistance',ceil(period)*fs,'Threshold',Threshold);%,'MinPeakheight',MinPeakHeight);
        if size(lc,1)>1
            period = mean(diff(lc))/fs
            if period<26
                periods(end+1,1) = period;
                pks{1,end+1} = pk;
                lcs{1,end+1} = lc;
            else
                period = [];
            end
        else
            period = [];
        end
    end
    
    
    hold on
    N = size(periods,1);
    Legends = cell(N+1,1);  
    Legends{1} = '';
    Styles = {'or','vk','+y','>b','<m','*r','xk','.y','sb','dm'};
    for i=1:N
        plot(lags(lcs{1,i})/fs,pks{1,i}+i*0.05,Styles{1,mod(i,size(Styles,2))+1});
        Legends{i+1} = ['Period: ' num2str(periods(i))];
    end
    hold off
    legend(Legends)
    
    %%
    %close all
    periods
    periods1 = periods;%([1 5 7])    
    N1 = size(periods1,1);
    y1 = y;
    for i=N1:-1:1
        yhat = sinefit(t,y1,2*pi/ceil(periods1(i)*fs)*(1:size(t,1)));
        y1 = y1 - yhat;
    end
    %%
        plot(y1)
    autocorrelation = xcorr(y1, 'unbiased');
    figure; plot(autocorrelation);
    figure; plot(y1)
    y1hat = sinefit(t,y1,2*pi/7521*(1:size(t,1)));
    y2 = y1 - y1hat;
    autocorrelation = xcorr(y2, 'unbiased'); figure; plot(autocorrelation);

%% Test detect multiple periods by removing the largest IMFs and then autocorrelation
% Does not appear to be working correctly

    %load('HE-degree.mat')
    load('HE-degree-corrected_cross_corr')
    dir  = '/home/manolisc/epilepsy/MATLAB/MV-cross_cor-periodicity'; 
    y    = detrend(y);
    n    = size(y,1);
    time = (0:n-1)/fs;
    
    autocorrelation = xcorr(y, 'unbiased');
    autocorrelation = autocorrelation./autocorrelation(n);
    
    figure; 
        subplot(2,1,1); plot(time,y); xlabel('Time (hours)');
        title('Degree (detrended)')
        subplot(2,1,2); plot(time(1:n-2000),autocorrelation(n+1:2*n-2000)); xlabel('Lag (hours)');
        title('Αutocorrelation')
        saveas(gcf,[dir '/degree.fig'])
        saveas(gcf,[dir '/degree.jpg'])
    
    %imf = plot_hht(y,1/fs);     % requires the findpeaks provided
    imf = plot_hht(y,1/fs,[dir '/hht']);
    
    nimf = size(imf,2);
    %%
    y1 = y;
    close all
    for i=nimf:-1:1
        % Autocorrelate
        [autocorrelation1,lags] = xcorr(y1, 'unbiased');
        autocorrelation1 = autocorrelation1./autocorrelation1(n);

        % Method 1 for finding the main period - Power spectrum
%         [Pxx,F] = pwelch(y1,[],[],4096,fs);
%         figure; plot(F,Pxx)
%             title('Power spectrum')
%             saveas(gcf,[dir '/power' num2str(i) '.fig'])
%             saveas(gcf,[dir '/power' num2str(i) '.jpg'])
%             close
%             
%         [pk,loc] = findpeaks(Pxx);
%         [maxpk,maxloc] = max(pk(2:end));
%         period1 = ceil(1/F(1+maxloc))
%         [pks,locs] = findpeaks( autocorrelation1(n+1:2*n-15*fs),'MinPeakDistance',ceil(period1*fs));
%         period = mean(diff(locs))/fs; 

        % Method 2 for finding the main period - Reapeated find peaks
        periods = period_detection_findpeaks(lags(n+1:2*n-15*fs),autocorrelation1(n+1:2*n-15*fs),fs);
        period = periods(end);
        [pks,locs] = findpeaks( autocorrelation1(n+1:2*n-15*fs),'MinPeakDistance',ceil(period*fs));

        per_measure = ' hours';
        if period<1
            period = period*60; per_measure = ' mins';
        end

        % Find prominent peaks
        %[pks,locs] = findpeaks( autocorrelation1(n+1:2*n-15*fs)),'MinPeakDistance',22*fs);
        %diff(locs)
        %period = mean(diff(locs))
        
        % Testing
%         [pks,locs] = findpeaks( autocorrelation1(n+1:2*n-15*fs));%,'NPeaks',10,'SortStr','none');
%         maxpk = max(pks);
%         t = (1/2)*maxpk;
%         indx  = find(pks>t);
%         locs  = locs(indx);
%         mean_peak_distance = mean(diff(locs));
%         [pks,locs] = findpeaks( autocorrelation1(n+1:2*n-15*fs),'MinPeakHeight',t,'MinPeakDistance',ceil(mean_peak_distance));
%         %figure; plot(time(1:n-2000),autocorrelation1(n+1:2*n-2000)); xlabel('Lag (hours)');
%         %hold on; plot(locs/fs,pks+0.05,'vr');
        
        
        % Plot
        figure; 
            subplot(2,1,1); plot(time,y1); xlabel('Time (hours)');
            title(['First ' num2str(i) ' IMFs of Degree'])
            subplot(2,1,2); plot(time(1:n-2000),autocorrelation1(n+1:2*n-2000)); xlabel('Lag (hours)');
            hold on; hper = plot(locs/fs,pks,'vr');
            title('Αutocorrelation')
            legend(hper,['Period (mean): ' num2str(period) per_measure])
            saveas(gcf,[dir '/period' num2str(i) '.fig'])
            saveas(gcf,[dir '/period' num2str(i) '.jpg'])
            close

        % Remove last imf
        y1 = y1 - imf{1,i}';
    end
    
    
%%  Test detect multiple periods by spectral analysis (http://www.mathworks.com/help/matlab/math/fast-fourier-transform-fft.html)

    load('HE-degree.mat')
    n    = size(y,1);
    time = (0:n-1)/fs;
    
    figure; plot(time,y); xlabel('Time (hours)');
    
    Y = fft(y);
    freq = (fs/2)*linspace(0,1,n/2+1); freq = freq';
    figure; plot(freq,abs(Y(1:n/2+1)));         % Amplitude of the DFT
    figure; plot(freq,(abs(Y(1:n/2+1)).^2)/n);  % Power of the DFT (periodogram)
    
    Y_power = (abs(Y(1:n/2+1)).^2)/n;
    [~,Y_power_peaks] = findpeaks(Y_power);
    [1./freq(Y_power_peaks(1:25)) Y_power(Y_power_peaks(1:25))]
    
    spectrogram(y,[],[],[],fs,'yaxis')

    
    
    
    
    
    
    
    
    
    
    
%% Testing (to be deleted) - http://www.johnloomis.org/ece561/notes/zeropole/comb.html

L = 16;
r = 0.995
[b,a] = comb(r,L);
[z,p,k] = tf2zp(1,b); % IIR comb
zplane(z,p)

% IIR
[h,w] = freqz(1,b);
plot(w/pi,abs(h));
xlabel 'Normalized frequency (Nyquist==1)'
ylabel 'Magnitude Response'

% FIR
[h,w] = freqz(b,1);
plot(w/pi,abs(h));
ylabel 'Magnitude Response'
xlabel 'Normalized frequency (Nyquist==1)'

%
r =0.9995
L = 75
fs = 22050
[b,a] = comb2(r,L)
y = filter(1,b,im);
plot(y)

%% Testing (to be deleted) - http://dsp.stackexchange.com/questions/1782/creating-a-50hz-comb-filter-in-matlab
% // Make a harmonic signal and add it to another sine
sr = 44100; 
dt = 1/sr;
tAxis = dt:dt:2;

freq = 50;
x = mean(sin (2*pi*freq*(1:10)'*tAxis))'; %Harmonic noise
x = x+ sin(2*pi*440*tAxis)';


% // Fractional delay comb filter
rho = 0.95; %This sets how narrow the rejection is. Must be between 0 and 1

delay = (sr/2)/freq - 1;
N = 2*floor(delay);



%// LAGRANGE  h=lagrange(N,delay) returns order N FIR 
%//          filter h which implements given delay 
%//          (in samples).  For best results, 
%//          delay should be near N/2 +/- 1.
n = 0:N;
h = ones(1,N+1);
for k = 0:N
    index = find(n ~= k);
    h(index) = h(index) *  (delay-k)./ (n(index)-k);
end


b = [1 -h];
a = [1 -rho*h];

nfft = 2^14;
figure; freqz(b, a, nfft, 'half', sr)

xf = filter(b,a,x);

soundsc([x; xf],sr);
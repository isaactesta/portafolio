    function testing_measures_mat(dir,infilename,montage,correlation,filtering,threshold)
% Tests various measures, thresholds, window-sizes etc.
    
    tic;
    
    % Print current run
    inputs = {dir; infilename};
    disp(inputs);

    global NET CORR FILT OUTDIR WINDOWS INPUTTYPE GAMMA_MAX ...
        MULTIPLE_NETWORKS_PER_FIG PLOT_AVERAGE
    
    
    % ===================================================================
    % ******************** USER INPUT ***********************************
    
    % Redo calculations from scratch? (rather than load and replot?)
    % 0 = No, 1 = Yes
    REDO_FROM_SCRATCH = 0;
    
    % Size of window to consider (5 for cross-corr, 10 for kramer)
    WINDOWS = [5];    
    
    % Maximum freq of the gamma band and the broadband
    GAMMA_MAX = 45;
    
    % 0 or 1 (used in plot_nodes_property)
    MULTIPLE_NETWORKS_PER_FIG = 0;
    
    % Plot data by averaging intervals
    PLOT_AVERAGE = 0;
    
    % Instead of setting a set threshold we define a percentage of
    % connections to be drawn. 0 indicates the use of surrogates (below)
    CONNECTIVITY = 0.0;

    % Use surrogate data to set the threshold.
    % 0 indicates the use of a fixed threshold (below)
    SURROGATES = 0;
    
    % The thresholds for which the experiments will run
    % If connectivity or surrogates are used, these will be ignored
    if nargin<6
        T_LOW  = 0.55;
        T_HIGH = 0.65;
    else
        T_LOW  = threshold;
        T_HIGH = threshold;
    end
    % ****************** END OF USER INPUT ******************************
    % ===================================================================

    % Type of nodes in the network: 'xltek_single', 'ref', 'avgref' or 'bipolar'
    NET = montage;
    
    % Type of filtering: 'detrend', 'f1-48', 'f1-50', 'f1-50_regression', 
    %       'f1-60', 'f1-60_notch', 'alpha' (8-13Hz), 'beta' (13-30Hz),
    %       'gamma' (30-48/60Hz), 'delta' (1-4Hz), 'theta' (4-8Hz), 
    %       'ICA', 'CRLS', 'f1-45'
    % Is not used when clean data are passed (args. 3 & 4)
    FILT = filtering;
    
    % Type of correlation: 'cross-corr', 'kramer', 
    %   'coherence', 'coherence_freq_bands',
    %   'mean_coherence' 'mean_coherence_freq_bands',
    %   'imaginary_coherence', 'imaginary_coherence_freq_bands'
    %   'mean_imaginary_coherence' 'mean_imaginary_coherence_freq_bands'
    %   'reduced_coherence_freq_bands', 'cross-corr_no_zero_lag', 
    %   'pli', 'pli_cpsd', 'wpli', 'cross-corr_no_symmetric'
    CORR = correlation;
    
    % The output directory
    if GAMMA_MAX~=45 && ~strcmp(filtering,'f1-45')
        OUTDIR = [dir '/' infilename '/' NET '__' FILT '__' CORR '__fmax_' num2str(GAMMA_MAX)];
    else
        OUTDIR = [dir '/' infilename '/' NET '__' FILT '__' CORR];
    end
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Don't touch below this point
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Create or load correlations
    if REDO_FROM_SCRATCH || ~exist_nets_weighted(OUTDIR,WINDOWS)
        create_nets_weighted(dir,infilename);
    end
    
    %load([OUTDIR '/data.mat'],'data','srate','evend','evstart','filtered_data','indices','nets_w*','node_data','indx');
    load([dir '/' infilename '.mat'],'startdate','starttime','srate',...
         'seizend','seizstart','sleepend','sleepstart');   
    load([OUTDIR '/nets.mat'],'nets_w*')

    % Binarize and plot
    for window_size = WINDOWS
        varname = ['nets_w' num2str(window_size)];
        network_labels = {'all bands' 'alpha band' 'beta band' ...
                          'gamma band' 'delta band' 'theta band'};
        
        if CONNECTIVITY>0 
            % Maintain constant average degree according to requested
            % connectivity
            eval(['nets = binarize_fixed_connectivity(' varname ', CONNECTIVITY);']);
            figdir = [OUTDIR '/window=' num2str(window_size) '/connectivity=' num2str(CONNECTIVITY)];
            plot_all(nets,window_size,floor(seizstart/srate),floor(seizend/srate),figdir,network_labels);
        
        elseif SURROGATES>0
            % Initialize with weighted data
            eval(['nets = ' varname ';']);
            
            % Construct surrogates and set to zero all connections
            % with weaker connections than the surrogates
            for i=1:SURROGATES
                % Check if we have the surrogates already
                surrogate_filename = [OUTDIR '/surrogates_w' num2str(window_size) '.mat'];
                 if exist(surrogate_filename,'file')
                    vars = whos('-file',surrogate_filename);
                    
                    %if ~exist(['surrogate_nets' num2str(i)],'var')
                    if ismember(['surrogate_nets' num2str(i)], {vars.name})
                        disp(['LOADING surrogate nets ' num2str(i) '...']);
                        eval('load(surrogate_filename,[''surrogate_nets'' num2str(i)]);');
                        eval(['surrogate_nets = surrogate_nets' num2str(i) ';']);
                    end
                end
                
                if ~exist('surrogate_nets','var')
                    disp(['CREATING surrogate nets ' num2str(i) '...']);
                    load([OUTDIR '/data.mat'],'filtered_data');
                    surrogate_data = generate_surrogate_data(filtered_data,window_size,srate);
                    surrogate_nets = correlate_all(surrogate_data,window_size,srate);

                    % Save surrogate nets for future use
                    eval(['surrogate_nets' num2str(i) '=surrogate_nets;']);
                    if i==1
                        eval('save(surrogate_filename,[''surrogate_nets'' num2str(i)]);');
                    else
                        eval('save(surrogate_filename,[''surrogate_nets'' num2str(i)],''-append'');');
                    end
                end
                
                size(nets)
                size(surrogate_nets)
                nets(nets<=surrogate_nets) = 0;
                clear surrogate_nets;
                eval(['clear surrogate_nets' num2str(i) ';']);
            end
            
            % The remaining connections are significant
            nets(nets>0) = 1;
            
            % Plot and save
            figdir = [OUTDIR '/window=' num2str(window_size) '/surrogates=' num2str(SURROGATES)];
            plot_all(nets,window_size,floor(evstart/srate),floor(evend/srate),figdir,network_labels);
            
        else
            % Binarize the weighted network with the given fixed thresholds
            for threshold = T_LOW:0.1:T_HIGH
                eval(['nets = binarize(' varname ',threshold);']);
                figdir = [OUTDIR '/window=' num2str(window_size) '/threshold=' num2str(threshold)];
                plot_all(nets,window_size,floor(seizstart/srate),floor(seizend/srate),figdir,network_labels);
            end
        end
    end
    
    clear;
    toc;
end

function [doesexist]=exist_nets_weighted(netsdir,windows)
    fprintf('Checking existence of correlation nets... ');
    
    doesexist = false;
    netsfile = [netsdir '/nets.mat'];
    
    if exist(netsfile,'file')
        load(netsfile,'nets_w*');%,'seizstart','seizend','srate')
    else 
        fprintf('Nets file does not exist!\n');
        return;
    end
    
    for w = windows
        if ~exist(['nets_w' int2str(w)],'var')
        	fprintf('nets_w%d does not exist!\n',int2str(w));
            return;
        end
    end
    
    fprintf('Yes, all nets do exist!\n');
    doesexist = true;
end

function create_nets_weighted(dir,infilename)
    fprintf('Creating correlation networks...\n');
    
    global NET FILT OUTDIR WINDOWS INPUTTYPE GAMMA_MAX
    
    % Set up filenames and directories
    source      = [dir '/' infilename '.mat'];
    datafile    = [dir '/' infilename '_data__' NET '__' FILT '.mat'];
    netsfile    = [OUTDIR '/nets.mat'];

    matsource   = matfile(source);
    matdata     = matfile(datafile);    % If file does not exist, it is writable by default!
    matnets     = matfile(netsfile,'Writable',true);
    
    if ~exist(OUTDIR,'dir') mkdir(OUTDIR); end
    %if exist(netsfile,'file') delete(netsfile); end

    load(source,'startdate','starttime','srate',...
         'seizend','seizstart','sleepend','sleepstart');
    datasize        = size(matsource,'data');
    n               = datasize(1);
    nloc            = 16000000;
    fprintf('    Data size is %d, in %d rounds\n',n,ceil(n/nloc))
    
    redo_datafile   = false;
    if ~exist(datafile,'file') 
        redo_datafile = true;
        matdata     = matfile(datafile,'Writable',true);
    else
        % matdata     = matfile(datafile,'Writable',true);
        filtdata_size = size(matdata,'filtered_data');
        if filtdata_size(1) ~= n
            redo_datafile = true;
            matdata     = matfile(datafile,'Writable',true);
        end
    end
    
    for i = 1:ceil(n/nloc)
        round_start  = (i-1)*nloc+1;
        round_finish = min(i*nloc,n);
        fprintf('    Round %d: %d - %d\n',i,round_start,round_finish)
        
        if redo_datafile
            matdata.montage = NET;
            matdata.filter  = FILT;
            channels_to_load = 1:28;
            data = matsource.data(round_start:round_finish,channels_to_load);
            data(isnan(data)) = 0;

            % Adjust the data montage
            if strcmp(NET,'xltek_single')
                node_data = data(:,4:22);   % Electrode data

            elseif strcmp(NET,'ref')
                fprintf('      Converting XLTEK to common ref...\n')
                node_data = xltek_to_commonref(data);
                
                % Append eye channels 
                if strfind(FILT,'f1-50_regression')
                    node_data(:,19:20) = data(:,23:24);     % add the eyes
                end

            elseif strcmp(NET,'avgref')
                fprintf('      Converting XLTEK to avgref...\n')
                node_data = xltek_to_avgref(data);

                % Append eye channels
                if strfind(FILT,'f1-50_regression')
                    node_data(:,19:20) = data(:,23:24);      % add the eyes
                end

            elseif strcmp(NET,'bipolar')
                fprintf('      Converting XLTEK to bipolar...\n')
                node_data = xltek_to_bipolar(data,18);

            end
            clear data;

            % Filter the data
            if strfind(FILT,'detrend')
                filtered_data = detrend(node_data);
            elseif strfind(FILT,'f1-45')
                filtered_data = myfilter(node_data,1,45,srate);
            elseif strfind(FILT,'f1-48')
                filtered_data = myfilter(node_data,1,48,srate);
            elseif strfind(FILT,'f1-50')
                filtered_data = myfilter(node_data,1,50,srate);
            elseif strfind(FILT,'f1-60')
                filtered_data = myfilter(node_data,1,60,srate);
            elseif strfind(FILT,'f1-60_notch')
                filtered_data = myfilter(node_data,1,60,srate);
                %wo = 50/(srate/2); bw = wo/35;
                %[b,a] = iirnotch(wo,bw);
                filtered_data = notch_filter(srate,50,filtered_data);
            elseif strfind(FILT,'alpha')
                disp('     Filtering data in the alpha band...');
                filtered_data = myfilter(node_data,8,13,srate);
            elseif strfind(FILT,'beta')
                disp('     Filtering data in the beta band...');
                filtered_data = myfilter(node_data,13,30,srate);
            elseif strfind(FILT,'gamma')
                disp('     Filtering data in the gamma band...');
                filtered_data = myfilter(node_data,30,GAMMA_MAX,srate);
            elseif strfind(FILT,'delta')
                disp('     Filtering data in the delta band...');
                filtered_data = myfilter(node_data,1,4,srate);
            elseif strfind(FILT,'theta')
                disp('     Filtering data in the theta band...');
                filtered_data = myfilter(node_data,4,8,srate);
            elseif strfind(FILT,'f1-50_regression')
                % Remove artifacts with regression
                filtered_data = remove_artifacts(node_data); 
            elseif ~isempty(strfind(FILT,'ICA')) || ~isempty(strfind(FILT,'CRLS'))
                filtered_data = node_data;
            else
                error(['Unknown filtering function: ' FILT]);
            end
            clear node_data;
            
            nchans = size(filtered_data,2);
            fprintf('      Saving at mat positions (%d:%d,1:%d)\n',round_start,round_finish,nchans)
            matdata.filtered_data(round_start:round_finish,1:nchans) = filtered_data;
        else
            filtdatasize  = size(matdata,'filtered_data');
            nchans        = filtdatasize(2);
            fprintf('      Loading filtered_data(%d:%d,1:%d)...\n',round_start,round_finish,nchans)
            filtered_data = matdata.filtered_data(round_start:round_finish,1:nchans);
        end % redo_datafile
        

        % Cross-correlate
        for window_size = WINDOWS
            netvar = ['nets_w' int2str(window_size)];
            nchans = 18;    % Number of channels to correlate on
            eval(['[' genvarname(netvar)...
                ',indx]=correlate_all(filtered_data,window_size,srate,nchans);'])
            
            frame = window_size*srate;
            net_length = nloc/frame;
            eval(['net_cur_length = size(' netvar ',3);'])
            eval(['nfreq_bands = size(' netvar ',4);'])
            if nfreq_bands>1
                eval(['matnets.' netvar '(1:nchans,1:nchans,(i-1)*net_length+1:(i-1)*net_length+net_cur_length,1:nfreq_bands) = ' netvar ';'])
            else
                eval(['matnets.' netvar '(1:nchans,1:nchans,(i-1)*net_length+1:(i-1)*net_length+net_cur_length) = ' netvar ';'])
            end
        end
    end % data parts
    
    %matout.nets_w5 = nets_w5_all;
    
    % Check
    info2 = whos(matdata,'filtered_data');
    %assert(isequal(info2.size,info.size));
    info2.size
    info3 = whos(matnets,'nets_w5');
    info3.size
    %assert(isequal(info2.size,[nchans nchans floor(n/(5*srate))]));
    %save([OUTDIR '/data.mat'],'startdate','starttime','srate','seizend','seizstart','sleepend','sleepstart','-append');
    
    fprintf('... Done creating correlation networks!\n');
end

function [filtered_data]=myfilter(data,low,high,srate)
    disp('      Filtering... ');

    filtered_data = detrend(data);

    filtered_data = filtered_data';
    [filtered_data]=eegfilt(filtered_data,srate,low,0);
    [filtered_data]=eegfilt(filtered_data,srate,0,high);
    filtered_data = filtered_data';

    %fprintf('Done!\n');
end

function [nets,indx]=correlate_all(data,window,srate,nchan)
    fprintf(['      Correlating (window = ' num2str(window) ')... ']);

    global CORR NET GAMMA_MAX

    symmetric    = 0;        % Symmetric correlation measure
    indx = 0;

    [length chan] = size(data);
    frame = window*srate;
    timemoments = 0;
    symmetric = 1;
    
    if nargin>3
        chan = nchan;   % Use only the first nchan channels
    end

    if strcmp(CORR,'kramer')
        corr      = @kramer_edge_weighted;
    elseif strcmp(CORR,'cross-corr')
        %corr      = @(x,y)  max(abs(xcov(x,y,srate/4,'coeff')));
        corr      = @(x,y) cross_corr(x,y,srate);
    elseif strcmp(CORR,'cross-corr_no_zero_lag')
        corr      = @(x,y) cross_corr_no_zero_lag(x,y,srate);
    elseif strcmp(CORR,'cross-corr_no_symmetric')
        corr      = @(x,y) cross_corr_no_symmetric(x,y,srate);
    elseif strcmp(CORR,'coherence')
        corr      = @(x,y) coherence(x,y,1,GAMMA_MAX,srate);
    elseif strcmp(CORR,'mean_coherence')
        corr      = @(x,y) mean_coherence(x,y,1,GAMMA_MAX,srate);
    elseif strcmp(CORR,'imaginary_coherence')
        corr      = @(x,y) imaginary_coherence1(x,y,srate);
    elseif strcmp(CORR,'mean_imaginary_coherence')
        corr      = @(x,y) mean_imaginary_coherence(x,y,1,GAMMA_MAX,srate);
    elseif strcmp(CORR,'mutualinfo')
        corr      = @mutualinf;
    elseif strcmp(CORR,'coherence_freq_bands')
        corr      = @(x,y) coherence_freq_bands(x,y,srate);
    elseif strcmp(CORR,'mean_coherence_freq_bands')
        corr      = @(x,y) mean_coherence_freq_bands(x,y,srate);
    elseif strcmp(CORR,'imaginary_coherence_freq_bands')
        corr      = @(x,y) imaginary_coherence_freq_bands(x,y,srate);
    elseif strcmp(CORR,'reduced_coherence_freq_bands')
        % Not really used; we make a special case below as we need 
        %   to calculate the distances 
        corr      = @reduced_coherence_freq_bands;
    elseif exist([CORR '.m'],'file')
        corr      = str2func(CORR);
    else
        error(['        Unknown correlation function: ' CORR]);
    end

    if strcmp(CORR,'coherence_freq_bands') || ...
        strcmp(CORR,'mean_coherence_freq_bands') || ...
        strcmp(CORR,'imaginary_coherence_freq_bands')
        % Special case: we will plot all frequency bands in the same plot
        % Compute the coherence, then plot one line for each frequency band
        nets = zeros(chan,chan,ceil(length/frame),6);	% Fourth dimension stores the 
                                                        % values at different frequencies

        for time = 1:frame:length
            timestop    = min(time+frame-1,length);
            timemoments = timemoments + 1;
            for i = 1:chan
                for j = 1:chan
                    if (i<j) || (i>j && ~symmetric)
                        nets(i,j,timemoments,:) = corr(data(time:timestop,i),...
                            data(time:timestop,j));
                    elseif (i>j && symmetric)
                        nets(i,j,timemoments,:) = nets(j,i,timemoments,:);
                    end
                end
            end
        end
    elseif strcmp(CORR,'reduced_coherence_freq_bands')
        if ~strcmp(NET,'ref')
            error('        Reduced coherence can only be computed with common reference montage. Aborting...');
        end

        nets = zeros(chan,chan,ceil(length/frame),6);	% Fourth dimension stores the 
                                                        % values at different frequencies
        % Load electod distances and get rid of the common reference Cz
        distance=importdata('electrode-distances.txt');
        distance=distance(~ismember(1:size(distance,1),13),:);
        distance=distance(:,~ismember(1:size(distance,2),13));

        for time = 1:frame:length
            timestop    = min(time+frame-1,length);
            timemoments = timemoments + 1;
            for i = 1:chan
                for j = 1:chan
                    if (i<j) || (i>j && ~symmetric)
                        nets(i,j,timemoments,:) = ...
                            reduced_coherence_freq_bands(data(time:timestop,i),...
                            data(time:timestop,j),distance(i,j),srate);
                    elseif (i>j && symmetric)
                        nets(i,j,timemoments,:) = nets(j,i,timemoments,:);
                    end
                end
            end
        end     
    elseif strcmp(CORR,'cross-corr') || strcmp(CORR,'cross-corr_no_zero_lag')
%        tic
        nets = zeros(chan,chan,ceil(length/frame));
        indx = zeros(chan,chan,ceil(length/frame));

        for time = 1:frame:length
            timestop    = min(time+frame-1,length);
            timemoments = timemoments + 1;
            for i = 1:chan
                for j = 1:chan
                    if (i<j) || (i>j && ~symmetric)
                        [nets(i,j,timemoments),indx(i,j,timemoments)] = ...
                            corr(data(time:timestop,i), ...
                                 data(time:timestop,j));
                    elseif (i>j && symmetric)
                        nets(i,j,timemoments) = nets(j,i,timemoments);
                        indx(i,j,timemoments) = indx(j,i,timemoments);
                    end
                end
            end
        end
%         toc
%         
%         tic
%         nets2 = zeros(chan,chan,ceil(length/frame));
%         indx2 = zeros(chan,chan,ceil(length/frame));
%         nets_round = zeros(chan*(chan-1)/2,1);
%         indx_round = zeros(chan*(chan-1)/2,1);
% 
%         for time = 1:frame:length
%             timestop    = min(time+frame-1,length);
%             timemoments = timemoments + 1;
%             k = 1;
%             for i = 1:chan
%                 for j = i+1:chan
%                     [nets_round(k),indx_round(k)] = ...
%                         corr(data(time:timestop,i), ...
%                              data(time:timestop,j));
%                     k = k+1;
%                 end
%             end
%             nets2(:,:,timemoments) = squareform(nets_round);
%             indx2(:,:,timemoments) = squareform(indx_round);
%         end
%         toc
%         
%         nets(:,:,1)
%         nets2(:,:,1)
%         assert(isequal(nets,nets2))
%         assert(isequal(indx,indx2))
        
    else 
        nets = zeros(chan,chan,ceil(length/frame));

        for time = 1:frame:length
            timestop    = min(time+frame-1,length);
            timemoments = timemoments + 1;
            for i = 1:chan
                for j = 1:chan
                    if (i<j) || (i>j && ~symmetric)
                        nets(i,j,timemoments) = corr(data(time:timestop,i),...
                            data(time:timestop,j));
                    elseif (i>j && symmetric)
                        nets(i,j,timemoments) = nets(j,i,timemoments);
                    end
                end
            end
        end
    end
    fprintf('    Done!\n'); 
end

function [surrogate] = generate_surrogate_data(data,window,srate)
    
    [length chan] = size(data);
    frame         = window*srate;   % Length of each epoch
    timemoments   = 0;

    surrogate = zeros(length,chan);

    for time = 1:frame:length
        timestop    = min(time+frame-1,length);
        timemoments = timemoments + 1;
        surrogate(time:timestop,:) = FTsurrogates_matrix(data(time:timestop,:));
    end
end

function [cor,indx] = cross_corr(x,y,srate)
    lag        = floor(srate/4);
    [cor,indx] = max(abs(xcov(x,y,lag,'coeff')));
    indx       = indx-lag-1;
end

function [cor,indx] = cross_corr_no_zero_lag(x,y,srate)
    lag    = floor(srate/4);
    covmat = abs(xcov(x,y,lag,'coeff'));
% 1st way
%     [cor1,indx1] = max(covmat(1:lag));
%     [cor2,indx2] = max(covmat(lag+2:2*lag+1));
%     [cor,i]      = max(cor1,cor2);
%     if i==1
%         indx = indx1-lag-1;
%     else
%         indx = indx2-lag-1;
%     end
    
% 2nd way    
    covmat(lag+1) = -1;
    [cor,indx]    = max(covmat);
    indx          = indx-lag-1;

% 3rd way
%     covmat = [covmat(1:lag); covmat(lag+2:end)];
%     [cor,indx] = max(covmat);
%     indx = indx-lag-1;
end

function [cor,indx] = cross_corr_no_symmetric(x,y,srate)
    maxlag = floor(srate/4);
    covmat = abs(xcov(x,y,maxlag,'coeff'));
    
    corrmat = covmat(maxlag+2:2*maxlag+1) -...
              flipdim(covmat(1:maxlag),1);
    [cor,indx] = max(corrmat);
end

function coh = coherence(x,y,low,high,srate)
    [C,f]  = mscohere(x,y,[],[],[],srate);
    low_i  = find(f>low,1,'first'); 
    high_i = find(f<high,1,'last'); 
    coh    = max(C(low_i:high_i));
end

function coh = mean_coherence(x,y,low,high,srate)
    [C,f]  = mscohere(x,y,[],[],[],srate);
    low_i  = find(f>low,1,'first');
    high_i = find(f<high,1,'last');
    coh    = mean(C(low_i:high_i));
end

function coh = mean_imaginary_coherence(x,y,low,high,srate)
    [C,f]  = imaginary_coherence(x,y,srate);
    low_i  = find(f>low,1,'first');
    high_i = find(f<high,1,'last');
    coh    = mean(C(low_i:high_i));
end

function coh = coherence_freq_bands(x,y,srate)
    global GAMMA_MAX
    [C,f]  = mscohere(x,y,[],[],[],srate);
    
    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = max(C(fband_indx_start:fband_indx_stop));
    end
end

function coh = mean_coherence_freq_bands(x,y,srate)
    global GAMMA_MAX
    [C,f]  = mscohere(x,y,[],[],[],srate);
    
    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = mean(C(fband_indx_start:fband_indx_stop));
    end
end

function coh = imaginary_coherence1(x,y,srate)
    global GAMMA_MAX
    [C,f]  = imaginary_coherence(x,y,srate);
    
    low_i  = find(f>1,1,'first'); 
    high_i = find(f<GAMMA_MAX,1,'last');
    
    coh = max(abs(C(low_i:high_i)));
end

function coh = imaginary_coherence_freq_bands(x,y,srate)
    global GAMMA_MAX
    [C,f]  = imaginary_coherence(x,y,srate);
    
    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = max(abs(C(fband_indx_start:fband_indx_stop)));
    end
end

function coh = reduced_coherence_freq_bands(x,y,distance,srate)
%
% Reduced coherence = Coherence - Random coherence (Nunez et al. 1997)
%   distance is the distance (on the scalp) between the two electrodes (cm)
%
    global GAMMA_MAX
    [C,f]  = mscohere(x,y,[],[],[],srate);
    
    % Reduced coherence = Coherence - Random coherence (Nunez et al. 1997)
    a = 3;      % A constant with approximate range 3-5
    C = C - exp((1-distance)/a);    

    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = max(C(fband_indx_start:fband_indx_stop));
    end
end

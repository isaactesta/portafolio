function r = time_diffs_to_index(evtimes,inittime,srate)

    if nargin<3
        srate = 200;
    end
    
    n = size(evtimes,1);
    dt = zeros(n,4);
    
    for i=1:n
        dt(i,:) = time_diff(evtimes(i,:),inittime);
    end
    
    r = (dt(:,1)*3600+dt(:,2)*60+dt(:,3))*srate + dt(:,4)*srate/1000 + 1;
end
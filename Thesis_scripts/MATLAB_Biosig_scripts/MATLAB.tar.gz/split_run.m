% Set in and out file names
infilename  = '/home/epilepsy/Exports/XLTEK/II-9fee1/CLEAN_DATA/Export1.mat';
outfilename = '/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/Export1_ica.mat';

matin   = matfile(infilename);
matout  = matfile(outfilename,'Writable',true);

% Set the variable to split on
info    = whos(mat,'data');
n       = info.size(1);

% Set the number of lines PER ITERATION
nlocal  = 10000000;

for i = 1:ceil(n/nlocal)
    start_row   = (i-1)*nlocal+1;
    end_row     = min(i*nloc,n);
    data        = matin.data(start_row:end_row,:);
    
    % Get rid of NaN values
    data(isnan(data)) = 0;
    
    % Do whatever with the piece of data
    ica_data = ...
        
    % Save this part to the output file
    matout.ica_data(start_row:end_row,1:21) = ica_data;
    
    matout.annot_events = matin.annot_events;
    
end

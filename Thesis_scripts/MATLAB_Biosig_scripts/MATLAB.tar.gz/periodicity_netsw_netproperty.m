function C = periodicity_netsw_netproperty(dir,mainfile,experiment, property,thresholds)

    patient_title     = patient_to_str_public(dir);
    property_title    = fname_to_str(property);
%     x_axis_title      = '24h time';
    x_axis_title_per  = 'Time lag (hours)';
    
    load([dir '/' mainfile '.mat'],'srate','starttime','seizstart','seizend',...
         'sleepstart','sleepend','sleep_annot');
    if ~exist('sleep_annot','var') sleep_annot = []; end;
    load([dir '/' mainfile '/' experiment '/nets.mat'],'nets_w5');
    figdir = [dir '/' mainfile '/' experiment '/window=5/threshold=' num2str(thresholds(1))];
    
    [~, ~, timemoments, networks] = size(nets_w5);
    x_axis_values_per = [-(timemoments-1)*5/3600:5/3600:(timemoments-1)*5/3600];

    for j=1:networks
        if (networks==1)
            net_filename = '';
            net_title = '';
        else
            net_filename = ['_' strrep(network_to_freq_str(j),' band','')];
            net_title = network_to_freq_str(j);
        end
        
        
        for tr = 1:size(thresholds,2)
            nets_bin = binarize(nets_w5,thresholds(tr));
            for t=1:timemoments
               %for j=1:networks
                   C(t,tr) = feval(property,nets_bin(:,:,t,j));
               %end
            end

            C2(:,tr) = C(:,tr) - mean(C(:,tr),1);
            C3(:,tr) = remove_mean(C(:,tr),0.98);
            C3(:,tr) = C3(:,tr)'+min(C3(:,tr));
            
    %        C3a = C3 - mean(C3,2);

            autocorrelation = xcorr(C2(:,tr), 'unbiased');
            display('Done autocorrelating...');
            normalized_autocorrelation(:,tr) = autocorrelation./autocorrelation(timemoments);
            display('Done normalizing...');

%             T = size(C2(:,tr),1);
%             if nargin<6
%                 wsize = T;
%                 o = 0;
%             end
%             normalized_autocorrelation = zeros(2*wsize-1,size(thresholds,2));
%             middle = wsize;
%             for i=1:wsize-o:T-wsize+1
%                 autocorrelation = xcorr(C2(i:min(i+wsize-1,T),tr), 'unbiased');
%                 %display('Done autocorrelating...');
%                 normalized_autocorrelation(:,tr) = normalized_autocorrelation(:,tr) + autocorrelation./autocorrelation(middle);
%                 %display('Done normalizing...');
%             end

        end     % for thresholds
        
        figtitle = [patient_title ' - ' property_title ' ' net_title];
        % Plot property WITH sleep stages...
        g = plot_with_events(C3,srate,sleep_annot,starttime,figtitle,seizstart,seizend,sleepstart,sleepend);
        % ... or plot property WITHOUT sleep stages
        %g = plot_with_events(C3,srate,[],starttime,figtitle,seizstart,seizend,sleepstart,sleepend);
        if ~exist(figdir,'dir') mkdir(figdir); end;
        saveas(g, [figdir '/' property net_filename '.jpg']);
        saveas(g, [figdir '/' property net_filename '.fig']);
        close;
       
        % Figure plotting the periodicity
        h = figure;
        leave_out_values = 550;
        % Plot autocorrelation's both positive and negative values...
        %plot(x_axis_values_per(leave_out_values+1:2*timemoments-leave_out_values-1),normalized_autocorrelation(leave_out_values+1:2*timemoments-leave_out_values-1,:));
        % ... or plot only positive values
        plot(x_axis_values_per(timemoments+1:2*timemoments-leave_out_values-1),normalized_autocorrelation(timemoments+1:2*timemoments-leave_out_values-1,:));
        title([patient_title ' - ' property_title ' ' net_title ' autocorrelation']);
        xlabel(x_axis_title_per);
        set(findall(gcf,'type','text'),'fontSize',24);
        set(findall(gcf,'type','axes'),'fontsize',14);

        saveas(h, [figdir '/periodicity_' property net_filename '.jpg']);
        saveas(h, [figdir '/periodicity_' property net_filename '.fig']);

        %close;
        
    end    % for networks
end
function [ bipolar_data ] = xltek_to_bipolar_sleepannot(data)
%XLTEK_TO_BIPOLAR Converts the XLTEK raw data to six bipolar channels used in sleep annotation
%   Assumes that rows are time moments and cols are channels
%
% Manolis Christodoulakis @ 2014

    if (nargin<2)
        ncols = 18;
    end
    
    nlines       = size(data,1);
    bipolar_data = zeros(nlines,6);

    bipolar_data(:,1)  = data(:,10) - data(:,2);   %   C3 - A2
    bipolar_data(:,2)  = data(:,16) - data(:,1);   %   C4 - A1
    bipolar_data(:,3)  = data(:,8) - data(:,2);    %   01 - A2
    bipolar_data(:,4)  = data(:,22) - data(:,1);   %   O2 - A1
    bipolar_data(:,5)  = data(:,23) - data(:,2);   %  LOC - A2
    bipolar_data(:,6)  = data(:,24) - data(:,1);   %  ROC - A1
end


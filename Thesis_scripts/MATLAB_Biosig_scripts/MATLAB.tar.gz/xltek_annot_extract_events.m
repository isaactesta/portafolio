function [evidx] = xltek_annot_extract_events(annot_file,indices,event)
% xltek_annot_extract_events extracts the positions of event inside indices
%
% Finds all occurrences of the event in the annotation file, and then
% matches their time of occurrence inside the cell array indices. Returns
% the index positions inside indices matching
%
% Manolis Christodoulakis @ 2014

    fprintf(['    Extracting locations of events ' event '... ']);
    
    % Find times that are annotated as event
    annot = import_annotations(annot_file);    
    %times = annot(find(strcmp([annot(:, 2)], event)));
    times = annot(strcmp(annot(:, 2), event));
    
    % Compute the corresponding positions within our data file
    [~,~,evidx] = intersect(times,indices);
    %event_times = evidx/srate;

    fprintf('Done!\n');
end

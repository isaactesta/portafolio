% Overnight script

% Calculate networks
montages     = {'bipolar'; 'ref'; 'avgref'};

correlations = {'cross-corr';                       % 1
                'cross-corr_no_zero_lag';           % 2
                'cross-corr_no_symmetric';          % 3
                'coherence';                        % 4
                'coherence_freq_bands';             % 5
                'mean_coherence';                   % 6
                'mean_coherence_freq_bands';        % 7
                'mean_imaginary_coherence';         % 8
                'imaginary_coherence';              % 9 
                'imaginary_coherence_freq_bands';   % 10
                'pli';                              % 11
                'pli_cpsd';                         % 12
                'wpli'};                            % 13

thresholds   = [0.75; 0.75; 0.5;
                0.75; 0.75; 
                0.4; 0.4;
                0.08;
                0.5; 0.5; 
                0.13; 0.55; 0.6]; 
            
filterings   = {'ICA'; 'f1-60_notch'; 'f1-45'; 'f1-50'; 'f1-60'; 
                'alpha'; 'beta'; 'gamma'; 'delta'; 'theta'; 
                'ICA_alpha'; 'ICA_beta'; 'ICA_gamma'; 'ICA_delta'; 
                'ICA_theta'}; 
            
long_seiz_mat = {'/home/manolisc/epilepsy/Exports/II-9fee1' 'Export1'; % I.I.
                 '/home/manolisc/epilepsy/Exports/MC-95a3a' 'Export1'; % M.C.
                 '/home/manolisc/epilepsy/Exports/TK-c840d' 'Export1'; % T.K.
                 '/home/manolisc/epilepsy/Exports/HE-bb167' 'Export1-2'; % H.E.
                 '/home/manolisc/epilepsy/Exports/MG-f84c1' 'Export1-2part'; % M.G.
                 '/home/manolisc/epilepsy/Exports/DP-98304' 'Export1'; % Psychogenic
                 '/home/manolisc/epilepsy/Exports/GM-10837' 'Export1';
                 '/home/manolisc/epilepsy/Exports/MV-5859' 'Export1-2';
                 '/home/manolisc/epilepsy/Exports/RC-4337' 'Export1-2';
};

mrange = 1;
crange = 1;%[1 3 13];
frange = 3;
srange = 1;
for m = mrange
    for c = crange
        for f = frange
            for s = srange
                disp(long_seiz_mat(s,1));
                disp(long_seiz_mat(s,2));
                disp(montages(m));
                disp(correlations(c));
                disp(filterings(f));
                testing_measures_mat(long_seiz_mat{s,1},long_seiz_mat{s,2},montages{m},correlations{c},filterings{f},thresholds(c));
            end
        end
    end
end

% Calculate periodicities

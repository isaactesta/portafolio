function p = wpli(x,y)

% %% remove dc
x=x-mean(x);
y=y-mean(y);

% get cross-spectrum and its imaginary part
cross_spectrum = cpsd(x,y);
cpsd_imag = imag(cross_spectrum);

% PLI
% p = abs(mean((abs(cpsd_imag)).*(sign(cpsd_imag))))./mean(abs(cpsd_imag));
p = abs(mean(cpsd_imag))./mean(abs(cpsd_imag));
    
end
clear;
montages = {'bipolar'; 'ref'; 'avgref'};
m_titles = {'Bipolar'; 'Common ref.'; 'Average ref.'};   

for m = 1:3
    % Load the data
    datafile = ['/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/' montages{m} '__ICA__cross-corr/data.mat']
    load(datafile,'node_data');
    
    data = node_data';
    %clear node_data;
    node_data = eegfilt(data,200,0,20);
    node_data = node_data';
    
    % Compute correlations, normal and corrected
    wlength  = 60;
    srate    = 200;
    lag      = srate;
    [ndatapoints,nchannels] = size(node_data);
    nwindows = ndatapoints/(wlength*srate)
    ncorrs   = nwindows*(nchannels-1)*(nchannels-2)/2;

    correlations = zeros(nchannels,nchannels,2*lag+1,nwindows);
    %corrected_correlations = zeros(nchannels,nchannels,lag,nwindows);

    w = 1;
    for wstart=1:wlength*srate:ndatapoints
        wend = wstart + wlength*srate -1;
        for i = 1:nchannels
            for j=i+1:nchannels
                correlations(i,j,:,w) = xcov(node_data(wstart:wend,i),node_data(wstart:+wend,j),lag,'coeff');
                %corrected_correlations(i,j,:,w) = correlations(i,j,lag+2:2*lag+1,w) - 
            end
        end
        w = w +1;
    end
    
    % Plot one window per period (pre-, post-, ictal), average over channels
%     periods = [ floor(nwindows/4);
%                 floor(nwindows/2+10);
%                 floor(3*nwindows/4)];
    periods = [ floor(5);
                floor(16);
                floor(25)];
    p_titles = {'inter-ictal' 'ictal' 'post-ictal'}; 
    mean_corr_at_lag = zeros(2*lag+1,3);
    up_bound=mean_corr_at_lag;
    low_bound=mean_corr_at_lag;

    h = figure; hold all;
    for p = 1:3
        corr = correlations(:,:,:,periods(p));
        
        for i=1:2*lag+1
            corr_at_lag = corr(:,:,i);  % A single window for a lag
            corr_at_lag = corr_at_lag(itriu(size(corr_at_lag),1));  % vectorize upper triangular (non-zero) part
            rect_corr=abs(corr_at_lag);
            mean_corr_at_lag(i,p) = median(rect_corr);
            up_bound(i,p) = prctile(rect_corr,97.5);
            low_bound(i,p) = prctile(rect_corr,2.5);
        end
        plot(-lag:lag, mean_corr_at_lag(:,p)); 
%         plot(-lag:lag, up_bound(:,p),'k:'); 
%         plot(-lag:lag, low_bound(:,p),'k:'); 
    end
    legend(p_titles);
    title([m_titles{m} ' - Cross-correlation over lags']);
    saveas(h,[strrep(datafile,'data.mat',[montages{m} '_cross_corr_over_lags']) '.jpg']);
%    close;
    
    h = figure; hold all;
    mean_corr_at_lag = zeros(lag,3);
    for p = 1:3
        corr1 = correlations(:,:,:,periods(p));
        corr = corr1(:,:,lag+2:2*lag+1) - flipdim(corr1(:,:,1:lag),3);
        for i=1:lag
            corr_at_lag = corr(:,:,i);  % A single window for a lag
            corr_at_lag = corr_at_lag(itriu(size(corr_at_lag),1));  % vectorize upper triangular (non-zero) part
            rect_corr=abs(corr_at_lag);
            mean_corr_at_lag(i,p) = median(rect_corr);
%             up_bound(i,p) = prctile(rect_corr,97.5);
%             low_bound(i,p) = prctile(rect_corr,2.5);
        end
        plot(1:lag, mean_corr_at_lag(:,p)); 
    end
    legend(p_titles);
    title([m_titles{m} ' - Corrected cross-correlation over lags']);
    saveas(h,[strrep(datafile,'data.mat',[montages{m} '_corrected_cross_corr_over_lags']) '.jpg']);
%    close;

end
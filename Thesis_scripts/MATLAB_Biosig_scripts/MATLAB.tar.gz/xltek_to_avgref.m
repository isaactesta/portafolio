function [ avgref_data ] = xltek_to_avgref( data )
%XLTEK_TO_AVGREF Converts the XLTEK raw data to average ref
%   Assumes that rows are time moments and cols are channels
%
% Manolis Christodoulakis @ 2012

    nlines      = size(data,1);
    avgref_data = zeros(nlines,19);

    % Find the mean of the eeg channels at each time point
    avg = mean(data,2);

    % Subtract the mean
    for i=1:19
        avgref_data(:,i) = data(:,3+i) - avg;
    end     
end
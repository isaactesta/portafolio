function testing_measures(dir,seizid)
% Tests various measures, thresholds, window-sizes etc.

    %windows = [5 10 20];
    windows = [10];

    % Load (or create) cross correlations
    if ~exist_nets_weighted(dir,seizid,windows)
        create_nets_weighted(dir,seizid,windows);
    end    
    load([dir '/seizure_' seizid '/data.mat']);
    
    % Temp
%    event_times    = get_events(dir,indices);
%    save([subdir '/data.mat']);
    
    % Binarize and plot
    for window_size = windows
        for threshold = 0.75:0.1:0.75 %0.65:0.1:0.85
            varname = ['nets_w' num2str(window_size)];
            eval(['nets = binarize(' varname ',threshold);']);
            plot_all(nets,window_size,evstart,evend);
            save_plots(dir,seizid,...
                ['window=' num2str(window_size)],...
                ['threshold=' num2str(threshold)]);
        end
    end
end

function [doesexist]=exist_nets_weighted(dir,seizid,windows)
    disp('Checking existence of correlations and events...');
    
    doesexist = false;
    datafile = [dir '/seizure_' seizid '/data.mat'];
    if exist(datafile)
        load(datafile)
    else 
        return;
    end
    
    for w = windows
        if ~exist(['nets_w' int2str(w)],'var')
            return;
        end
    end
    
    if ~exist('evstart','var') | ~exist('evend','var')
        return;
    end
    
    disp('Yes, all data do exist!...');
    doesexist = true;
end

function create_nets_weighted(dir,seizid,windows)
    fprintf('Creating correlation networks...\n');
    
    % Import the data and the annotations
    source         = [dir '/seizure_' seizid '.txt'];
    [data,indices] = importEEG(source,0);
    evstart   = get_events_start(dir,indices);
    evend     = get_events_end(dir,indices);

    % Filter the data (also removes channels 26-36)
    filtered_data = filter(data);

    % Cross-correlate
    for window_size = windows
        %nets_weighted = correlate_all(filtered_data,window_size);
        eval([genvarname(['nets_w' int2str(window_size)])...
            '=correlate_all(filtered_data,window_size);'])
    end

    subdir = [dir '/seizure_' seizid];
    if ~exist(subdir,'dir')
        mkdir(subdir);
    end
    
    save([subdir '/data.mat']);

    fprintf('... Done creating correlation networks!\n');
end

function [event_times] = get_events_start(dir,indices)
    fprintf('Extracting locations where events start... ');
    
    % Find times that are annotated as 'start'
    annot = import_annotations([dir '/annotations.txt']);    
    times = annot(find(strcmp([annot(:, 2)], 'start')));
    
    % Compute the corresponding seconds within our data file
    SRATE       = 200;
    [~,~,evidx] = intersect(times,indices);
    event_times = evidx/SRATE;

    fprintf('Done!\n');
end

function [event_times] = get_events_end(dir,indices)
    fprintf('Extracting locations where events end... ');
    
    % Find times that are annotated as 'start'
    annot = import_annotations([dir '/annotations.txt']);    
    times = annot(find(strcmp([annot(:, 2)], 'end')));
    
    % Compute the corresponding seconds within our data file
    SRATE       = 200;
    [~,~,evidx] = intersect(times,indices);
    event_times = evidx/SRATE;

    fprintf('Done!\n');
end


function [filtered_data]=filter(data)
    disp('Filtering... ');

    filtered_data = detrend(data(:,1:25));
    
    filtered_data = filtered_data';
    [filtered_data]=eegfilt(filtered_data,200,1,0);
    [filtered_data]=eegfilt(filtered_data,200,0,50);
    filtered_data = filtered_data';
    
    %fprintf('Done!\n');
end

function [nets]=correlate_all(data,window)
    fprintf(['Correlating (window = ' num2str(window) ')... ']);

    SRATE = 200;            % sampling rate, 200Hz
    
    [length ~] = size(data);
    frame = window*SRATE;
    timemoments = 0;
    nets = zeros(22,22,length/frame);
    for time = 1:frame:length
        timestop = min(time+frame-1,length);
        timemoments = timemoments + 1;
        for i = 1:22
            for j = 1:22
                if i~=j
                    [nets(i,j,timemoments) ~] = kramer_edge_weighted(...
                        data(time:timestop,i), data(time:timestop,j));
                        %max(abs(xcov(data(time:timestop,i),...
                        %data(time:timestop,j),50,'coeff')));
                end
            end
        end
    end
    
    fprintf('Done!\n'); 
end

function [nets]=binarize(nets,threshold)
    fprintf(['Binarizing network (threshold = ' num2str(threshold) ')... ']);
    
    %nets = nets_weighted;
    nets(nets>threshold|nets<-threshold)=1;
    nets(nets<1)=0;
    
    fprintf('Done!\n');
end

function plot_all(nets,duration,evstart,evend)
    fprintf('Plotting... ');
    
    plot_nodes_property('degrees_und',nets,duration,evstart,evend);
    plot_nodes_property('betweenness_bin',nets,duration,evstart,evend);
    plot_nodes_property('clustering_coef_bu',nets,duration,evstart,evend);
    plot_nodes_property('charpath',nets,duration,evstart,evend);
    plot_nodes_property('betweenness_centralization_bin',nets,duration,evstart,evend);
    plot_nodes_property('network_clustering_WS_bu',nets,duration,evstart,evend);
    plot_nodes_property('network_clustering_NMW_bu',nets,duration,evstart,evend);
    plot_nodes_property('efficiency_bin',nets,duration,evstart,evend);
    plot_nodes_property('network_smallworldness_WS_bu',nets,duration,evstart,evend);
    plot_nodes_property('network_smallworldness_NMW_bu',nets,duration,evstart,evend);
    
    fprintf('Done!\n');
end

function save_plots(dir,seizid,subdir1,subdir2)
    fprintf('Saving... ');

    subdir = [dir '/seizure_' seizid '/' subdir1 '/' subdir2];
    if ~exist(subdir,'dir')
        mkdir(subdir);
    end
    
    movefile('*.jpg',subdir);

    fprintf('Done!\n');
end
function testing_measures(dir,seizid,clean_data,clean_method)
% Tests various measures, thresholds, window-sizes etc.
% clean_data is optional matrix (records,channels). If it is given, 
% data will be taken from that matrix instead of the file

    
    global NET CORR FILT OUTDIR WINDOWS

    % Size of window to consider (5 for cross-corr, 10 for kramer)
    WINDOWS = [10];% 10 20];
    
    % Type of nodes in the network: 'single', 'ref' or 'bipolar'
    NET = 'ref'
    
    % Type of correlation: 'cross-corr', 'kramer' or 'coherence'
    CORR = 'coherence'
    
    % Type of filtering: 'detrend', 'f1-50', or 'f1-50_regression'
    %       'alpha' (8-13Hz), 'beta' (13-30Hz), 'gamma' (30-60Hz), 
    %       'delta' (1-4Hz), 'theta' (4-8Hz)
    % Is not used when clean data are passed (args. 3 & 4)
    FILT = 'theta' 
    
    % The output directory
    OUTDIR = [dir '/seizure_' seizid '/' NET '__' FILT '__' CORR];
    if (nargin==3)
        error('Please specify the cleaning method of the data');
    elseif (nargin==4)
        OUTDIR = [OUTDIR '__' clean_method]
    else
        OUTDIR
    end
    
    % Load (or create) cross correlations
    if ~exist_nets_weighted
        if (nargin<3)
            create_nets_weighted(dir,seizid);
        else
            create_nets_weighted(dir,seizid,clean_data,clean_method);
        end
    end    
    load([OUTDIR '/data.mat']);
    
    % Binarize and plot
    for window_size = WINDOWS
        for threshold = 0.75:0.05:0.95 %0.65:0.1:0.85
            varname = ['nets_w' num2str(window_size)];
            eval(['nets = binarize(' varname ',threshold);']);
            plot_all(nets,window_size,evstart,evend);
            save_plots(OUTDIR,...
                ['window=' num2str(window_size)],...
                ['threshold=' num2str(threshold)]);
        end
    end
    global sw
    %sw
    clear;
end

function [doesexist]=exist_nets_weighted()
    disp('Checking existence of correlations and events...');
    
    doesexist = false;
    global OUTDIR WINDOWS
    
    datafile = [OUTDIR '/data.mat'];
    
    if exist(datafile)
        load(datafile,'nets_w*','evstart','evend')
    else 
        return;
    end
    
    for w = WINDOWS
        if ~exist(['nets_w' int2str(w)],'var')
        	disp(['nets_w' int2str(w) ' does not exist!']);
            return;
        end
    end
    
    if ~exist('evstart','var') | ~exist('evend','var')
        return;
    end
    
    disp('Yes, all data do exist!...');
    doesexist = true;
end

function create_nets_weighted(dir,seizid,clean_data_file,clean_method)
    fprintf('Creating correlation networks...\n');
    
    % Import the data and the annotations
    source         = [dir '/seizure_' seizid '.txt'];
    if (nargin<3)
        [data,indices] = importEEG(source,0);
    else
        [~,indices] = importEEG(source,0);
        % Load clean data (EEG data structure)
        clear EEG;
        load([dir '/clean_data/' clean_data_file]);
        if strcmp(clean_method,'ICA')
            [moments,channels] = size(remove_eyes_ICA);
            % Transpose EEGLab's data and add zero col. 3
            data = zeros(moments,channels+1);
            data(:,1:2) = remove_eyes_ICA(:,1:2);
            data(:,4:channels+1) = remove_eyes_ICA(:,3:channels);            
        else
            [channels,moments] = size(EEG.data);
            % Transpose EEGLab's data and add zero col. 3
            data = zeros(moments,channels+1);
            data(:,1:2) = EEG.data(1:2,:)';
            data(:,4:channels+1) = EEG.data(3:channels,:)';
        end
    end
    [nlines ~] = size(data);
    evstart   = get_events(dir,indices,'start');
    evend     = get_events(dir,indices,'end');

    global NET FILT OUTDIR WINDOWS
    
    % Type of network nodes
    if strcmp(NET,'single')
        node_data = data(:,4:22);
    elseif strcmp(NET,'ref')
        % Append eye channels
        if strcmp(FILT,'f1-50_regression')
            node_data = zeros(nlines,20);
            node_data(:,19:20) = data(:,23:24);
        else
            node_data = zeros(nlines,18);
        end
        
        % Subtract Cz
        node_data(:,1:9) = data(:,4:12) - repmat(data(:,13),1,9);
        node_data(:,10:18) = data(:,14:22) - repmat(data(:,13),1,9);
%         if (nargin<3)
%             node_data(:,1:9) = data(:,4:12) - repmat(data(:,13),1,9);
%             node_data(:,10:18) = data(:,14:22) - repmat(data(:,13),1,9);
%         else  % clean data is provided (missing cols 1-3)
%             node_data(:,1:9) = data(:,1:9) - repmat(data(:,10),1,9);
%             node_data(:,10:18) = data(:,11:19) - repmat(data(:,10),1,9);
%         end
        
    elseif strcmp(NET,'bipolar')
        node_data = zeros(nlines,22);
        node_data(:,1) = data(:,4) - data(:,5);
        node_data(:,2) = data(:,5) - data(:,6);
        node_data(:,3) = data(:,6) - data(:,7);
        node_data(:,4) = data(:,7) - data(:,8);
        node_data(:,5) = data(:,18) - data(:,19);
        node_data(:,6) = data(:,19) - data(:,20);
        node_data(:,7) = data(:,20) - data(:,21);
        node_data(:,8) = data(:,21) - data(:,22);
        node_data(:,9) = data(:,4) - data(:,9);
        node_data(:,10) = data(:,9) - data(:,10);
        node_data(:,11) = data(:,10) - data(:,11);
        node_data(:,12) = data(:,11) - data(:,8);
        node_data(:,13) = data(:,18) - data(:,15);
        node_data(:,14) = data(:,15) - data(:,16);
        node_data(:,15) = data(:,16) - data(:,17);
        node_data(:,16) = data(:,17) - data(:,22);
        node_data(:,17) = data(:,12) - data(:,13);
        node_data(:,18) = data(:,13) - data(:,14);
        node_data(:,19) = data(:,4) - data(:,27);
        node_data(:,20) = data(:,27) - data(:,7);
        node_data(:,21) = data(:,18) - data(:,28);
        node_data(:,22) = data(:,28) - data(:,21);
    end
    
    % Filter the data
    if (nargin<3)
        if strcmp(FILT,'detrend')
            filtered_data = detrend(node_data);
        elseif strcmp(FILT,'f1-50')
            filtered_data = filter(node_data,1,50);
        elseif strcmp(FILT,'alpha')
            filtered_data = filter(node_data,8,13);
        elseif strcmp(FILT,'beta')
            filtered_data = filter(node_data,13,30);
        elseif strcmp(FILT,'gamma')
            filtered_data = filter(node_data,30,60);
        elseif strcmp(FILT,'delta')
            filtered_data = filter(node_data,1,4);
        elseif strcmp(FILT,'theta')
            filtered_data = filter(node_data,4,8);
        elseif strcmp(FILT,'f1-50_regression')
            % Remove artifacts with regression
            filtered_data = remove_artifacts(node_data); 
        else
            error(['Unknown filtering function: ' FILT]);
        end
    else    % Clean data have been provided
        filtered_data = node_data;
    end

    % Cross-correlate
    for window_size = WINDOWS
        %nets_weighted = correlate_all(filtered_data,window_size);
        eval([genvarname(['nets_w' int2str(window_size)])...
            '=correlate_all(filtered_data,window_size);'])
    end

    if ~exist(OUTDIR,'dir')
        mkdir(OUTDIR);
    end
    
    save([OUTDIR '/data.mat']);

    fprintf('... Done creating correlation networks!\n');
end

function [event_times] = get_events(dir,indices,event)
    fprintf(['Extracting locations of events ' event '... ']);
    
    % Find times that are annotated as 'start'
    annot = import_annotations([dir '/annotations.txt']);    
    times = annot(find(strcmp([annot(:, 2)], event)));
    
    % Compute the corresponding seconds within our data file
    SRATE       = 200;
    [~,~,evidx] = intersect(times,indices);
    event_times = evidx/SRATE;

    fprintf('Done!\n');
end

function [filtered_data]=filter(data,low,high)
    disp('Filtering... ');

    filtered_data = detrend(data);
    
    filtered_data = filtered_data';
    [filtered_data]=eegfilt(filtered_data,200,low,0);
    [filtered_data]=eegfilt(filtered_data,200,0,high);
    filtered_data = filtered_data';
    
    %fprintf('Done!\n');
end

function [nets]=correlate_all(data,window)
    fprintf(['Correlating (window = ' num2str(window) ')... ']);

    global CORR

    SRATE        = 200;      % Sampling rate, 200Hz
    symmetric    = 0;        % Symmetric correlation measure     
    
    [length chan] = size(data);
    frame = window*SRATE;
    timemoments = 0;
    nets = zeros(chan,chan,ceil(length/frame));
    
    if strcmp(CORR,'kramer')
        corr      = @kramer_edge_weighted;
        symmetric = 1; 
    elseif strcmp(CORR,'cross-corr')
        corr      = @(x,y)  max(abs(xcov(x,y,50,'coeff')));
        symmetric = 1; 
    elseif strcmp(CORR,'coherence')
        corr      = @(x,y) coherence(x,y,2,100);
        symmetric = 1; 
    elseif strcmp(CORR,'mutualinfo')
        corr      = @mutualinf;
        symmetric = 1; 
    else
        error(['Unknown correlation function: ' CORR]);
    end
    
    for time = 1:frame:length
        timestop    = min(time+frame-1,length);
        timemoments = timemoments + 1;
        for i = 1:chan
            for j = 1:chan
                if (i<j) | (i>j & ~symmetric)
                    nets(i,j,timemoments) = corr(data(time:timestop,i),...
                        data(time:timestop,j));
                elseif (i>j & symmetric)
                    nets(i,j,timemoments) = nets(j,i,timemoments);
                end
            end
        end
    end
    
    fprintf('Done!\n'); 
end

function [nets]=binarize(nets,threshold)
    fprintf(['Binarizing network (threshold = ' num2str(threshold) ')... ']);
    
    nets(nets>threshold|nets<-threshold)=1;
    nets(nets<1)=0;
    
    fprintf('Done!\n');
end

function plot_all(nets,duration,evstart,evend)
    fprintf('Plotting... ');
    
    frames = size(nets,3);
    distances = nets;
    for i=1:frames
        distances(:,:,i) = distance_bin(nets(:,:,i));
    end
    
    plot_nodes_property('degrees_und',nets,duration,evstart,evend);
    plot_nodes_property('average_degree_und',nets,duration,evstart,evend);
    plot_nodes_property('betweenness_bin',nets,duration,evstart,evend);
    plot_nodes_property('clustering_coef_bu',nets,duration,evstart,evend);
    plot_nodes_property('charpath',distances,duration,evstart,evend);
    plot_nodes_property('betweenness_centralization_bin',nets,duration,evstart,evend);
    plot_nodes_property('network_clustering_WS_bu',nets,duration,evstart,evend);
    plot_nodes_property('network_clustering_NMW_bu',nets,duration,evstart,evend);
    plot_nodes_property('efficiency_bin',nets,duration,evstart,evend);
    plot_nodes_property('network_smallworldness_WS_bu',nets,duration,evstart,evend);
    plot_nodes_property('network_smallworldness_NMW_bu',nets,duration,evstart,evend);
    
    fprintf('Done!\n');
end

function save_plots(dir,subdir1,subdir2)
    fprintf('Saving... ');
    
    subdir = [dir '/' subdir1 '/' subdir2];
    if ~exist(subdir,'dir')
        mkdir(subdir);
    end
    
    movefile('*.jpg',subdir);

    fprintf('Done!\n');
end

function coh = coherence(x,y,low,high)
    [C,f]  = mscohere(x,y,[],[],[],200);
    low_i  = find(f>low);
    high_i = find(f>high-1); 
    coh    = max(C(low_i(1):high_i(1)));
end

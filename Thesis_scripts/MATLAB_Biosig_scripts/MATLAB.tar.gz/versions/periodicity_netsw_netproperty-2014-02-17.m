function periodicity_netsw_netproperty(filename,property,threshold)

    % patient = regexp(filename,'Exports/(.+)/seizure','tokens');   % Just
    % keep the main folder
    patient_title = patient_to_str(filename);
    property_title = fname_to_str(property);
    x_axis_title = 'Time (hours)';
    
    load(filename,'nets_w5','evstart','evend');
    nets_bin = binarize(nets_w5,threshold);
    
    [~, ~, timemoments, networks] = size(nets_bin);
    x_axis_values = [5/3600:5/3600:timemoments*5/3600];     % Set the time scale to hours
    x_axis_values_per = [-(timemoments-1)*5/3600:5/3600:(timemoments-1)*5/3600];

    for t=1:timemoments
        for j=1:networks
           C(:,t,j) = feval(property,nets_bin(:,:,t,j));
        end
    end
    
    for j=1:networks
        if (networks==1)
            net_filename = '';
            net_title = '';
        else
            net_filename = ['_' strrep(network_to_freq_str(j),' band','')];
            net_title = network_to_freq_str(j);
        end
        
        C2 = C(:,:,j) - mean(C(:,:,j),2);
        C3 = remove_mean(C(:,:,j),0.98);
        C3 = C3'+min(C3);
%        C3a = C3 - mean(C3,2);

        g = figure;
%         plot(x_axis_values,C,'g'); hold on;
%        plot(C2,'r'); hold on;     % Unsmoothed data
%         plot(C3,'y'); hold on;
        plot(x_axis_values, C3,'b'); hold on;             % Smoothed data
        xlabel(x_axis_title);
        title([patient_title ' - ' property_title ' ' net_title]);
        
        % Indicate specific events if there are any
        for e=evstart
            arrayfun(@(e) add_vline(e,'--'),e/3600);
        end

        
        figdir = strrep(filename,'data.mat',['window=5/threshold=' num2str(threshold)]);
        if ~exist(figdir,'dir') mkdir(figdir); end;
        saveas(g, [figdir '/' property net_filename '.jpg']);
        close;

        % Label x axis with time of day        
%         window = 5;
%         %tick_start = (18 + 34*60)/window; tick_start_label = 10;% 10.25.42 (M.C.)
%         tick_start = (55 + 28*60)/window; tick_start_label = 9; % 9.31.05 (I.I.)
%         tick_distance = 4*3600/window; % 4 hours
%         xtickat = tick_start:tick_distance:timemoments-1;
%         set(gca, 'XTick', xtickat, 'XTickLabel', cellstr( num2str( mod( tick_start_label + round(xtickat .' ./ (3600/window)),24) ) ) )

        h = figure;
        autocorrelation = xcorr(C2(1,:), 'unbiased');
        normalized_autocorrelation = autocorrelation./autocorrelation(timemoments);
        leave_out_values = 150;
        plot(x_axis_values_per(leave_out_values+1:2*timemoments-leave_out_values-1),normalized_autocorrelation(leave_out_values+1:2*timemoments-leave_out_values-1));
%        plot(x_axis_values_per,normalized_autocorrelation); %hold on
%        plot(xcorr(C2(1,:), 'biased'), 'r'); hold on;
%        plot(xcorr(C3a(1,:), 'biased'), 'g');
        
        %title([patient{1} ' - ' fname_to_str(property) ' ' int2str(j)]) %network_to_freq_str(j)])
        title([patient_title ' - ' property_title ' ' net_title ' autocorrelation']);
        xlabel(x_axis_title);
        
        saveas(h, [figdir '/periodicity_' property net_filename '.jpg']);
        saveas(h, [figdir '/periodicity_' property net_filename '.fig']);
        
        close;
    end
end
%% Test that nets differ across time
newline=0;
disp('test starts...');
[rows cols windows] = size(nets);
for i=1:windows
    for j=i+1:windows
        if (~isequal(nets(:,:,i),nets(:,:,j)))
            fprintf('%d~=%d ', i,j);
            newline=1;
        end
    end
    if (newline)
        fprintf('\n');
        newline=0;
    end
end
disp('...test finished');
clear newline i j newline rows cols windows

%% Test small fractions of xcorr to check whether they differ
col = 1;
for start=50001:100:51000
%    corr12(:,col) = xcorr(A(start:start+99,1),A(start:start+99,2),50,'coef');
    corr12(:,col) = corrcoef(A(start:start+99,1),A(start:start+99,2));
    [maxval(col),pos(col)] = max(abs(corr12(:,col)));
    col=col+1;
end
clear col start
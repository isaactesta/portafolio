% DEPRECATED Use kramer_edge_weighted instead.
%  A network edge between nodes (time series) x and y, using cross correlation as described by Kramer et. al 2008
function edge=kramer_edge(x,y)

SRATE = 200;            % sampling rate, 200Hz
WINDOW = 1;             % 1s windows
SHIFT = 0.5;            % 0.5s shift between consecutive windows
MAXLAGS = 0.25;         % 0.25s maximum lag for xcorr
THRESHOLD = 0.95;       % Threshold of correlation signal
MAXACCEPTEDLAG=0.15;    % Maxvalue will be accepted only if it occurred
                        % within this time lag

n = size(x);        % number of rows of each signal
m = size(y);    

if (n~=m)
    warning('The datasets are not of equal size');
    return;
end

%MAXVALS(1:ceil((n-WINDOW*SRATE+1)/(SHIFT*SRATE)))=0;
%POSITIONS(1:ceil((n-WINDOW*SRATE+1)/(SHIFT*SRATE)))=0;

edge = 0;           % Initially we assume there is no edge
k=1;
for i=1:SHIFT*SRATE:n-WINDOW*SRATE+1
    j=min(i+WINDOW*SRATE-1,n);

% Try unbiased
%    [maxval,pos] = max(abs(xcorr(x(i:j),y(i:j),MAXLAGS*SRATE,'coeff')));
    [maxval,pos] = max(abs(xcorr(x(i:j)-mean(x(i:j)),y(i:j)-mean(y(i:j)),...
                   MAXLAGS*SRATE,'unbiased')/(std(x(i:j))*std(y(i:j)))));
    
 %    MAXVALS(k)=maxval;
 %    POSITIONS(k)=pos;
 %    k=k+1;
 
 % Make non-binary for testing
 edge = maxval;
 %   if (maxval>THRESHOLD && abs(pos)<MAXACCEPTEDLAG*SRATE)
 %       edge = 1;   % Strong correlation, thus edge should be there
 %       break;      % Once a connection is found no need to search further
 %   end
end

% *** Attempt to vectorize the loop above
%beg=[1:SHIFT*SRATE:n-WINDOW*SRATE+1];
%fin=beg+WINDOW*SRATE-1;
%M = zeros(19);
%P = zeros(19);
%[M,P]=arrayfun(@(a,b) max(abs(xcorr(x(a:b),y(a:b),MAXLAGS*SRATE,'coef'))),beg,fin,'UniformOutput', true);
%MAXVALS
%POSITIONS
end
function C3 = periodicity_netsw_netproperty(dir,mainfile,experiment, property,thresholds)

    patient_title     = patient_to_str(dir);
    property_title    = fname_to_str(property);
%     x_axis_title      = '24h time';
    x_axis_title_per  = 'Time lag (hours)';
    
    load([dir '/' mainfile '.mat'],'srate','starttime','seizstart','seizend',...
         'sleepstart','sleepend','sleep_annot');
    if ~exist('sleep_annot','var') sleep_annot = []; end;
    load([dir '/' mainfile '/' experiment '/nets.mat'],'nets_w5');
    figdir = [dir '/' mainfile '/' experiment '/window=5/threshold=' num2str(thresholds(1))];
    
    [~, ~, timemoments, networks] = size(nets_w5);
%     x_axis_start_hour = (double(starttime(1))+double(starttime(2))/60+double(starttime(3))/3600);
%     x_axis_values     = x_axis_start_hour + [5/3600:5/3600:timemoments*5/3600];     % Set the time scale to hours
    x_axis_values_per = [-(timemoments-1)*5/3600:5/3600:(timemoments-1)*5/3600];

    for j=1:networks
        if (networks==1)
            net_filename = '';
            net_title = '';
        else
            net_filename = ['_' strrep(network_to_freq_str(j),' band','')];
            net_title = network_to_freq_str(j);
        end
        
        
        for tr = 1:size(thresholds,2)
            nets_bin = binarize(nets_w5,thresholds(tr));
            for t=1:timemoments
               %for j=1:networks
                   C(t,tr) = feval(property,nets_bin(:,:,t,j));
               %end
            end

            C2(:,tr) = C(:,tr) - mean(C(:,tr),1);
            C3(:,tr) = remove_mean(C(:,tr),0.98);
            C3(:,tr) = C3(:,tr)'+min(C3(:,tr));
    %        C3a = C3 - mean(C3,2);

    %         plot(x_axis_values,C,'g'); hold on;
    %        plot(C2,'r'); hold on;     % Unsmoothed data
    %         plot(C3,'y'); hold on;
%            plot(g,x_axis_values, C3,'b'); hold on;             % Smoothed data



            % Label x axis with time of day        
    %         window = 5;
    %         %tick_start = (18 + 34*60)/window; tick_start_label = 10;% 10.25.42 (M.C.)
    %         tick_start = (55 + 28*60)/window; tick_start_label = 9; % 9.31.05 (I.I.)
    %         tick_distance = 4*3600/window; % 4 hours
    %         xtickat = tick_start:tick_distance:timemoments-1;
    %         set(gca, 'XTick', xtickat, 'XTickLabel', cellstr( num2str( mod( tick_start_label + round(xtickat .' ./ (3600/window)),24) ) ) )

            autocorrelation = xcorr(C2(:,tr), 'unbiased');
            display('Done autocorrelating...');
            normalized_autocorrelation(:,tr) = autocorrelation./autocorrelation(timemoments);
            display('Done normalizing...');
    %        plot(x_axis_values_per,normalized_autocorrelation); %hold on
    %        plot(xcorr(C2(1,:), 'biased'), 'r'); hold on;
    %        plot(xcorr(C3a(1,:), 'biased'), 'g');

            %title([patient{1} ' - ' fname_to_str(property) ' ' int2str(j)]) %network_to_freq_str(j)])

        end     % for thresholds
        
        figtitle = [patient_title ' - ' property_title ' ' net_title];
        g = plot_with_events(C3,srate,sleep_annot,starttime,figtitle,seizstart,seizend,sleepstart,sleepend);
        if ~exist(figdir,'dir') mkdir(figdir); end;
        saveas(g, [figdir '/' property net_filename '.jpg']);
        saveas(g, [figdir '/' property net_filename '.fig']);
        close;
       
        % Figure plotting the periodicity
        h = figure;
        leave_out_values = 150;
        %plot(x_axis_values_per(leave_out_values+1:2*timemoments-leave_out_values-1),normalized_autocorrelation(leave_out_values+1:2*timemoments-leave_out_values-1,:));
        plot(x_axis_values_per(timemoments+1:2*timemoments-leave_out_values-1),normalized_autocorrelation(timemoments+1:2*timemoments-leave_out_values-1,:));
        title([patient_title ' - ' property_title ' ' net_title ' autocorrelation']);
        xlabel(x_axis_title_per);
        set(findall(gcf,'type','text'),'fontSize',24) 
        set(findall(gcf,'type','axes'),'fontsize',14)

        saveas(h, [figdir '/periodicity_' property net_filename '.jpg']);
        saveas(h, [figdir '/periodicity_' property net_filename '.fig']);

        close;
        
    end    % for networks
end
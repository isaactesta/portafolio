function testing_measures(dir,seizid,montage,correlation,filtering,threshold)
% Tests various measures, thresholds, window-sizes etc.
    
    % Print current run
    inputs = {dir; seizid};
    disp(inputs);

    global NET CORR FILT OUTDIR WINDOWS INPUTTYPE GAMMA_MAX ...
        MULTIPLE_NETWORKS_PER_FIG PLOT_AVERAGE
    
    
    % ===================================================================
    % ******************** USER INPUT ***********************************
    
    % Calculate everything from scratch? (rather than load and replot?)
    REDO_FROM_SCRATCH = 0;
    
    % Size of window to consider (5 for cross-corr, 10 for kramer)
    WINDOWS = [5];    
    
    % Maximum freq of the gamma band and the broadband
    GAMMA_MAX = 45;
    
    % 0 or 1 (used in plot_nodes_property)
    MULTIPLE_NETWORKS_PER_FIG = 0;
    
    % Plot data by averaging intervals
    PLOT_AVERAGE = 0;
    
    % The type of the input data (use 'new' for those in mat file)
    INPUTTYPE = 'old';
    
    % Instead of setting a set threshold we define a percentage of
    % connections to be drawn. 0 indicates the use of surrogates (below)
    CONNECTIVITY = 0.0;

    % Use surrogate data to set the threshold.
    % 0 indicates the use of a fixed threshold (below)
    SURROGATES = 0;
    
    % ==== User input
    % The thresholds for which the experiments will run
    % If connectivity or surrogates are used, these will be ignored
    if nargin<6
        T_LOW  = 0.55;
        T_HIGH = 0.65;
    else
        T_LOW  = threshold;
        T_HIGH = threshold;
    end
    % ****************** END OF USER INPUT ******************************
    % ===================================================================

    % Type of nodes in the network: 'single', 'ref', 'avgref' or 'bipolar'
    NET = montage;
    
    % Type of filtering: 'detrend', 'f1-48', 'f1-50', 'f1-50_regression', 
    %       'f1-60', 'f1-60_notch', 'alpha' (8-13Hz), 'beta' (13-30Hz),
    %       'gamma' (30-48/60Hz), 'delta' (1-4Hz), 'theta' (4-8Hz), 
    %       'ICA', 'CRLS'
    % Is not used when clean data are passed (args. 3 & 4)
    FILT = filtering;
    
    % Type of correlation: 'cross-corr', 'kramer', 
    %   'coherence', 'coherence_freq_bands',
    %   'mean_coherence' 'mean_coherence_freq_bands',
    %   'imaginary_coherence', 'imaginary_coherence_freq_bands'
    %   'mean_imaginary_coherence' 'mean_imaginary_coherence_freq_bands'
    %   'reduced_coherence_freq_bands', 'cross-corr_no_zero_lag', 
    %   'pli', 'pli_cpsd', 'wpli', 'cross-corr_no_symmetric'
    CORR = correlation;
    
    % The output directory
    if GAMMA_MAX~=45
        OUTDIR = [dir '/seizure_' seizid '/' NET '__' FILT '__' CORR '__fmax_' num2str(GAMMA_MAX)];
    else
        OUTDIR = [dir '/seizure_' seizid '/' NET '__' FILT '__' CORR];
    end
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Don't touch below this point
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Set the sampling rate according to the type of data
    if strcmp(INPUTTYPE,'new')
        srate = 500;
    else
        srate = 200;
    end
    
    % Load (or create) cross correlations
    if REDO_FROM_SCRATCH || ~exist_nets_weighted()
        create_nets_weighted(dir,seizid,srate);
    end
    load([OUTDIR '/data.mat'],'data','evend','evstart','filtered_data','indices','nets_w*','node_data','indx');

    % Binarize and plot
    for window_size = WINDOWS
        varname = ['nets_w' num2str(window_size)];
        network_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};
        
        if CONNECTIVITY>0 
            % Maintain constant average degree according to requested
            % connectivity
            eval(['nets = binarize_fixed_connectivity(' varname ', CONNECTIVITY);']);
            figdir = [OUTDIR '/window=' num2str(window_size) '/connectivity=' num2str(CONNECTIVITY)];
            plot_all(nets,window_size,evstart,evend,figdir,network_labels);
        
        elseif SURROGATES>0
            % Initialize with weighted data
            eval(['nets = ' varname ';']);
            
            % Construct surrogates and set to zero all connections
            % with weaker connections than the surrogates
            for i=1:SURROGATES
                % Check if we have the surrogates already
                surrogate_filename = [OUTDIR '/surrogates_w' num2str(window_size) '.mat'];
                 if exist(surrogate_filename,'file')
                    vars = whos('-file',surrogate_filename);
                    
                    %if ~exist(['surrogate_nets' num2str(i)],'var')
                    if ismember(['surrogate_nets' num2str(i)], {vars.name})
                        disp(['LOADING surrogate nets ' num2str(i) '...']);
                        eval('load(surrogate_filename,[''surrogate_nets'' num2str(i)]);');
                        eval(['surrogate_nets = surrogate_nets' num2str(i) ';']);
                    end
                end
                
                if ~exist('surrogate_nets','var')
                    disp(['CREATING surrogate nets ' num2str(i) '...']);
                    surrogate_data = generate_surrogate_data(filtered_data,window_size,srate);
                    surrogate_nets = correlate_all(surrogate_data,window_size,srate);

                    % Save surrogate nets for future use
                    eval(['surrogate_nets' num2str(i) '=surrogate_nets;']);
                    if i==1
                        eval('save(surrogate_filename,[''surrogate_nets'' num2str(i)]);');
                    else
                        eval('save(surrogate_filename,[''surrogate_nets'' num2str(i)],''-append'');');
                    end
                end
                
                size(nets)
                size(surrogate_nets)
                nets(nets<=surrogate_nets) = 0;
                clear surrogate_nets;
                eval(['clear surrogate_nets' num2str(i) ';']);
            end
            
            % The remaining connections are significant
            nets(nets>0) = 1;
            
            % Plot and save
            figdir = [OUTDIR '/window=' num2str(window_size) '/surrogates=' num2str(SURROGATES)];
            plot_all(nets,window_size,evstart,evend,figdir,network_labels);
            
        else
            % Binarize the weighted network with the given fixed thresholds
            for threshold = T_LOW:0.1:T_HIGH
                eval(['nets = binarize(' varname ',threshold);']);
                figdir = [OUTDIR '/window=' num2str(window_size) '/threshold=' num2str(threshold)];
                plot_all(nets,window_size,evstart,evend,figdir,network_labels);
            end
        end
    end
    
    clear;
end

function [doesexist]=exist_nets_weighted()
    disp('Checking existence of correlations and events...');
    
    doesexist = false;
    global OUTDIR WINDOWS
    
    datafile = [OUTDIR '/data.mat'];
    
    if exist(datafile,'file')
        load(datafile,'nets_w*','evstart','evend')
    else 
        disp(['    Datafile does not exist!']);
        return;
    end
    
    for w = WINDOWS
        if ~exist(['nets_w' int2str(w)],'var')
        	disp(['nets_w' int2str(w) ' does not exist!']);
            return;
        end
    end
    
    if ~exist('evstart','var') || ~exist('evend','var')
        disp('    Events do not exist!');
        return;
    end

    disp('    Yes, all data do exist!');
    doesexist = true;
end

function create_nets_weighted(dir,seizid,srate)
    fprintf('Creating correlation networks...\n');
    
    global NET FILT OUTDIR WINDOWS INPUTTYPE GAMMA_MAX
    
    % Import the data
    source = [dir '/seizure_' seizid '.txt'];
    
    if strcmp(INPUTTYPE,'new')
        load([dir '/seizure_' seizid '.mat']);
    elseif strfind(FILT,'ICA')
        disp('   Loading ICA data...');
        
        % Import clean data (no filtering will be performed)
        clear EEG;
        load([dir '/clean_data/seizure_' seizid '_ICA.mat']);
        
        % Transform data to correct form
        [moments,channels] = size(remove_eyes_ICA);
        
        % Transpose EEGLab's data and add zero col. 3
        data = zeros(moments,channels+1);
        data(:,1:2) = remove_eyes_ICA(:,1:2);
        data(:,4:channels+1) = remove_eyes_ICA(:,3:channels);
        
        % Apply Notch filter
        if ~isempty(strfind(FILT,'alpha')) && ...
            ~isempty(strfind(FILT,'beta')) && ...
            ~isempty(strfind(FILT,'gamma')) && ...
            ~isempty(strfind(FILT,'delta')) && ...
            ~isempty(strfind(FILT,'theta'))
            
            disp('   Filtering broadband...');
            srate = 200;
            data = notch_filter(data,srate);
            data = myfilter(data,1,GAMMA_MAX,srate);
        end
        % Import indices for the data
        [~,indices] = importEEG(source,0);
    elseif strfind(FILT,'CRLS')
        disp('   Loading CRLS data...');
        
        % Import clean data (no filtering will be performed)
        clear EEG;
        load([dir '/clean_data/seizure_' seizid '_CRLS.mat']);
        
        % Transform data to correct form
        [channels,moments] = size(EEG.data);
        % Transpose EEGLab's data and add zero col. 3
        data = zeros(moments,channels+1);
        data(:,1:2) = EEG.data(1:2,:)';
        data(:,4:channels+1) = EEG.data(3:channels,:)';

        % Import indices for the data
        [~,indices] = importEEG(source,0);      
    else
        disp('   Loading raw data...');
        
        % Import raw data (will be filtered later on)
        [data,indices] = importEEG(source,0);
    end
    
%    if (nargin<3)
%        [data,indices] = importEEG(source,0);
%    else
%        [~,indices] = importEEG(source,0);
%        % Load clean data (EEG data structure)
%        clear EEG;
%        load([dir '/clean_data/' clean_data_file]);
%        if strcmp(clean_method,'ICA')
%             [moments,channels] = size(remove_eyes_ICA);
%             % Transpose EEGLab's data and add zero col. 3
%             data = zeros(moments,channels+1);
%             data(:,1:2) = remove_eyes_ICA(:,1:2);
%             data(:,4:channels+1) = remove_eyes_ICA(:,3:channels);            
%         else
%             [channels,moments] = size(EEG.data);
%             % Transpose EEGLab's data and add zero col. 3
%             data = zeros(moments,channels+1);
%             data(:,1:2) = EEG.data(1:2,:)';
%             data(:,4:channels+1) = EEG.data(3:channels,:)';
%         end
%     end

    % Import annotations
    nlines  = size(data,1);
    if ~strcmp(INPUTTYPE,'new')
        evstart = get_events(dir,indices,'start',srate);
        evend   = get_events(dir,indices,'end',srate);
    end

    
    % Adjust the data montage
    if strcmp(INPUTTYPE,'new')
        % In this case the data is already in bipolar format
        % Simply ignore the last channels (ears, etc)
        node_data = data(:,1:18);   
        
    elseif strcmp(NET,'single')
        node_data = data(:,4:22);   % Electrode data

    elseif strcmp(NET,'ref')
        % Append eye channels
        if strfind(FILT,'f1-50_regression')
            node_data = zeros(nlines,20);
            node_data(:,19:20) = data(:,23:24);     % add the eyes
        else
            node_data = zeros(nlines,18);
        end
        
        % node_data includes only the eeg channels (excluding the Cz and
        % the ears)
        % Subtract Cz
        node_data(:,1:9) = data(:,4:12) - repmat(data(:,13),1,9);
        node_data(:,10:18) = data(:,14:22) - repmat(data(:,13),1,9);       
        
    elseif strcmp(NET,'avgref')
        % Append eye channels
        if strfind(FILT,'f1-50_regression')
            node_data = zeros(nlines,20);
            node_data(:,19:20) = data(:,23:24);      % add the eyes
        else
            node_data = zeros(nlines,18);
        end
        
        % Find the mean of the eeg channels at each time point
        avg_data = mean(data,2);
        
        % Subtract Cz
        node_data = zeros(nlines,19);
        for i=1:19
            node_data(:,i) = data(:,3+i) - avg_data;
        end

    elseif strcmp(NET,'bipolar')
        node_data = zeros(nlines,18);
        node_data(:,1) = data(:,4) - data(:,5);
        node_data(:,2) = data(:,5) - data(:,6);
        node_data(:,3) = data(:,6) - data(:,7);
        node_data(:,4) = data(:,7) - data(:,8);
        node_data(:,5) = data(:,18) - data(:,19);
        node_data(:,6) = data(:,19) - data(:,20);
        node_data(:,7) = data(:,20) - data(:,21);
        node_data(:,8) = data(:,21) - data(:,22);
        node_data(:,9) = data(:,4) - data(:,9);
        node_data(:,10) = data(:,9) - data(:,10);
        node_data(:,11) = data(:,10) - data(:,11);
        node_data(:,12) = data(:,11) - data(:,8);
        node_data(:,13) = data(:,18) - data(:,15);
        node_data(:,14) = data(:,15) - data(:,16);
        node_data(:,15) = data(:,16) - data(:,17);
        node_data(:,16) = data(:,17) - data(:,22);
        node_data(:,17) = data(:,12) - data(:,13);
        node_data(:,18) = data(:,13) - data(:,14);
% Temporarily remove last four channels that contain AC27 and AC28
%        node_data(:,19) = data(:,4) - data(:,27);
%        node_data(:,20) = data(:,27) - data(:,7);
%        node_data(:,21) = data(:,18) - data(:,28);
%        node_data(:,22) = data(:,28) - data(:,21);
    end
    
    % Filter the data
    if strfind(FILT,'detrend')
        filtered_data = detrend(node_data);
    elseif strfind(FILT,'f1-48')
        filtered_data = myfilter(node_data,1,48,srate);
    elseif strfind(FILT,'f1-50')
        filtered_data = myfilter(node_data,1,50,srate);
    elseif strfind(FILT,'f1-60')
        filtered_data = myfilter(node_data,1,60,srate);
    elseif strfind(FILT,'f1-60_notch')
        filtered_data = myfilter(node_data,1,60,srate);
        %wo = 50/(srate/2); bw = wo/35;
        %[b,a] = iirnotch(wo,bw);
        filtered_data = notch_filter(srate,50,filtered_data);
    elseif strfind(FILT,'alpha')
        disp('   Filtering data in the alpha band...');
        filtered_data = myfilter(node_data,8,13,srate);
    elseif strfind(FILT,'beta')
        disp('   Filtering data in the beta band...');
        filtered_data = myfilter(node_data,13,30,srate);
    elseif strfind(FILT,'gamma')
        disp('   Filtering data in the gamma band...');
        filtered_data = myfilter(node_data,30,GAMMA_MAX,srate);
    elseif strfind(FILT,'delta')
        disp('   Filtering data in the delta band...');
        filtered_data = myfilter(node_data,1,4,srate);
    elseif strfind(FILT,'theta')
        disp('   Filtering data in the theta band...');
        filtered_data = myfilter(node_data,4,8,srate);
    elseif strfind(FILT,'f1-50_regression')
        % Remove artifacts with regression
        filtered_data = remove_artifacts(node_data); 
    elseif strfind(FILT,'ICA') || strfind(FILT,'CRLS')
        filtered_data = node_data;
    else
        error(['Unknown filtering function: ' FILT]);
    end
        

    % Cross-correlate
    for window_size = WINDOWS
        eval(['[' genvarname(['nets_w' int2str(window_size)])...
            ',indx]=correlate_all(filtered_data,window_size,srate);'])
    end

    % Save the networks
    if ~exist(OUTDIR,'dir')
        mkdir(OUTDIR);
    end  
    if ~strcmp(INPUTTYPE,'new')
        save([OUTDIR '/data.mat'],'data','evend','evstart','filtered_data','indices','nets_w*','node_data','indx');
    else
        save([OUTDIR '/data.mat'],'data','evend','evstart','filtered_data','nets_w*','node_data','indx');
    end

    fprintf('... Done creating correlation networks!\n');
end

function [event_times] = get_events(dir,indices,event,srate)
    fprintf(['    Extracting locations of events ' event '... ']);
    
    % Find times that are annotated as 'start'
    annot = import_annotations([dir '/annotations.txt']);    
    %times = annot(find(strcmp([annot(:, 2)], event)));
    times = annot(strcmp(annot(:, 2), event));
    
    % Compute the corresponding seconds within our data file
    [~,~,evidx] = intersect(times,indices);
    event_times = evidx/srate;

    fprintf('Done!\n');
end

function [filtered_data]=myfilter(data,low,high,srate)
    disp('    Filtering... ');

    filtered_data = detrend(data);
    
    filtered_data = filtered_data';
    [filtered_data]=eegfilt(filtered_data,srate,low,0);
    [filtered_data]=eegfilt(filtered_data,srate,0,high);
    filtered_data = filtered_data';
    
    %fprintf('Done!\n');
end

function [nets,indx]=correlate_all(data,window,srate)
    fprintf(['    Correlating (window = ' num2str(window) ')... ']);

    global CORR NET GAMMA_MAX
    
    symmetric    = 0;        % Symmetric correlation measure
    indx = 0;
    
    [length chan] = size(data);
    frame = window*srate;
    timemoments = 0;
    symmetric = 1;
    
    if strcmp(CORR,'kramer')
        corr      = @kramer_edge_weighted;
    elseif strcmp(CORR,'cross-corr')
        %corr      = @(x,y)  max(abs(xcov(x,y,srate/4,'coeff')));
        corr      = @(x,y) cross_corr(x,y,srate);
    elseif strcmp(CORR,'cross-corr_no_zero_lag')
        corr      = @(x,y) cross_corr_no_zero_lag(x,y,srate);
    elseif strcmp(CORR,'cross-corr_no_symmetric')
        corr      = @(x,y) cross_corr_no_symmetric(x,y,srate);
    elseif strcmp(CORR,'coherence')
        corr      = @(x,y) coherence(x,y,1,GAMMA_MAX,srate);
    elseif strcmp(CORR,'mean_coherence')
        corr      = @(x,y) mean_coherence(x,y,1,GAMMA_MAX,srate);
    elseif strcmp(CORR,'imaginary_coherence')
        corr      = @(x,y) imaginary_coherence1(x,y,srate);
    elseif strcmp(CORR,'mean_imaginary_coherence')
        corr      = @(x,y) mean_imaginary_coherence(x,y,1,GAMMA_MAX,srate);
    elseif strcmp(CORR,'mutualinfo')
        corr      = @mutualinf;
    elseif strcmp(CORR,'coherence_freq_bands')
        corr      = @(x,y) coherence_freq_bands(x,y,srate);
    elseif strcmp(CORR,'mean_coherence_freq_bands')
        corr      = @(x,y) mean_coherence_freq_bands(x,y,srate);
    elseif strcmp(CORR,'imaginary_coherence_freq_bands')
        corr      = @(x,y) imaginary_coherence_freq_bands(x,y,srate);
    elseif strcmp(CORR,'reduced_coherence_freq_bands')
        % Not really used; we make a special case below as we need 
        %   to calculate the distances 
        corr      = @reduced_coherence_freq_bands;
    elseif exist([CORR '.m'],'file')
        corr      = str2func(CORR);
    else
        error(['        Unknown correlation function: ' CORR]);
    end

	if strcmp(CORR,'coherence_freq_bands') || ...
        strcmp(CORR,'mean_coherence_freq_bands') || ...
        strcmp(CORR,'imaginary_coherence_freq_bands')
		% Special case: we will plot all frequency bands in the same plot
		% Compute the coherence, then plot one line for each frequency band
    	nets = zeros(chan,chan,ceil(length/frame),6);	% Fourth dimension stores the 
    													% values at different frequencies
    	
    	for time = 1:frame:length
        	timestop    = min(time+frame-1,length);
        	timemoments = timemoments + 1;
        	for i = 1:chan
        	    for j = 1:chan
        	        if (i<j) || (i>j && ~symmetric)
        	            nets(i,j,timemoments,:) = corr(data(time:timestop,i),...
        	                data(time:timestop,j));
        	        elseif (i>j && symmetric)
        	            nets(i,j,timemoments,:) = nets(j,i,timemoments,:);
        	        end
        	    end
        	end
        end
    elseif strcmp(CORR,'reduced_coherence_freq_bands')
        if ~strcmp(NET,'ref')
            error('        Reduced coherence can only be computed with common reference montage. Aborting...');
        end
        
    	nets = zeros(chan,chan,ceil(length/frame),6);	% Fourth dimension stores the 
    													% values at different frequencies
        % Load electod distances and get rid of the common reference Cz
        distance=importdata('electrode-distances.txt');
        distance=distance(~ismember(1:size(distance,1),13),:);
        distance=distance(:,~ismember(1:size(distance,2),13));
    	
    	for time = 1:frame:length
        	timestop    = min(time+frame-1,length);
        	timemoments = timemoments + 1;
        	for i = 1:chan
        	    for j = 1:chan
        	        if (i<j) || (i>j && ~symmetric)
        	            nets(i,j,timemoments,:) = ...
                            reduced_coherence_freq_bands(data(time:timestop,i),...
        	                data(time:timestop,j),distance(i,j),srate);
        	        elseif (i>j && symmetric)
        	            nets(i,j,timemoments,:) = nets(j,i,timemoments,:);
        	        end
        	    end
        	end
        end     
    elseif strcmp(CORR,'cross-corr') || strcmp(CORR,'cross-corr_no_zero_lag')
    	nets = zeros(chan,chan,ceil(length/frame));
        indx = zeros(chan,chan,ceil(length/frame));
    	
    	for time = 1:frame:length
        	timestop    = min(time+frame-1,length);
        	timemoments = timemoments + 1;
        	for i = 1:chan
        	    for j = 1:chan
        	        if (i<j) || (i>j && ~symmetric)
        	            [nets(i,j,timemoments),indx(i,j,timemoments)] = ...
                            corr(data(time:timestop,i), ...
                                 data(time:timestop,j));
        	        elseif (i>j && symmetric)
        	            nets(i,j,timemoments) = nets(j,i,timemoments);
                        indx(i,j,timemoments) = indx(j,i,timemoments);
        	        end
        	    end
        	end
    	end
    else 
    	nets = zeros(chan,chan,ceil(length/frame));
    	
    	for time = 1:frame:length
        	timestop    = min(time+frame-1,length);
        	timemoments = timemoments + 1;
        	for i = 1:chan
        	    for j = 1:chan
        	        if (i<j) || (i>j && ~symmetric)
        	            nets(i,j,timemoments) = corr(data(time:timestop,i),...
        	                data(time:timestop,j));
        	        elseif (i>j && symmetric)
        	            nets(i,j,timemoments) = nets(j,i,timemoments);
        	        end
        	    end
        	end
        end
    end
    fprintf('    Done!\n'); 
end

% function [nets]=binarize(nets,threshold)
%     fprintf(['    Binarizing network (threshold = ' num2str(threshold) ')... ']);
%     
%     nets(nets>threshold|nets<-threshold)=1;
%     nets(nets<1)=0;
%     
%     fprintf('    Done!\n');
% end

function [surrogate] = generate_surrogate_data(data,window,srate)
    
    [length chan] = size(data);
    frame         = window*srate;   % Length of each epoch
    timemoments   = 0;

    surrogate = zeros(length,chan);

    for time = 1:frame:length
        timestop    = min(time+frame-1,length);
        timemoments = timemoments + 1;
        surrogate(time:timestop,:) = FTsurrogates_matrix(data(time:timestop,:));
    end
end

% function save_plots(dir,subdir1,subdir2)
%     fprintf('    Saving... ');
%     
%     subdir = [dir '/' subdir1 '/' subdir2];
%     if ~exist(subdir,'dir')
%         mkdir(subdir);
%     end
%     
%     movefile('*.jpg',subdir);
%     movefile('*.fig',subdir);
% 
%     fprintf('    Done!\n');
% end

function [cor,indx] = cross_corr(x,y,srate)
    lag        = floor(srate/4);
    [cor,indx] = max(abs(xcov(x,y,lag,'coeff')));
    indx       = indx-lag-1;
end

function [cor,indx] = cross_corr_no_zero_lag(x,y,srate)
    lag    = floor(srate/4);
    covmat = abs(xcov(x,y,lag,'coeff'));
% 1st way
%     [cor1,indx1] = max(covmat(1:lag));
%     [cor2,indx2] = max(covmat(lag+2:2*lag+1));
%     [cor,i]      = max(cor1,cor2);
%     if i==1
%         indx = indx1-lag-1;
%     else
%         indx = indx2-lag-1;
%     end
    
% 2nd way    
    covmat(lag+1) = -1;
    [cor,indx]    = max(covmat);
    indx          = indx-lag-1;

% 3rd way
%     covmat = [covmat(1:lag); covmat(lag+2:end)];
%     [cor,indx] = max(covmat);
%     indx = indx-lag-1;
end

function [cor,indx] = cross_corr_no_symmetric(x,y,srate)
    maxlag = floor(srate/4);
    covmat = abs(xcov(x,y,maxlag,'coeff'));
    
    corrmat = covmat(maxlag+2:2*maxlag+1) -...
              flipdim(covmat(1:maxlag),1);
    [cor,indx] = max(corrmat);
end

function coh = coherence(x,y,low,high,srate)
    [C,f]  = mscohere(x,y,[],[],[],srate);
    low_i  = find(f>low,1,'first'); 
    high_i = find(f<high,1,'last'); 
    coh    = max(C(low_i:high_i));
end

function coh = mean_coherence(x,y,low,high,srate)
    [C,f]  = mscohere(x,y,[],[],[],srate);
    low_i  = find(f>low,1,'first');
    high_i = find(f<high,1,'last');
    coh    = mean(C(low_i:high_i));
end

function coh = mean_imaginary_coherence(x,y,low,high,srate)
    [C,f]  = imaginary_coherence(x,y,srate);
    low_i  = find(f>low,1,'first');
    high_i = find(f<high,1,'last');
    coh    = mean(C(low_i:high_i));
end

function coh = coherence_freq_bands(x,y,srate)
    global GAMMA_MAX
    [C,f]  = mscohere(x,y,[],[],[],srate);
    
    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = max(C(fband_indx_start:fband_indx_stop));
    end
end

function coh = mean_coherence_freq_bands(x,y,srate)
    global GAMMA_MAX
    [C,f]  = mscohere(x,y,[],[],[],srate);
    
    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = mean(C(fband_indx_start:fband_indx_stop));
    end
end

function coh = imaginary_coherence1(x,y,srate)
    global GAMMA_MAX
    [C,f]  = imaginary_coherence(x,y,srate);
    
    low_i  = find(f>1,1,'first'); 
    high_i = find(f<GAMMA_MAX,1,'last');
    
    coh = max(abs(C(low_i:high_i)));
end

function coh = imaginary_coherence_freq_bands(x,y,srate)
    global GAMMA_MAX
    [C,f]  = imaginary_coherence(x,y,srate);
    
    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = max(abs(C(fband_indx_start:fband_indx_stop)));
    end
end

function coh = reduced_coherence_freq_bands(x,y,distance,srate)
%
% Reduced coherence = Coherence - Random coherence (Nunez et al. 1997)
%   distance is the distance (on the scalp) between the two electrodes (cm)
%
    global GAMMA_MAX
    [C,f]  = mscohere(x,y,[],[],[],srate);
    
    % Reduced coherence = Coherence - Random coherence (Nunez et al. 1997)
    a = 3;      % A constant with approximate range 3-5
    C = C - exp((1-distance)/a);    

    % Frequency bands: all (1-GAMMA_MAX), alpha (8-13Hz), beta (13-30Hz)
    % gamma (30-GAMMA_MAX), delta (1-4Hz), theta (4-8Hz)
    fband_freq_start = [    1      8 13     30    1 4];
    fband_freq_stop  = [GAMMA_MAX 13 30 GAMMA_MAX 4 8];
    nfbands = size(fband_freq_start,2);

    coh = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop  = find(f<fband_freq_stop(i),1,'last');
        coh(i) = max(C(fband_indx_start:fband_indx_stop));
    end
end

%WINDOW_CROSS_CORRELATION DEPRECATED Applies correlation coefficient to windows of A 
%
% INPUT
%   A           : Columns in A are the variables to be correlated.
%                 Rows in A are the values of each variable.
%                 NOTE: Only reads the first 22 columns!
%   threshold   : I used to separate good connections from bad ones.
%                 It must be a positive float < 1.
%   window_size : (Optional) Default is 20 sec
%   shift       : (Optional) Default is 10 sec
%
% OUTPUT
%       nets    : A 3D matrix of the correlation coefficient windows.
%                 (i,j,k) where i,j are channels and k is time window
%
% Manolis Christodoulakis @ 2011

function nets = window_cross_correlation(A,threshold,window_size,shift)

    % Set default values
    if (nargin<4)
        shift = 2000;           %  10 sec @ 200Hz 
    end
    if (nargin<3)
        window_size = 2000;     %  10 sec @ 200Hz 
    end
    if (nargin<2)
        threshold = 0.75;
    end

    % Check for erroneous input
    if (threshold <= 0 || threshold >=1)
        error('Invalid input! Threshold must be between 0 and 1 exclusive!');
    end

    if (window_size <= 0)
        error('Invalid input! Window_size must be greater than 0!');
    end

    if (window_size < shift)
        error('Invalid input! Window_size must be larger than shift!');
    end

    [rowsA colsA] = size(A);
    num_windows = ceil(rowsA/shift); % ??? Check this
    num_channels = 22;
    nets=zeros(num_channels,num_channels,num_windows);

    for time=1:num_windows
        start = (time-1) * window_size + 1;
        finish = min(start + window_size - 1,rowsA);
        for chanA=1:num_channels
            for chanB=chanA+1:num_channels %1:num_channels
                nets(chanA,chanB,time)=kramer_edge_weighted(A(start:finish,chanA),A(start:finish,chanB));
            end
        end
        % Undirectional, therefore symmetric
        nets(:,:,time) = nets(:,:,time) + nets(:,:,time)';
    end

    % nets2=zeros(colsA-1,colsA-1,num_windows);
    % for time=1:num_windows
    %     start = (time-1) * window_size + 1;
    %     finish = start + window_size - 1;
    %     [cA cB] = meshgrid(1:num_channels);
    %     nets2(:,:,time) = arrayfun( @(a,b) kramer_edge(A(start:finish,a+1),A(start:finish,b+1)),cA,cB,'UniformOutput', true);
    % end
    % 
    % if (nets~=nets2)
    %     error('nets ~= nets2');
    % end

end


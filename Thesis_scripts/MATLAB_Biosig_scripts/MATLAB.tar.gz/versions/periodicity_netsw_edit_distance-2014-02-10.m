function periodicity_netsw_edit_distance(filename,threshold)
% Calculates periodicity over time, based on the topology of the graphs
%
% Loads the weighted adjacency matrices (nets_w5), calculates average
% networks (e.g. over one minute) and calculates the correlation of the
% cumulative graph edit distance, over a number of networks (e.g. 500)
%
% Manolis Christodoulakis @2014

    % --------------------------------------------------------------------
    % --- Customization
    patient_title       = patient_to_str(filename);
    avg_time        	= 60;               % Average over this many sec
    mean_step           = avg_time / 5;     % 5 sec windows
    num_windows_to_corr = 180;     % # windows to calculate correlation on  

    
    % --------------------------------------------------------------------
    % --- Load the data and calculate average nets
    load(filename,'nets_w5','evstart','evend');
    [nrows ncols nnets nfreq] = size(nets_w5);

    avg_bin_nets    = zeros(nrows,ncols,ceil(nnets/mean_step));
    navgnets        = floor(nnets/mean_step);
    for f=1:nfreq
        for i=1:navgnets
            avg_bin_nets(:,:,i,f) = mean(nets_w5(:,:,(i-1)*mean_step+1:min(i*mean_step,nnets),f),3);
            avg_bin_nets(:,:,i,f) = binarize(avg_bin_nets(:,:,i,f),threshold);
        end
    end

    % --------------------------------------------------------------------
    % --- Calculate periodicities, plot, and save, for every freq. band
    for f=1:nfreq
        if (nfreq==1)
            net_filename = '';
            net_title = '';
        else
            net_filename = ['_' strrep(network_to_freq_str(f),' band','')];
            net_title = ['(' network_to_freq_str(f) ')'];
        end

        % ----------------------------------------------------------------
        % --- Calculate periodicity with cross correlations
        % --- over limited number of windows
        distances = zeros(navgnets-num_windows_to_corr,1);
        for shift=1:navgnets-num_windows_to_corr
            sum_distance = 0;
            for k=1:num_windows_to_corr
                sum_distance = sum_distance + graph_edit_distance(avg_bin_nets(:,:,k,f),avg_bin_nets(:,:,shift+k,f));
            end
            distances(shift) = sum_distance;
        end

        % ----------------------------------------------------------------
        % --- Plot
        % Set the time scale to hours
        h = figure;
        x_axis_values = [avg_time/3600:avg_time/3600:...
                         (navgnets-num_windows_to_corr)*avg_time/3600];
        x_axis_title = 'Time (hours)';
        plot(x_axis_values,distances); hold on;
        xlabel(x_axis_title);
        title([patient_title ' - Graph Edit Distance periodicity ' net_title]);

        % Indicate specific events if there are any
        for e=evstart
            arrayfun(@(e) add_vline(e,'--'),e/3600);
        end

        % ----------------------------------------------------------------
        % --- Save
        figdir = strrep(filename,'data.mat',...
                        ['window=5/threshold=' num2str(threshold)]);
        if ~exist(figdir,'dir') mkdir(figdir); end;
        saveas(h, [figdir '/periodicity_edit_dist' net_filename '.jpg']);
        saveas(h, [figdir '/periodicity_edit_dist' net_filename '.fig']);
        close;
    end
end
%% Run several tests together
% Column vectors, use semicolon
montages     = {'bipolar'};
filterings   = {'f1-60_notch'}; % 'f1-50'; 'f1-60'; 'ICA'
correlations = {'coherence_freq_bands'; 'imaginary_coherence_freq_bands'; 'mean_coherence_freq_bands'}; % 'coherence_freq_bands'; 'imaginary_coherence_freq_bands'; 'mean_coherence_freq_bands'; 'cross-corr'; 'cross-corr_no_zero_lag';
seizures     = {'/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240' '19_56_36_820_[-15min_+15min]'; % I.I.
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '4_18_11_250_[-15min_+15min]';  % M.C. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '16_48_31_920_[-15min_+15min]'; % M.C. 2nd seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_11_43_870_[-15min_+15min]'; % T.K. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_33_52_810_[-15min_+15min]'; % T.K. 2nd seizure
                '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' '91_26_49_705_[-15min_+15min]';           % H.E.
                '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' '36_43_57_265_[-15min_+15min]';       % M.G.
                '/home/manolisc/epilepsy/Exports/Export-Txxxxx~ Yxxxxx_d405987a-c066-4363-a607-bd1ec8c5f7cf' '15_50_06_900_[-15min_+15min]'        % T.Y. 
};

new_seizures = {'/home/manolisc/epilepsy/Exports/Export-10753' '5848.2812_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '7582.25_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '36929.2395_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '40464.3958_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '41666.2395_[-15min_+15min]';
                '/home/manolisc/epilepsy/Exports/Export-10753' '42626.6041_[-15min_+15min]'
};

% OLD PATIENTS
[s m c f] = ndgrid(1:size(seizures,1), 1:numel(montages), 1:numel(correlations), 1:numel(filterings));
run       = [ seizures(s(:),1) seizures(s(:),2) montages(m(:)) correlations(c(:)) filterings(f(:)) ];

% NEW PATIENTS
%[s m c f] = ndgrid(1:size(new_seizures,1), 1:numel(montages), 1:numel(correlations), 1:numel(filterings));
%run       = [ new_seizures(s(:),1) new_seizures(s(:),2) montages(m(:)) correlations(c(:)) filterings(f(:)) ];

tic
%matlabpool open
parfor i = 1:size(run,1)
    testing_measures(run{i,1}, run{i,2}, run{i,3}, run{i,4}, run{i,5});
end
%matlabpool close
toc


%% Run selection of tests
montages     = {'bipolar'; 'ref'; 'avgref'};
correlations = {'cross-corr'; 'cross-corr_no_zero_lag'; ...
                'coherence'; 'coherence_freq_bands'; ...
                'mean_coherence'; 'mean_coherence_freq_bands'; ...
                'mean_imaginary_coherence'; ...
                'imaginary_coherence'; 'imaginary_coherence_freq_bands'; ...
                'pli'; 'pli_cpsd'; 'wpli';
                'cross-corr_no_symmetric'}; 
thresholds = [0.75; 0.75; 
              0.95; 0.95; 
              0.4; 0.4;
              0.08;
              0.85; 0.85; 
              0.13; 0.55; 0.6;
              0.5]; 
filterings   = {'ICA'; 'f1-60_notch'; 'f1-50'; 'f1-60'; 'alpha'; 'beta'; 'gamma'; 'delta'; 'theta'}; 
seizures     = {'/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240' '19_56_36_820_[-15min_+15min]'; % I.I.
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '4_18_11_250_[-15min_+15min]';  % M.C. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b' '16_48_31_920_[-15min_+15min]'; % M.C. 2nd seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_11_43_870_[-15min_+15min]'; % T.K. 1st seizure
                '/home/manolisc/epilepsy/Exports/focal_Export-Txxxxx~ Kxxxxx_c840d375-4129-4384-935a-0c6241e004aa' '59_33_52_810_[-15min_+15min]'; % T.K. 2nd seizure
                '/home/manolisc/epilepsy/Exports/Export-Hxxx~ Exxx_bb167ef0-9e10-43b7-9456-3b3dc43a3baa' '91_26_49_705_[-15min_+15min]';           % H.E.
                '/home/manolisc/epilepsy/Exports/Export-Mxxxxxx~ Gxxxx_f84c19fa-45c8-4c1a-89a3-97811009a935' '36_43_57_265_[-15min_+15min]';       % M.G.
                '/home/manolisc/epilepsy/Exports/Export-Txxxxx~ Yxxxxx_d405987a-c066-4363-a607-bd1ec8c5f7cf' '15_50_06_900_[-15min_+15min]'        % T.Y. 
};

mrange = 1:3;
crange = 13;
frange = 1;
srange = 3;
for m = mrange
    parfor c = crange
        for f = frange
            for s = srange
                disp(seizures(s,1));
                disp(seizures(s,2));
                disp(montages(m));
                disp(correlations(c));
                disp(filterings(f));
                testing_measures(seizures{s,1},seizures{s,2},montages{m},correlations{c},filterings{f},thresholds(c));
            end
        end
    end
end


%% Plot brain networks around seizure
PATIENT_SEIZURE ='focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_4_18_11_250_[-15min_+15min]/';
EXPERIMENT      ='bipolar__ICA__coherence_freq_bands';
MONTAGE         = 'bipolar'
WINDOW          = 5;
CONNECTIVITY    = 0;
SURROGATES      = 0;
THRESHOLD       = 0.85;

% Load experiment
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/data.mat'],['nets_w' num2str(WINDOW)]);
if CONNECTIVITY>0
    eval(['nets = binarize_fixed_connectivity(nets_w' int2str(WINDOW) ',CONNECTIVITY);']);
elseif SURROGATES>0
    %%%%%%%%%%%%%%%%%
else
    eval(['nets = binarize(nets_w' int2str(WINDOW) ',THRESHOLD);']);
end
eval(['clear nets_w' int2str(WINDOW)]);

% Plot and save
if CONNECTIVITY>0
    subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/graphs_w' int2str(WINDOW) '_c' num2str(connectivity)];
elseif SURROGATES>0
    %%%%%%%%%%%%%%%%%
else
    subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/graphs_w' int2str(WINDOW) '_t' num2str(THRESHOLD)];
end

if ~exist(subdir,'dir')
    mkdir(subdir);
end

timemoments = size(nets,3);
for i=1:timemoments
    draw_brain_network(nets(:,:,i), MONTAGE)
    saveas(gcf, [subdir '/graph' int2str(i) '.jpg'])
    close(gcf);    
end

% Clean up
clear PATIENT_SEIZURE EXPERIMENT WINDOW THRESHOLD MONTAGE subdir i nets



%% Plot brain networks differences between two networks
PATIENT_SEIZURE ='focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_4_18_11_250_[-15min_+15min]/';
EXPERIMENT      ='ref__f1-60__coherence_freq_bands';
MONTAGE         = 'ref';
WINDOW          = 10;
THRESHOLD       = 0.85;
EXPERIMENT2     ='ref__f1-60__imaginary_coherence_freq_bands';
%THRESHOLD2      = 0.95;
DIFFTITLE       = 'imaginary_coherence';

% Load experiment 1
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/data.mat'],['nets_w' num2str(WINDOW)]);
eval(['nets1 = binarize(nets_w' int2str(WINDOW) ',THRESHOLD);']);
eval(['clear nets_w' int2str(WINDOW)]);

% Load experiment 2
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT2 '/data.mat'],['nets_w' num2str(WINDOW)]);
eval(['nets2 = binarize(nets_w' int2str(WINDOW) ',THRESHOLD);']);
eval(['clear nets_w' int2str(WINDOW)]);

% Plot and save
subdir = ['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/graphs_w' int2str(WINDOW) '_t' num2str(THRESHOLD) ...
    '__diff__' DIFFTITLE];
if ~exist(subdir,'dir')
    mkdir(subdir);
end

timemoments = size(nets1,3);
for i=1:timemoments
    % Plot only networks that differ
    if draw_brain_network_differences(nets1(:,:,i), nets2(:,:,i), MONTAGE)==1
        saveas(gcf, [subdir '/graph' int2str(i) '.jpg'])
    end
    close(gcf);    
end

% Clean up
clear PATIENT_SEIZURE EXPERIMENT WINDOW THRESHOLD MONTAGE subdir i nets



%% Plot correlations vs electrode distances
% Load electod distances and get rid of the common reference Cz
if ~exist('A')
    A=importdata('electrode-distances.txt');
    A=A(~ismember(1:size(A,1),13),:);
    A=A(:,~ismember(1:size(A,2),13));
    Avec = nonzeros(triu(A)');
end

% Load the correlations
PATIENT_SEIZURE='focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_19_56_36_820_[-15min_+15min]/';
NAME='I.I.';
%EXPERIMENT='ref__f1-60__coherence_freq_bands';
EXPERIMENT='ref__f1-50__kramer__ICA';
WINDOW=10;
load(['/home/manolisc/epilepsy/Exports/' PATIENT_SEIZURE EXPERIMENT '/data.mat'],['nets_w' num2str(WINDOW)]);
timemoments = [70 90 100];
freq        = {'all' 'alpha' 'beta' 'gamma' 'delta' 'theta'};

for t=timemoments
    for fi=1:1
        %figtitle = strcat(NAME,' --- ',EXPERIMENT,' - ', char(freq(fi)), ' --- window=',num2str(WINDOW),'--- time=', num2str(t));

         % Plot correlation measure
        netvec = nonzeros(triu(nets_w10(:,:,t,fi))');
        scatter(Avec,netvec);
        h=lsline;
        set(h(1),'color','r')
        title(figtitle);
        saveas(gcf, strcat(figtitle, '.jpg'));
        close(gcf);
    end
end

% Plot correlation measure minus random coherence
%figure
%scatter(Avec,netvec-exp((1-Avec)/3));
%lsline;


%% Single patient from scratch
[data,indices] = importEEG('/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min].txt',0);
node_data      = xltek_to_bipolar(data);
filtered_data  = bandpass(node_data,1,50);

SRATE  = 200;
WINDOW = 5;     % In sec.
frame  = WINDOW*SRATE;

[length chan]  = size(filtered_data);
nets_w         = zeros(chan,chan,ceil(length/frame));
maxind         = zeros(chan,chan,ceil(length/frame));
timemoments    = 0;
for time = 1:frame:length
    timestop    = min(time+frame-1,length);
    timemoments = timemoments + 1;
    for i = 1:chan
        for j = 1:chan
            if (i<j)
%                [nets_w(i,j,timemoments) maxind(i,j,timemoments)] = max(abs(xcov(filtered_data(time:timestop,i),filtered_data(time:timestop,j),50,'coeff')));
                covmat = abs(xcov(filtered_data(time:timestop,i),filtered_data(time:timestop,j),50,'coeff'));
%                nets_w(i,j,timemoments) = max(max(covmat(1:50)),max(covmat(52:101)));
                covmat(51) = 0;
                [nets_w(i,j,timemoments) maxind(i,j,timemoments)] = max(covmat);
            % We'll make it symmetric afterwards
            %else
            %    nets_w(i,j,timemoments) = nets_w(j,i,timemoments);
            end
        end
    end
end

for i=1:timemoments
    nets_w(:,:,i) = triu(nets_w(:,:,i)) + triu(nets_w(:,:,i),1)';
end

%plot(1:timemoments, reshape(maxind(1,2,:),timemoments,1));

nets_bin = binarize(nets_w,0.75);
plot_nodes_property('average_degree_und',nets_bin,WINDOW);


%% Problematic coherence data
load('/home/manolisc/epilepsy/Exports/focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240/seizure_19_56_36_820_[-15min_+15min]/bipolar__f1-60__coherence_freq_bands/data.mat');
[C,f]  = mscohere(data(120000:122000,5),data(120000:122000,4),[],[],[],200);figure; plot(f,C);


%% Plot part of edf matrix
from=12;
to=15;
SRATE=500;

screen_size = get(0, 'ScreenSize');
h = figure('Position', [0 0 screen_size(3) screen_size(4) ]);
set(h,'Color',[1 1 1]);
for i=1:18
    ax(i) = subplot(18,1,i); 
    plot(from:0.002:to,DK_data2{1,i}(from*SRATE:to*SRATE));
end

    % Set the X-axis tick locations and limits of
    % each plot to the same values
%    set(ax,'YTick',get(ax(1),'YTick'), ...
%    'YLim',get(ax(1),'YLim'))

    % Turn off the X-tick labels in the top axes
    set(ax(1:17),'XTickLabel','');

    % Set the background color to gray
%    set(gca,'Color',[0.8 0.8 0.8]);

    % Set the color of the X-axis in the top axes
    % to the axes background color
    set(ax(1:17),'XColor',get(gca,'Color'))
    
    % Turn off the box so that only the left 
    % vertical axis and bottom axis are drawn
    set(ax,'box','off')

%% Load a series of EDF data from a patient
day_num = 9;
max_day_file = 4;
patient_day = ['/home/epilepsy/Original Data/new-patients-small-files/Karamanidou Panayiota 10753/KP_patientevent5-' int2str(day_num) ];
for i=0:max_day_file
    if (i==0)
        seq = '';
    else
        seq = int2str(i);
    end
    % Load both data and header
    % eval(['[data' int2str(day_num) seq ',header' int2str(day_num) seq ']=ReadEDF(''' patient_day seq '.edf'');']);
    % Load header only
    eval(['[~,header' int2str(day_num) seq ']=ReadEDF(''' patient_day seq '.edf'');']);
end

%%
for i=0:4
    if (i==0)
        seq = '';
    else
        seq = int2str(i);
    end
    eval(['header' int2str(day_num) seq '.startdate']);
    eval(['header' int2str(day_num) seq '.starttime']);
    eval(['header' int2str(day_num) seq '.annotation.event(1:5)']);
    eval(['starts = find(strcmp(header' int2str(day_num) seq '.annotation.event,''start''))']);
end

%%
sum = size(data1{1,1},1);
for i=1:9
    eval(['sum = sum + size(data1' int2str(i) '{1,1},1);']);
end
sum
sum/(500*60)

%%
patient   = 'KP_Day1';
starttime = 87.8125;
shift     = 0;

% Ignore shift initially
    starttime_row = floor(starttime * 500);
    figure7
    plot(-data{1,1}(starttime_row-1000:starttime_row+1000));
    hold on;
    ylimits = get(gca, 'YLim');
    plot([1000 1000], ylimits, '--','DisplayName','','Color','k');

    saveas(gca,[patient '_seizure_' num2str(starttime) 'a.jpg']);
    hold off;

% Plot once more with the shift included
if (shift>0)
    starttime_row = floor(starttime * 500) + shift*500;
    figure
    plot(-data16{1,1}(starttime_row-1000:starttime_row+1000));
    hold on;
    ylimits = get(gca, 'YLim');
    plot([1000 1000], ylimits, '--','DisplayName','','Color','k');

    saveas(gca,[patient '_seizure_' num2str(starttime) 'b.jpg']);
    close;
end


%% Bipolar (old) data; making plots on selection of channels
clear;
bad_channels = [1 5 9 13];
threshold  = 0.75;
datadir    = '/home/manolisc/epilepsy/Exports';
patient    = 'focal_Export-Ixxxxx~ Ixxxxx_9fee1d08-4e32-4b56-a20d-9fc240673240';
seizure    = 'seizure_19_56_36_820_[-15min_+15min]';
experiment = 'bipolar__ICA__coherence_freq_bands';
artfctdir  = '/home/manolisc/fieldtrip';

% Load the data
load([datadir '/' patient '/' seizure '/' experiment '/data.mat']);
window_size = 5;

% Get rid of noisy channels
index = true(1,size(nets_w5,1));
index(bad_channels) = false;
if size(nets_w5,4)>0
    nets_w5_clean = nets_w5(index,index,:,:);
else
    nets_w5_clean = nets_w5(index,index,:);
end
size(nets_w5_clean)

% Correct event annotations
load([artfctdir '/' patient '/' seizure '__seizures-and-artifacts.mat']);
evstart = cfg.artfctdef.seizure.artifact(1)/200;
evend = cfg.artfctdef.seizure.artifact(2)/200;

% Binarize and plot for clean network
nets = binarize(nets_w5_clean,threshold);
clean_figdir = [OUTDIR '/window=' num2str(window_size) '/threshold=' num2str(threshold) '/excl_bad_channels'];
plot_all(nets,window_size,evstart,evend,clean_figdir);
plot_all_brain_networks(nets,NET,clean_figdir,bad_channels);





%% Plot histogram of lag indices where the max cross-corr and the max cross-corr-no-zero-lag occur
clear
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/data.mat';
load(datafile);

[s1 s2 s3]    = size(indx);
size_per_iter = (s1-1)*(s2-2)/2;
%indx_vector   = zeros(s3*size_per_iter,1);
indx_vector1 = [];
for i=1:s3
    strt = (i-1)*size_per_iter+1;
    %indx_vector(strt:strt+size_per_iter-1) = indx(find(~tril(ones(size(indx(:,:,i))))));
    indx_vector1 = [indx_vector1; indx(find(~tril(ones(size(indx(:,:,i))))))];
end

indx_vector1(indx_vector1<-15|indx_vector1>15) = [];

clearvars -except indx_vector1
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr_no_zero_lag/data.mat';
load(datafile);

[s1 s2 s3]    = size(indx);
size_per_iter = (s1-1)*(s2-2)/2;
%indx_vector   = zeros(s3*size_per_iter,1);
indx_vector2 = [];
for i=1:s3
    strt = (i-1)*size_per_iter+1;
    %indx_vector(strt:strt+size_per_iter-1) = indx(find(~tril(ones(size(indx(:,:,i))))));
    indx_vector2 = [indx_vector2; indx(find(~tril(ones(size(indx(:,:,i))))))];
end
indx_vector2(indx_vector2<-15|indx_vector2>15) = [];

h = figure;
subplot(2,1,1)
hist(indx_vector1,[-15:15])
title('Cross-correlation');
subplot(2,1,2)
hist(indx_vector2,[-15:15])
title('Cross-correlation excluding zero-lags');
saveas(h,[strrep(datafile,'data.mat','subplot_hist_with_and_without_zerolags.jpg')]);
saveas(h,[strrep(datafile,'data.mat','subplot_hist_with_and_without_zerolags.fig')]);


%% Histogram to show differences between max correlations of cross-corr and cross-corr_no_zero_lag
clear
datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr_no_zero_lag/data.mat';
load(datafile);
indx_nozerolag = indx;
nets_nozerolag = nets_w5;
clearvars -except indx_nozerolag nets_nozerolag

datafile = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/data.mat';
load(datafile);
nets = nets_w5;
clearvars -except indx_nozerolag nets_nozerolag indx nets datafile

% Indices of non-zero elements above the diagonal
[s1 s2 s3]    = size(indx);         % third dimension is time
size_per_iter = (s1-1)*(s2-2)/2;
diffs = [];
for i=1:s3
    % Vectorize upper triangular parts
    indx1 = indx(:,:,i);
    indx1v = indx1(itriu(size(indx1),1));
    nets_diff = nets(:,:,i) - nets_nozerolag(:,:,i);
    nets1v = nets_diff(itriu(size(indx1),1));
    
    diffs = [diffs; nets1v(find(indx1v==0))];
end

h = figure;
%[nelements,xcenters] = hist(diffs);
%plot(xcenters,nelements);
hist(diffs,[0.025:0.05:0.4]);
saveas(h,[strrep(datafile,'data.mat','crosscorr_vs_nonzerolag_maxdiff.jpg')]);
saveas(h,[strrep(datafile,'data.mat','crosscorr_vs_nonzerolag_maxdiff.fig')]);


%% Plot node properties of three experiments in the same figure (change montage)
% =========================================================================
% Load and binarize nets
% In the 4th dimension we add the experiments to be plot at the same figure
% included
clear
experiment = 'cross-corr_no_symmetric';
threshold = 0.5;

datafile = ['/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__' experiment '/data.mat'];
load(datafile,'nets_w5');
nets = binarize(nets_w5,threshold);
clear nets_w5;

datafile = ['/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/avgref__ICA__' experiment '/data.mat'];
load(datafile,'nets_w5');
channels_to_include = [1:12 14:19];
avgnet = binarize(nets_w5,threshold);
nets(:,:,:,2) = avgnet(channels_to_include,channels_to_include,:);
clear nets_w5;

datafile = ['/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/ref__ICA__' experiment '/data.mat'];
load(datafile,'nets_w5','evstart','evend');
nets(:,:,:,3) = binarize(nets_w5,threshold);
clear nets_w5;


% Plot properties - you need to set MULTIPLE_NETWORKS_PER_FIG = 1
figdir = strrep(datafile,'data.mat',[experiment '_montage_comparison_3x']);
network_labels = {'Bipolar montage' 'Common reference montage' 'Average reference montage'};
plot_all(nets,5,evstart,evend,figdir,network_labels);


%% Plot node properties of two experiments in the same plot
% =========================================================================
% Load and binarize nets
% In the 4th dimension: 1 is no-zero-lag corrs and 2 with zero-lags
% included
clear
file_prefix = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__';
file_suffix = '/data.mat';

% Cross-correlation vs no-zero-lag
experiments = {'cross-corr'; 'cross-corr_no_zero_lag'};
legends = {'Cross-correlation'; 'No-zero-lag cross-correlation'};
thresholds = [0.5; 0.5];

% Cross-correlation vs no-zero-lag vs no-symmetric
% experiments = {'cross-corr'; 'cross-corr_no_zero_lag';'cross-corr_no_symmetric'};
% legends = {'Cross-correlation'; 'No-zero-lag cross-correlation'; 'No-symmetric cross-correlation'};
% thresholds = [0.5; 0.5; 0.5];

% Coherence
% experiments = {'mean_coherence'; 'mean_imaginary_coherence'};
% legends = {'Coherence'; 'Imaginary Coherence'};
% thresholds = [0.35; 0.06];

% Coherence freq bands
% experiments = {'coherence_freq_bands'; 'imaginary_coherence_freq_bands'};
% legends = {'Coherence'; 'Imaginary Coherence'};
% thresholds = [0.9; 0.6];

% PLI
% experiments = {'pli'; 'wpli'};
% legends = {'PLI'; 'Weighted PLI'};
% thresholds = [0.13; 0.6];

for i=1:size(experiments,1)
    datafile = [file_prefix experiments{i} file_suffix];
    load(datafile,'nets_w5');
    if size(size(nets_w5),2)==4
        nets(:,:,:,:,i) = binarize(nets_w5,thresholds(i));
    else
        nets(:,:,:,i) = binarize(nets_w5,thresholds(i));
    end
    clear nets_w5;
end
load(datafile,'evstart','evend');

expdir = '';
for i=1:size(experiments,1)-1
    expdir = [expdir experiments{i} '__vs__'];
end
expdir = [expdir experiments{end}];
figdir = strrep([file_prefix experiments{1} file_suffix],'data.mat',expdir)

if ~exist(figdir,'dir')
    mkdir(figdir); 
end

if size(size(nets),2)==5
    freqband_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};
    [s1 s2 s3 s4 s5] = size(nets);
    for i=1:s4
        plot_all(reshape(nets(:,:,:,i,:),[s1 s2 s3 s5]),5,evstart,evend,[figdir '/' freqband_labels{i}],legends);
    end
else
    plot_all(nets(:,:,:,:),5,evstart,evend,figdir,legends);
end


%% Delete (should be same as above)
clear
datafile1 = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/data.mat';
load(datafile1,'nets_w5');
nets = binarize(nets_w5,0.75);
clear nets_w5;

datafile2 = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__imaginary_coherence_freq_bands/data.mat';
load(datafile2,'nets_w5','evstart','evend');
nets(:,:,:,:,2) = binarize(nets_w5,0.75);   % 4th dim. is now the freq. band
clear nets_w5;

% Plot properties - you need to set MULTIPLE_NETWORKS_PER_FIG = 1
figdir = strrep(datafile1,'data.mat','comparison_to_imaginary_coherence');
network_labels = {'Coherence' 'Imaginary coherence'};
freqband_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};
[s1 s2 s3 s4 s5] = size(nets);
for i=1:6
    plot_all(reshape(nets(:,:,:,i,:),[s1 s2 s3 2]),5,evstart,evend,[figdir '/' freqband_labels{i}],network_labels);
end





%% Plot node properties vs electrode distance of two experiments in the same figure (coherence vs imaginary coherence, one band per plot)
clear
datafile1 = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/data.mat';
load(datafile1,'nets_w5');
nets1 = nets_w5;
clear nets_w5;

datafile2 = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__imaginary_coherence_freq_bands/data.mat';
load(datafile2,'nets_w5','evstart','evend');
nets2 = nets_w5;   % 4th dim. is now the freq. band
clear nets_w5;

load('/home/manolisc/epilepsy/MATLAB/electrode_locations_and_distances.mat','bipolar_distances');
dist = nonzeros(triu(bipolar_distances));
clear bipolar_distances;

figdir = strrep(datafile1,'data.mat','electrode_dist_comparison_to_imaginary_coherence');
timemoments = [90];
freq        = {'All bands' 'Alpha Band' 'Beta Band' 'Gamma Band' 'Delta Band' 'Theta Band'};

for t=timemoments
    for fi=1:6
        figtitle = strcat(freq(fi),'Time=', num2str(t));

        % Plot correlation measure
        net1vec = nonzeros(triu(nets1(:,:,t,fi))');
        net2vec = nonzeros(triu(nets2(:,:,t,fi))');
        scatter(dist,net1vec,'o');
        h=lsline;
        set(h(1),'color','r')
        hold on
        scatter(dist,net2vec,'+');
        h=lsline;
        set(h(1),'color','b')
        title(figtitle);
        saveas(gcf, strcat(figdir,'/',figtitle, '.jpg'));
        close(gcf);
    end
end


%% Combine multiple figs in one fig
% =========================================================================

% Montages, varying measures
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]';
figs = { [dir '/ref__ICA__cross-corr/cross-corr_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/ref__ICA__cross-corr_no_zero_lag/cross-corr_no_zero_lag_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/ref__ICA__mean_coherence/mean_coherence_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/ref__ICA__imaginary_coherence/imaginary_coherence_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/ref__ICA__pli/pli_montage_comparison_3x/average_degree_und1.fig'];
         [dir '/ref__ICA__wpli/wpli_montage_comparison_3x/average_degree_und1.fig']
       };
titles = {'Cross-correlation'; 'Cross-correlation excluding zero-lags';
            'Coherence'; 'Imaginary coherence'; 
            'PLI'; 'Weighted PLI'};
legends = {'Bipolar' 'Common ref.' 'Average ref.'};
figs_to_subplots(figs,titles,3,2,legends,[dir '/average_degree_montage_comparisons']);

%% Cross-corr vs cross-corr_no_zero_lag, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr/cross-corr__vs__cross-corr_no_zero_lag';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
%         [dir '/betweenness_centralization_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; % 'Betweenness centralization';
             'Clustering'};
legends = {'Cross-correlation' 'No-zero-lag cross-correlation'};
figs_to_subplots(figs,titles,3,1,legends,[dir '/cross-corr__vs__cross-corr_no_zero_lag_all_measures']);

%% Cross-corr vs cross-corr_no_zero_lag, average degree, varying threshold
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__cross-corr';
fig_choice = 'network_clustering_WS_bu1';
figs = { [dir '/cross-corr__vs__cross-corr_no_zero_lag_t0.35/' fig_choice '.fig'];
         [dir '/cross-corr__vs__cross-corr_no_zero_lag_t0.45/' fig_choice '.fig'];
         [dir '/cross-corr__vs__cross-corr_no_zero_lag_t0.55/' fig_choice '.fig'];
         [dir '/cross-corr__vs__cross-corr_no_zero_lag_t0.65/' fig_choice '.fig']
       };
titles = {'Threshold 0.35'; 'Threshold 0.45';
            'Threshold 0.55'; 'Threshold 0.65'};
legends = {'Cross-correlation' 'No-zero-lag cross-correlation'};
figs_to_subplots(figs,titles,2,2,legends,[dir '/cross-corr__vs__cross-corr_no_zero_lag_clustering_varying_thresholds']);

%% Cross-corr vs cross-corr_no_zero_lag, histograms
clear;
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]';
figs = { [dir '/bipolar__ICA__cross-corr_no_zero_lag/window=5/threshold=0.75/max-cross-corr_no_zero_lag-lag-indx.fig'];
         [dir '/bipolar__ICA__cross-corr/window=5/threshold=0.75/max-cross-corr-lag-indx.fig']
        };
titles = {'Cross-correlation'; 'Cross-correlation excluding zero-lags'};
      
figs_to_subplots(figs,titles,2,1,[dir '/subplot_hist_lag_indx']);

%% Coherence vs Imaginary coherence, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__mean_coherence/mean_coherence__vs__mean_imaginary_coherence__t0.35_t0.06';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
         [dir '/betweenness_centralization_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; 'Betweenness Centralization';
             'Clustering'};
legends = {'Coherence' 'Imaginary Coherence'};
figs_to_subplots(figs,titles,2,2,legends,[dir '/mean_coherence__vs__mean_imaginary_coherence_all_measures']);

%% Coherence vs Imaginary coherence, frequency bands, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence_freq_bands/coherence_freq_bands__vs__imaginary_coherence_freq_bands__t0.9_t0.6';
titles = {'Average Degree'; 'Efficiency'; 'Betweenness Centralization';
             'Clustering'};
legends = {'Coherence' 'Imaginary Coherence'};
freqbands = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};

for i=1:6
figs = { [dir '/' freqbands{i} '/average_degree_und1.fig'];
         [dir '/' freqbands{i} '/efficiency_bin1.fig'];
         [dir '/' freqbands{i} '/betweenness_centralization_bin1.fig'];
         [dir '/' freqbands{i} '/network_clustering_WS_bu1.fig']
       };
    figs_to_subplots(figs,titles,2,2,legends,[dir '/coherence__vs__imaginary_coherence_all_measures_' strrep(freqbands{i},' ','_')]);
end

%% PLI vs weighted PLI, varying network properties
dir  = '/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__pli/pli__vs__wpli__t0.13_t0.6';
figs = { [dir '/average_degree_und1.fig'];
         [dir '/efficiency_bin1.fig'];
         [dir '/betweenness_centralization_bin1.fig'];
         [dir '/network_clustering_WS_bu1.fig']
       };
titles = {'Average Degree'; 'Efficiency'; 'Betweenness Centralization';
             'Clustering'};
legends = {'PLI' 'Weighted PLI'};
figs_to_subplots(figs,titles,2,2,legends,[dir '/pli__vs__wpli_all_measures']);



%% Average power per freq. among all channels as a function of time
clear;
load('/home/manolisc/epilepsy/Exports/focal_Export-Mxxxxxxxxx~ Cx_95a3aa1d-cd6c-4844-acbd-921d46a45f8b/seizure_16_48_31_920_[-15min_+15min]/bipolar__ICA__coherence/data.mat');

window = 5;
srate  = 200;
[ndatapoints,nchannels] = size(node_data);
nwindows = ndatapoints/(window*srate);

fband_freq_start = [1   8 13 30 1 4];
fband_freq_stop  = [45 13 30 45 4 8];
fband_labels = {'all bands' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};
nfbands = size(fband_freq_start,2);
assert(nfbands == size(fband_freq_stop,2));
assert(nfbands == size(fband_labels,2));

pxx_mean_per_band = zeros(nwindows,nfbands);
pxx_std_per_band  = zeros(nwindows,nfbands);

for wstart=1:window*srate:ndatapoints
    wend = wstart + window*srate -1;
    [p1,f] = pwelch(node_data(wstart:wend,1),[],[],[],srate);
    pxx = zeros(size(p1,1),nchannels);
    pxx(:,1) = 10*log10(p1);
    for i=2:18
        [pxx(:,i),~] = pwelch(node_data(wstart:wend,i),[],[],[],srate);
        pxx(:,i) = 10*log10(pxx(:,i));
    end

    fband_indx_start = zeros(nfbands,1);
    fband_indx_stop  = zeros(nfbands,1);
    for i=1:nfbands
        fband_indx_start(i) = find(f>fband_freq_start(i),1,'first');
        fband_indx_stop(i)  = find(f<fband_freq_stop(i),1,'last');
    end

    t = wend/(window*srate);
    for i=1:nfbands
        power_in_band = mean(pxx(fband_indx_start(i):fband_indx_stop(i),:));
        pxx_mean_per_band(t,i) = mean(power_in_band);
        pxx_std_per_band(t,i)  = std(power_in_band);
    end
end

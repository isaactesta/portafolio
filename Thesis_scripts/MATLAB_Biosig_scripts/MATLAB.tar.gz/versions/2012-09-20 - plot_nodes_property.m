function C = plot_nodes_property(fname, graphs, duration, evstart, evend)
%PLOT_NODES_PROPERTY Plots the change of a property of each node (or the graph as a whole) through time
%
%   Example C=plot_nodes_property('degrees_und',graphs);
%   Other fnames include: betweenness_bin, clustering_coef_bu, density_und,
%       modularity_und, transitivity_bu etc.
%
% INPUT
%   fname    : A function that measures some property of the nodes of the
%              graph (or of the graph as a whole)
%   graphs   : A 3-dimensional matrix (i,j,k) where i,j are nodes, entry
%              (i,j) denotes the presence of a connection, and k is time
%   duration : Integer indicating the time gap between successive graphs
%              This is used in annotating the x axis of the plot
%   events   : Each element indicates the second where an event occurs
%
% OUTPUT
%   C        : A 2D matrix where columns correspond to time moments 
%              (index k of graphs), and rows correspond to the values
%              measured (i.e. one value per node, or just one value for the
%             whole graph)
%
% Manolis Christodoulakis @ 2011

    % Set default values
    if (nargin<3)
        duration = 1;
    end

    % Compute the function once for each graph
    %disp(['plot_nodes_property: evaluating function ' fname '...']);
    [~, ~, timemoments] = size(graphs);
    
    for k=1:timemoments
       C(:,k) = feval(fname,graphs(:,:,k));
    end

    % Plot
    [c_rows,~]      = size(C);
    lines_per_plot  = 2;
    colors          = hsv(lines_per_plot+1);
    num_plots       = 0;
    for k=1:c_rows
        modk = mod(k,lines_per_plot);
        if modk==1
            fig_title = [fname ' ' int2str(k)];
            figure('Name',fig_title,'visible','off');
            hold on;
        end
        plot(1:duration:timemoments*duration,C(k,:),...
             'color',colors(modk+1,:),...
             'DisplayName',['Channel ' int2str(k)]);

        if modk==0 | k==c_rows
            title(fname_to_str(fname));
            num_plots = num_plots+1;
        
            if c_rows~=1
                legend show;
            end

            % Indicate specific events if there are any
            if (nargin>=4)
                arrayfun(@(e) add_vline(e,'--'),evstart);
            end
            
            if (nargin==5)
                arrayfun(@(e) add_vline(e,':'),evend);
            end
            
            hold off;
            saveas(gcf, [fname num2str(num_plots) '.jpg'])
            close(gcf)
        end
    end
    %disp(' Done!\n');
end

function [str]=fname_to_str(fname)
    switch fname
        case 'degrees_und'
            str = 'Degrees';
        case 'betweenness_bin'
            str = 'Betweeness Centrality';
        case 'clustering_coef_bu'
            str = 'Clustering Coefficient';
        case 'density_und'
            str = 'Density';
        case 'modularity_und'
            str = 'Modularity';
        case 'transitivity_bu'
            str = 'Transitivity';
        case 'charpath'
            str = 'Characteristic Path Length';
        case 'betweenness_centralization_bin'
            str = 'Betweeness Centralization';
        case 'efficiency_bin'
            str = 'Global Efficiency';
        case 'network_clustering_WS_bu'
            str = 'Clustering Coefficient';
        case 'network_clustering_NMW_bu'
            str = 'Global Clustering (Newton, Moore and Watts)';
        case 'network_smallworldness_WS_bu'
            str = 'Network Small-worldness';
        case 'network_smallworldness_NMW_bu'
            str = 'Network Small-worldness (Newton, Moore and Watts)';
        case 'average_degree_und'
            str = 'Average Degree';
        otherwise
            str = fname;
    end
end

function add_vline(x,style)
    ylimits = get(gca, 'YLim');
    %plot([x x], ylimits, 'k');
    plot([x x], ylimits, style,'DisplayName','');% ,'DisplayName',name);
end

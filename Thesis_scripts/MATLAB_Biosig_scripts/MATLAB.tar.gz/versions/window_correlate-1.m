function c = window_correlate(A,threshold,window_size,shift)
%CORRELATE Applies correlation coefficient to windows of A. 
%   Columns in A are the variables to be correlated.
%   Rows in A are the values of each variable.
%   The threshold is used to separate good connections from bad ones.
%       It must be a positive float < 1.
%   Returns a 3D %matrix of the correlation coefficient windows.
%
%   Manolis Christodoulakis @ 2011

% Set default values
if (nargin<3)
    window_size = 4000;     % 20 sec @ 200Hz 
    shift = 2000;           % 10 sec @ 200Hz 
elseif (nargin<4)
    shift = 2000;           % 10 sec @ 200Hz 
end

% Check for erroneous input
if (threshold <= 0 || threshold >=1)
    error('Invalid input! threshold must be between 0 and 1 exclusive!');
end

if (window_size <= 0)
    error('Invalid input! Window_size must be greater than 0!');
end

if (window_size < shift)
    error('Invalid input! Window_size must be larger than shift!');
end

[rowsA colsA] = size(A);
num_windows = ceil((rowsA-window_size)/shift)+1; % ??? Check this
c(1:colsA-1,1:colsA-1,1:num_windows)=0;
for i=1:num_windows
    % Find correlations within the current window
    first_row = (i-1)*shift+1;
    last_row = min(first_row+window_size-1,rowsA);
    c(:,:,i) = corrcoef(A(first_row:last_row,2:end)); % Assumes the first
                                                      % col is time
end
c(c>threshold|c<-threshold)=1;
c(c<1)=0;
end


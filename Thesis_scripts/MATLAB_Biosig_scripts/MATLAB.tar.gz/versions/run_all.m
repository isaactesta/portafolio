function [data,indices,nets] = run_all(dir,seizid)
%run_all Runs all experiments on a specific set of data

source = [dir '\seizure' int2str(seizid) '.txt']
[data,indices]=importEEG(source,0);
nets = window_cross_correlation(data);
plot_nodes_property('degrees_und',nets);
plot_nodes_property('betweenness_bin',nets);
plot_nodes_property('clustering_coef_bu',nets);
plot_nodes_property('charpath',nets);

destination = [dir '\seizure' int2str(seizid)];
mkdir(destination);
movefile('*.jpg',destination);
end


function t = time_add_index(t1,index,srate)
% Adds times in [h m s ms]
% Hours are in recording times (no modulo)
%
% Manolis Christodoulakis @ 2014

    rem    = index;
    
    ind_h  = floor(rem/(3600*srate));
    rem    = rem - ind_h*3600*srate;
    
    ind_m  = floor(rem/(60*srate));
    rem    = rem - ind_m*60*srate;
    
    ind_s  = floor(rem/srate);
    rem    = rem - ind_s*srate;

    ind_ms = rem * 1000/srate;
    assert(rem<srate);

    t      = time_add(t1,[ind_h ind_m ind_s ind_ms]);
end
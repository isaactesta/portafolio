function time = strtime_2_vector(str_time)
    time = [str2num(str_time(1:2)); str2num(str_time(4:5)); str2num(str_time(7:8))];
end
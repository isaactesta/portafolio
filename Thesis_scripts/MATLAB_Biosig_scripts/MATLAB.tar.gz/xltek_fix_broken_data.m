function [fixed_data fixed_times]= xltek_fix_broken_data(orig_data,orig_times)
% XLTEK files contain lines '--- BREAK IN DATA ---' which usually
% correspond to a few seconds missing. This function identifies missing
% rows and adds such rows in fixed_data as NaN
% 
% Manolis Christodoulakis @ 2014
    
    % Sanity check
    assert(isequal(size(orig_data,1),size(orig_times,1)))
    
    % Expected number of equal rows
    srate = 200;
    
    % Get problematic rows
    [prob_rows del_rows] = get_rep_rows(orig_times)
    
    % Convert to indices
    n_orig = size(orig_data,1);
    index = true(1,n_orig);
    for i=1:size(del_rows,1)
        index(del_rows(i,1):del_rows(i,2)) = false;
    end
    times = orig_times(index,:);
    data  = orig_data(index,:);
    assert(isequal(size(data,1),size(times,1)))
    test = time_diff(times(end,:),times(1,:));
    assert((test(1)*3600+test(2)*60+test(3))*200+test(4)/5+1 == size(times,1))
    return;
    
    
%     n_deleted = 0;
%     for i = 1:size(prob_rows,1)
%         n1 = prob_rows(i,1) - n_deleted + 1
%         n2 = n1 + prob_rows(i,2) - 1
%         [uniques,numUnique] = count_unique(times(n1:n2,4));
%         assert(numel(uniques)==200);
%         rep_start = find(numUnique>1)
%         rep_count = numUnique(numUnique>1) - 1 % keep one
%         for j=1:size(rep_start,1)
%             del_start = n1 + rep_start(j)
%             del_end   = del_start + rep_count(j) - 1
%             n_deleted = n_deleted + rep_count(j)
% %             index = true(1, size(times, 1));
% %             index(del_start:del_end) = false;
%             times(del_start:del_end,:) = [];
%             data(del_start:del_end,:) = [];
%         end
%         %rows_to_delete = [ n1+int32(rep_start)+[0; int32(cumsum(rep_count(1:end-1)))]-n_deleted...
%         %               n1+int32(rep_start)+int32(cumsum(rep_count))-1-n_deleted ] 
%         %n_deleted = n_deleted + sum(rep_count)
%     end
%     
%     
%     
%     orig_row = 0;
%     rows_added = 0;
%     last_row_added = 0;
%     missing_rows = 1;
%     while orig_row<n_orig
% %        current_sec = 1;
% %        times(current_sec);
% 
%         % Get the time the first 'time' of the block
%         orig_row = orig_row+1;
%         block_starttime = strtime_2_vector(times{orig_row});
%         % Count samples with the same 'time'
%         i = 1;
%         %for i=1:srate-1
%         while (i<srate && orig_row<n_orig)
%             i = i+1;
%             orig_row = orig_row+1;
% %             if orig_row>n_orig
% %                 break
% %             end
%             current_time = strtime_2_vector(times{orig_row});
%             if ~isequal(current_time-block_starttime,zeros(3,1))
%                 i=i-1;
%                 orig_row = orig_row-1;
%                 break
%             end
%         end % internal while
%         
%         if (missing_rows>0)  % from the previous round
%             add_before = 1;
%         else
%             add_before = 0;
%         end
%         
%         if (i<srate)
%             add_before
%             block_starttime
%             if orig_row==n_orig
%                 missing_rows = srate - i
%             else
%                 dist = current_time - block_starttime
%                 missing_rows = (dist(1)*3600+dist(2)*60+dist(3))*srate - i
%                 
%                 %fixed_data() = data(last_row_added+1:orig_row,:);
%                 %orig_row = orig_row-1;
%             end
%         else
%             missing_rows = 0;
%         end
%     end
end

function [prob_rows del_rows]= get_rep_rows(times,init_row)
    if nargin<2
        init_row=1;
    end
    i=init_row;
    assert(times(i,4)==0)
    n_rows = size(times,1)-i+1;
    
    prob_rows = [1 0 0 0 0 0];
    while i<n_rows
        count = sum(ismember(times(i:min(i+2999,n_rows),1:3),times(i,1:3),'rows'));
        if (count~=200 || isequal(times(i,1:3),times(prob_rows(end,1),1:3)))
            display(['Line ' num2str(i) ': ' num2str(times(i,1:3)) '     ' num2str(count) ' times']);
            if ~isequal(times(i,1:3),times(prob_rows(end,1),1:3))
                prob_rows = [prob_rows; i count times(i,:)]
            else
                prob_rows(end,2) = prob_rows(end,2) + count;
            end
        end
        i = i+count;
    end
    if prob_rows(1,2)==200
        prob_rows(1,:) = []
    end
    if ( prob_rows(end,2)<200 && prob_rows(end,1)+prob_rows(end,2)-1==size(times,1) )
        prob_rows(end,:) = []
    end
    
    del_rows = [0 0];
    for i = 1:size(prob_rows,1)
        if prob_rows(i,2)<200
            continue           
        end
        
        n1 = prob_rows(i,1);
        n2 = n1 + prob_rows(i,2) - 1;
        assert(times(n1,4)==0)
        assert(times(n2,4)==995)
        [uniques,numUnique] = count_unique(times(n1:n2,4));
        assert(numel(uniques)==200);
        rep_start = int32(find(numUnique>1));
        rep_count = numUnique(numUnique>1) - 1; % keep one
        
        del_start = n1 + rep_start + int32([0; cumsum(rep_count(1:end-1))]); % keep the first
        del_end   = del_start + int32(rep_count) -1;
        assert(isequal(times(del_start,:),times(del_start-1,:)))
        assert(~isequal(times(del_start,:),times(del_start-2,:)))
        %assert(times(del_start,:)==add_times(times(del_start-2,:),[0 0 0 5]))
        assert(isequal(times(del_start,:),times(del_end,:)))
        assert(~isequal(times(del_start,:),times(del_end+1,:)))
        %assert(times(del_start,:)==add_times(times(del_start-2,:),[0 0 0 5]))
        del_rows = [del_rows; del_start del_end];        
    end
    del_rows(1,:) = [];
    
    if init_row~=1
        n1 = 1;
        n2 = init_row-1
        [uniques,numUnique] = count_unique(times(n1:n2,4));
        rep_start = int32(find(numUnique>1))
        rep_count = numUnique(numUnique>1) - 1
        del_start = n1 + rep_start + int32([0; cumsum(rep_count(1:end-1))])
        del_end   = del_start + int32(rep_count) -1
        del_rows = [del_rows; del_start del_end]
    end
    
end

function prob_rows = get_prob_rows(times)
    i=1;
    assert(times(i,4)==0)
    n_rows = size(times,1)-i+1;
    prob_rows = [1 0 0 0 0 0];
    %last_block_time = [-1 -1 -1];
    while i<n_rows
        count = sum(ismember(times(i:min(i+2999,n_rows),1:3),times(i,1:3),'rows'));
        if (count~=200 || isequal(times(i,1:3),times(prob_rows(end,1),1:3)))
            display(['Line ' num2str(i) ': ' num2str(times(i,1:3)) '     ' num2str(count) ' times']);
            if ~isequal(times(i,1:3),times(prob_rows(end,1),1:3))
                prob_rows = [prob_rows; i count times(i,:)]
            else
                prob_rows(end,2) = prob_rows(end,2) + count;
            end
        end
        %last_block_time = times(i,1:3);
        i = i+count;
    end
    prob_rows(1,:) = [];
end


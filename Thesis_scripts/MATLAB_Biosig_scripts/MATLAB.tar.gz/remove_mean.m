function y=REMOVE_MEAN(data,lam)

N=length(data);
y=zeros(N,1);
y(1)=0;
for k=1:N-1
    y(k+1)=lam*y(k)+(1-lam)*data(k);
    
end


    
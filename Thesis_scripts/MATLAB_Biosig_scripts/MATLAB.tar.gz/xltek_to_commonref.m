function [ commref_data ] = xltek_to_commonref( data )
%XLTEK_TO_COMMONREF Converts the XLTEK raw data to common ref (Cz)
%   Assumes that rows are time moments and cols are channels
%
% Manolis Christodoulakis @ 2012

    nlines       = size(data,1);
    commref_data = zeros(nlines,18);

    % Subtract Cz
    commref_data(:,1:9) = data(:,4:12) - repmat(data(:,13),1,9);
    commref_data(:,10:18) = data(:,14:22) - repmat(data(:,13),1,9);       
end
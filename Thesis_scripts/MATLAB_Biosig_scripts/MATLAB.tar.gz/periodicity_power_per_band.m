function periodicity_power_per_band(datafile)
%periodicity_power_per_band Calculates and plots the power and its
%autocorrelation in every channel, as well as the mean and std power across
%channels, for each frequency band
%
% Input:
%   datafile    is the path to the file containing filtered_data
%
% Output:
%   The power in every channel for each frequency band
%   The mean and the std of the power across channels for each freq. band
%   Save the above in mat file, and plots and saves the plots in jpg
%
% Manolis Christodoulakis @ 2014

    load(datafile,'filtered_data');

    window = 5;
    srate  = 200;
    [ndatapoints,nchannels] = size(filtered_data);
    nwindows = ceil(ndatapoints/(window*srate));

    fband_freq_start = [1   8 13 30 1 4];
    fband_freq_stop  = [45 13 30 45 4 8];
    fband_labels = {'broadband' 'alpha band' 'beta band' 'gamma band' 'delta band' 'theta band'};
    nfbands = size(fband_freq_start,2);
    assert(nfbands == size(fband_freq_stop,2));
    assert(nfbands == size(fband_labels,2));

    pxx_mean_per_band = zeros(nwindows,nfbands);
    pxx_std_per_band  = zeros(nwindows,nfbands);
    pxx_per_chan_per_band = zeros(nwindows,nchannels,nfbands);

    % Calculate the power in each channel, the mean power, and the std
    fprintf('%3.0f',0)
    for wstart=1:window*srate:ndatapoints
        fprintf('\b\b\b%3.0f',floor(100*wstart/ndatapoints))
        wend = min(wstart + window*srate -1, ndatapoints);
        [p1,f] = pwelch(filtered_data(wstart:wend,1),[],[],[],srate);
        pxx = zeros(size(p1,1),nchannels);
        pxx(:,1) = 10*log10(p1);
        for i=2:18
            [pxx(:,i),~] = pwelch(filtered_data(wstart:wend,i),[],[],[],srate);
            pxx(:,i) = 10*log10(pxx(:,i));
        end

        fband_indx_start = zeros(nfbands,1);
        fband_indx_stop  = zeros(nfbands,1);
        for i=1:nfbands
            fband_indx_start(i) = find(f>fband_freq_start(i),1,'first');
            fband_indx_stop(i)  = find(f<fband_freq_stop(i),1,'last');
        end

        t = (wstart + window*srate -1)/(window*srate);
        for i=1:nfbands
            power_in_band = sum(pxx(fband_indx_start(i):fband_indx_stop(i),:));
            pxx_per_chan_per_band(t,:,i)  = power_in_band;
            pxx_mean_per_band(t,i) = mean(power_in_band);
            pxx_std_per_band(t,i)  = std(power_in_band);
        end
    end
    fprintf('\n')
    
    % Create and save the plots
    outdir  = strrep(datafile,'.mat','_channel_power_periodicities');
    if ~exist(outdir,'dir') mkdir(outdir); end
    patient_title = patient_to_str(outdir);
    
    for i=1:nfbands
        h = figure;
        errorbar((1:size(pxx_mean_per_band(:,i)))*window/3600,pxx_mean_per_band(:,i),pxx_std_per_band(:,i)); hold on;
        plot((1:size(pxx_mean_per_band(:,i)))*window/3600,pxx_mean_per_band(:,i),'r','LineWidth',2);
        xlim([1 size(pxx_mean_per_band(:,i),1)*window/3600])
        title([patient_title ' - Power in ' upper(fband_labels{i}(1)) fband_labels{i}(2:end)]);
        xlabel('Time (Hours)')
        saveas(h,[outdir '/power_' strrep(fband_labels{i},' ','_') '.jpg']);
        close;

        h = figure;
        [acf,lags] = autocorr(pxx_mean_per_band(:,i),length(pxx_mean_per_band(:,i))-1);
        plot((1:size(acf,1))*window/3600,acf)
        title([patient_title ' - Autocorrelation of Power in ' upper(fband_labels{i}(1)) fband_labels{i}(2:end)]);
        xlabel('Autocorrelation Lags (Hours)')
        saveas(h,[outdir '/periodicity_power_' strrep(fband_labels{i},' ','_') '.jpg']);
        close;
    end
    
    % Save the power, the mean and the std in mat file
    save([outdir '/power_per_chan_per_band.mat'],'pxx_per_chan_per_band','pxx_mean_per_band','pxx_std_per_band','-v7.3');
end
function [b,a] = comb2(r,L)
%  COMB
%
%      [b,a] = COMB(r,L)
%
%    generates L zeros equally spaced around a circle of radius r
% Source: http://www.johnloomis.org/ece561/notes/zeropole/comb.html


b = [1 zeros(1,L-1) -r^L];
a = [1 zeros(1,L-1)]; 

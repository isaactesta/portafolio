function fig = plot_with_events(lines,srate,annot,starttime,figtitle,seizstart,seizend,sleepstart,sleepend)
%plot_with_events Plots a given line and adds coloured boxes for events
%
% 
% Manolis Christodoulakis @ 2014

    % Size of data to plot
    [n nlines]          = size(lines);
    
    % Set the x-axis title and scale
    if nargin>3 && ~isempty(starttime)
        x_axis_title    = '24h time';
        start_hour      = double(starttime(1)) + ...
                          double(starttime(2))/60 + ...
                          double(starttime(3))/3600;
        dt              = 5; % Time between two points in seconds
        x_axis_values   = start_hour + [dt/3600:dt/3600:n*dt/3600];     % Set the time scale to hours
    else
        x_axis_title    = 'Hours';
    end

    % Plot the lines
    fig                 = figure;
    plot(x_axis_values,lines);
    xlim([x_axis_values(1) x_axis_values(end)]);
    
    % Set the x-axis timescale to hours
    if nargin>3 &&  ~isempty(starttime)
        xt = get(gca,'xtick'); xt = mod(xt,24); 
        set(gca,'xticklabel',cellstr(num2str(mod(xt',24))));
    end
    
    % Add titling information
    hold on;
    xlabel(x_axis_title);
    if nargin>4 && ~isempty(figtitle) title(figtitle); end;
    set(findall(gcf,'type','text'),'fontSize',24) 
    set(findall(gcf,'type','axes'),'fontsize',14)

    % Add seizures, if available
    if nargin>5 && ~isempty(seizstart)
        for e=start_hour+seizstart/(srate*3600)
            arrayfun(@(e) add_vline(e,'--'),e);
        end
    end
    % Show annotations with coloured boxes
    lims = ylim;
    %legend_set = zeros(6,0);
    s = zeros(7,1);
    for i=1:size(annot,1)-1
%         if strcmp(annot{i,2},'Wakefulness')
%             continue;
%         end
        
        if strcmp(annot{i,2},'Stage 1')
            colour = 'y';
            edgecolour = 'None';
            li = 1;
        elseif strcmp(annot{i,2},'Stage 2')
            colour = 'm';
            edgecolour = 'None';
            li = 2;
        elseif strcmp(annot{i,2},'Stage 3')
            colour = 'c';
            edgecolour = 'None';
            li = 3;
        elseif strcmp(annot{i,2},'Stage 4')
            colour = 'r';
            edgecolour = 'None';
            li = 4;
        elseif strcmp(annot{i,2},'REM')
            colour = 'g';
            edgecolour = 'None';
            li = 5;
        elseif strcmp(annot{i,2},'Wakefulness')
            colour = 'w';
            edgecolour = [.9 .9 .9];
            li = 6;
        else
            continue;
        end
        
        s(li) = fill((start_hour+[annot{i,1} annot{i,1} annot{i+1,1} annot{i+1,1}]./(srate*3600))', ...
                 [lims lims(end:-1:1)]',... %repmat([lims lims(end:-1:1)]',1,size(sleepstart,1)), ...
                 colour, 'EdgeColor',edgecolour);
        uistack(s(li),'bottom');
    end

    % Show sleep with grey boxes
    if nargin>7 && ~isempty(sleepstart) && ~isempty(sleepend)
        s2 = fill((start_hour+[sleepstart sleepstart sleepend sleepend]./(srate*3600))', ...
                repmat([lims lims(end:-1:1)]',1,size(sleepstart,1)), [.75 .75 .75],...
                'EdgeColor','None');
        uistack(s2,'bottom');
        s(7) = s2(1);
    end

    %legend(s(s>0),'Stage 1','Stage 2','Stage 3','Stage 4','REM','Wakefulness','Sleep');
    labels  = {'Stage 1';'Stage 2';'Stage 3';'Stage 4';'REM';'Wakefulness';'Sleep'};
    keep    = find(s);
    hleg    = legend(s(keep),labels{keep,1});
    set(hleg,'FontSize',6,'Location','NorthWest');    
end
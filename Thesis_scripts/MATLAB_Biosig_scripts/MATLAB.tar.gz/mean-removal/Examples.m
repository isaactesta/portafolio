close all;clear all;

t=(1:5000)';
len=5000;
amp=1;
w=10;

x{1}=amp*sin(2*pi*(w/len)*t);
x{2}=repmat([ones(500,1);-1*ones(500,1)],5,1);
x{3}=repmat([(1:200)'.*ones(200,1);50*sin(pi*(1/500)*(1:500)')+200;-1*ones(300,1)],5,1);

data{1}=awgn(x{1},7,'measured');
data{2}=awgn(x{2},7,'measured');
data{3}=awgn(x{3},7,'measured');

lam=cell(3,1);
err_ga=cell(3,1);
y=cell(3,1);
for i=1:3
    ga_opts = gaoptimset('TolFun',1e-8,'StallGenLimit',25,'Generations',120,'UseParallel','always','SelectionFcn',@selectiontournament,'Display','iter');
    nvars=1;
    LB=0.5;
    UB=0.999;
    h = @(X) REMOVE_MEAN_GA(data{i},X);
    rng('shuffle')
    [lam{i}, err_ga{i}] = ga(h, nvars,[],[],[],[],LB,UB,[],[],ga_opts);    
    y{i}=REMOVE_MEAN(data{i},lam{i});
    figure;
    hold on;
    plot(data{i});
    plot(x{i},'g','Linewidth',2);
    plot(y{i},'r','Linewidth',2);
    legend('Noisy Data','Real Data','Predicted Mean')
end

function J=REMOVE_MEAN_GA(data,X)
lam=X(1);

N=length(data);
y=zeros(N,1);
y(1)=0;
for k=1:N-1
    y(k+1)=lam*y(k)+(1-lam)*data(k);
    
end

e=data-y;
J=exp(-(1-var(e)/var(data)));

    
function dt = time_diff(t1,t2)
% Finds the difference t1-t2 of times in [h m s ms] format
% Hours are in recording times (no modulo)
%
% Manolis Christodoulakis @ 2014

    while t1(4)<t2(4)
        t1(4) = t1(4)+1000;
        t1(3) = t1(3)-1;
    end
    ms    = mod(t1(4)-t2(4),1000);
    
    while t1(3)<t2(3)
        t1(3) = t1(3)+60;
        t1(2) = t1(2)-1;
    end   
    s     = mod(t1(3)-t2(3),60);
    
    while t1(2)<t2(2)
        t1(2) = t1(2)+60;
        t1(1) = t1(1)-1;
    end
    m     = mod(t1(2)-t2(2),60);
    
    h     = t1(1)-t2(1);

    dt     = [h m s ms];
end
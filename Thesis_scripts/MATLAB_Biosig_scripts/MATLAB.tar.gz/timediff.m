function t = timediff(h,m,s,ms,seizh,seizm,seizs,seizms)
    diffh = h - seizh;
    diffm = m - seizm;
    diffs = s - seizs;
    diffms = ms - seizms;

    t = 3600*diffh + 60*diffm + diffs + diffms/1000;
end

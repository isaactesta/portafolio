function yhat = sinefit(t,y,period)
% Fits a sine to the curve y, and returns the resulting sine
%
% Manolis Christodoulakis @ 2014

    y = y(:);
    n = size(t,1);
    
    X      = ones(n,3);
    X(:,2) = cos(period); 
    X(:,3) = sin(period);
    
    beta   = X\y;

    yhat   = (beta(1) + beta(2)*cos(period) + beta(3)*sin(period))';
    
    figure
    plot(t,y,'b'); hold on
    plot(t,yhat,'r','linewidth',3);

end